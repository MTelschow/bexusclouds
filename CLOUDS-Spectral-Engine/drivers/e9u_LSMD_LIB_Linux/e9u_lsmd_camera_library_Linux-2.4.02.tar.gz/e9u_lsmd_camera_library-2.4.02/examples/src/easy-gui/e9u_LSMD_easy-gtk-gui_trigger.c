/*
    EURECA's e9u_LSMD camera software – connect to a e9u_LSMD camera USB module
    Copyright (C) 2020 Eureca Messtechnik GmbH, <info@eureca.de>

	This file is part of EURECA's e9u_LSMD camera software.

	EURECA's e9u_LSMD camera software is free software: you can redistribute
	it and/or modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation, either
	version 3 of the License, or (at your option) any later version.

	EURECA's e9u_LSMD camera software is distributed in the hope that it
	will be useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
	See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
	along with Foobar.  If not, see <http://www.gnu.org/licenses/>.



    Diese Datei ist Teil von EURECAs e9u_LSMD Kamera-Software.

	EURECAs e9u_LSMD Kamera-Software ist Freie Software: Sie können sie
	unter den Bedingungen der GNU Lesser General Public License, wie von
	der Free Software Foundation, Version 3 der Lizenz oder (nach Ihrer
	Wahl) jeder neueren veröffentlichten Version, weiter verteilen
	und/oder modifizieren.

	EURECAs e9u_LSMD Kamera-Software wird in der Hoffnung, dass es nützlich
	sein wird, aber OHNE JEDE GEWÄHRLEISTUNG, bereitgestellt; sogar ohne
	die implizite Gewährleistung der MARKTFÄHIGKEIT oder EIGNUNG FÜR
	EINEN BESTIMMTEN ZWECK.  Siehe die GNU General Public License für
	weitere Details.

    Sie sollten eine Kopie der GNU General Public License zusammen mit diesem
    Programm erhalten haben. Wenn nicht, siehe <https://www.gnu.org/licenses/>.

*/

// include for "exit"
#include <stdlib.h>

// include for "strcpy"
#include <string.h>

// include for "uint8_t"
#include <stdint.h>

// include for "pthread_create"
#include <pthread.h>

// include for "gtk_init"
#include <gtk/gtk.h>

// include for "pow"
#include <math.h>

#include <e9u_LSMD_defs.h>
#include <e9u_LSMD.h>



//! a struct containing all objects to get passed by a pointer to the callback
struct GUI_DATA { GtkWidget      *gtk_window;
                  GtkWidget      *gtk_scale_exp;
                  GtkWidget      *gtk_scale_frame;
                  GtkWidget      *gtk_entry_exp;
                  GtkWidget      *gtk_entry_frame;
                  GtkWidget      *gtk_image_pause;
                  int            i_pause;
                  GtkWidget      *gtk_button_Exp_INT;
                  GtkCssProvider *css_button_Exp_INT;
                  GtkWidget      *gtk_button_Exp_EXT;
                  GtkCssProvider *css_button_Exp_EXT;
                  GtkWidget      *gtk_button_Trig_INT;
                  GtkCssProvider *css_button_Trig_INT;
                  GtkWidget      *gtk_button_Trig_EXT;
                  GtkCssProvider *css_button_Trig_EXT;
                  GtkWidget      *gtk_button_Trig_USB;
                  GtkCssProvider *css_button_Trig_USB;
                  GtkWidget      *gtk_button_Trig_OFF;
                  GtkCssProvider *css_button_Trig_OFF;
                  GtkWidget      *gtk_check_debounce;
                  unsigned int   ui_control_reg_copy;
                  GtkWidget      *gtk_label_frame_count;
                  GtkWidget      *gtk_label_time_stamp;
                  GtkWidget      *gtk_label_fps;
                  GtkWidget      *gtk_label_mean;
                  GtkWidget      *gtk_label_sigma;
                  unsigned int   ui_width;
                  unsigned int   ui_height;
                  GdkPixbuf      *gdk_pixbuf;
                  GtkWidget      *gtk_image;
                  uint8_t        *ui8_pixel;
                  unsigned int   ui_redraw; };

void *read_camera_thread (void *para);
int draw_line (unsigned int ui_x0, unsigned int ui_y0, unsigned int ui_x1, unsigned int ui_y1, unsigned int ui_col, uint8_t *ui8_pixel, unsigned int ui_width);
gboolean idle_callback (gpointer *Pointer);
gboolean scale_exp_changed_callback (GtkWidget *Widget, gpointer *Pointer);
gboolean scale_frame_changed_callback (GtkWidget *Widget, gpointer *Pointer);
gboolean entry_exp_activate_callback (GtkWidget *Widget, gpointer *Pointer);
gboolean entry_frame_activate_callback (GtkWidget *Widget, gpointer *Pointer);
gboolean pause_callback (GtkWidget *Widget, gpointer *Pointer);
gboolean save_callback (GtkWidget *Widget, gpointer *Pointer);
gboolean int_exp_callback (GtkWidget *Widget, gpointer *Pointer);
gboolean ext_exp_callback (GtkWidget *Widget, gpointer *Pointer);
gboolean int_trig_callback (GtkWidget *Widget, gpointer *Pointer);
gboolean ext_trig_callback (GtkWidget *Widget, gpointer *Pointer);
gboolean usb_trig_press_callback (GtkWidget *Widget, GdkEvent *event, gpointer *Pointer);
gboolean usb_trig_release_callback (GtkWidget *Widget, GdkEvent *event, gpointer *Pointer);
gboolean off_trig_callback (GtkWidget *Widget, gpointer *Pointer);
int update_button_colors (struct GUI_DATA *gui_data);
gboolean fullscreen_callback (GtkWidget *Widget, gpointer *Pointer);
gboolean size_allocate_callback (GtkWidget *Widget, GtkAllocation *gtk_alloc, gpointer *Pointer);


int main (int i_argc, char *c_argv[])
{
// pack all neccessary widgets, etc in a struct to pass them as a pointer to the callback
struct GUI_DATA gui_data;
GtkWidget       *gtk_frame;
GtkWidget       *gtk_grid;
GtkWidget       *gtk_grid_status_line;
GtkWidget       *gtk_label_exp;
GtkWidget       *gtk_label_frame;
GtkWidget       *gtk_button_pause;
GtkWidget       *gtk_button_save;
GtkWidget       *gtk_button_fullscreen;
GtkWidget       *gtk_button_quit;
pthread_t       thread;
int             i_status;
int             i_UART;
char            c_dev_name[256];
char            c_string[256];

// initialize GTK and process GTK command line options, i_argc and c_argv will be changed and only include remaining non GTK command line options then:
    gtk_init (&i_argc, &c_argv);

// test UARTs:
    i_UART = 99;
    do {
        sprintf (c_dev_name, "%s%s%d", e9u_LSMD_UART_DIRPREFIX, e9u_LSMD_UART_DEVPREFIX, i_UART);
        i_status = e9u_LSMD_UART_exists (c_dev_name);
        if (i_status == e9u_LSMD_OK) {
            i_status = e9u_LSMD_begin (0, c_dev_name);
            if (i_status == e9u_LSMD_FAIL)
                e9u_LSMD_end (0);
        }
        
        if (i_status == e9u_LSMD_FAIL) {
            --i_UART;
            if (i_UART < 0) {
                printf ("ERROR: did not find any e9u_LSMD camera!\n");
                exit (1);
            }
        }
    } while (i_status == e9u_LSMD_FAIL);

// print camera information:
    printf ("API Version %X, using device %s:\n", e9u_LSMD_API_VERSION, c_dev_name);
    i_status = e9u_LSMD_board_info (0);
    i_status |= e9u_LSMD_eeprom_info (0, e9u_LSMD_SENSOR_BOARD);

// set 100 ms frame time, 10 ms exposure time, 0 s trigger delay
// enable internal timers, send Dark Pixels und Pixels: e9u_LSMD_C0C_DEFAULT = e9u_LSMD_C0C_EXP_INT | e9u_LSMD_C0C_TRIG_INT | e9u_LSMD_C0C_TRIG_DEBOUNCE | e9u_LSMD_C0C_PIX_DARK | e9u_LSMD_C0C_PIX_VALUE | e9u_LSMD_C0C_FILL_DITH
// configure to send Stay-Alive Packages and Timings: e9u_LSMD_GC_DEFAULT = e9u_LSMD_GC_CHANNEL_0 | e9u_LSMD_GC_STAY_ALIVE | e9u_LSMD_GC_SEND_CONF | e9u_LSMD_GC_SEND_TIME
// then update registers and start the camera:
    i_status |= e9u_LSMD_set_reg (0, e9u_LSMD_CH0_FRAME_TIME, 100000);
    i_status |= e9u_LSMD_set_reg (0, e9u_LSMD_CH0_EXP_TIME, 10000);
    i_status |= e9u_LSMD_set_reg (0, e9u_LSMD_CH0_TRIG_DELAY, 0);
    i_status |= e9u_LSMD_set_reg (0, e9u_LSMD_CH0_CONTROL, e9u_LSMD_C0C_DEFAULT);
    i_status |= e9u_LSMD_set_reg (0, e9u_LSMD_GLOBAL_CONTROL, e9u_LSMD_GC_DEFAULT);
    i_status |= e9u_LSMD_update_regs (0);
    if (i_status == e9u_LSMD_FAIL)
        exit (2);

// create a window and callback "exit" if window is destroyed
    gui_data.gtk_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    g_signal_connect (gui_data.gtk_window, "destroy", G_CALLBACK (exit) , NULL);

// create a frame around window:
    sprintf (c_string, " %s ", e9u_LSMD_board_type (0));
    gtk_frame = gtk_frame_new (c_string);

// create a grid:
    gtk_grid = gtk_grid_new ();
    gtk_grid_status_line = gtk_grid_new ();
    gtk_grid_set_column_homogeneous (GTK_GRID(gtk_grid_status_line), TRUE);

// initialize scale and entry for exposure time:
    gui_data.gtk_scale_exp = gtk_scale_new_with_range (GTK_ORIENTATION_HORIZONTAL, 0.01, 100., 0.01);
    gtk_range_set_value (GTK_RANGE(gui_data.gtk_scale_exp), 10.);
    g_signal_connect (gui_data.gtk_scale_exp, "value-changed", G_CALLBACK (scale_exp_changed_callback), (void *)&gui_data);
    gtk_label_exp = gtk_label_new (" exposure time [ms]: ");
    gtk_label_set_xalign (GTK_LABEL (gtk_label_exp), 1.0);

    gui_data.gtk_entry_exp = gtk_entry_new ();
    gtk_entry_set_width_chars (GTK_ENTRY(gui_data.gtk_entry_exp), 8);
    gtk_entry_set_text (GTK_ENTRY(gui_data.gtk_entry_exp), "10.00");
    gtk_entry_set_alignment (GTK_ENTRY(gui_data.gtk_entry_exp), 1.0);
    g_signal_connect (gui_data.gtk_entry_exp, "activate", G_CALLBACK (entry_exp_activate_callback), (void *)&gui_data);

// initialize scale and entry for frame time:
    gui_data.gtk_scale_frame = gtk_scale_new_with_range (GTK_ORIENTATION_HORIZONTAL, 8., 1000., 1.);
    gtk_range_set_value (GTK_RANGE(gui_data.gtk_scale_frame), 100.);
    g_signal_connect (gui_data.gtk_scale_frame, "value-changed", G_CALLBACK (scale_frame_changed_callback), (void *)&gui_data);
    gtk_label_frame = gtk_label_new (" frame time [ms]: ");
    gtk_label_set_xalign (GTK_LABEL (gtk_label_frame), 1.0);

    gui_data.gtk_entry_frame = gtk_entry_new ();
    gtk_entry_set_width_chars (GTK_ENTRY(gui_data.gtk_entry_frame), 8);
    gtk_entry_set_text (GTK_ENTRY(gui_data.gtk_entry_frame), "100.00");
    gtk_entry_set_alignment (GTK_ENTRY(gui_data.gtk_entry_frame), 1.0);
    g_signal_connect (gui_data.gtk_entry_frame, "activate", G_CALLBACK (entry_frame_activate_callback), (void *)&gui_data);

// initialize buttons for exposure and trigger modes:
    gui_data.gtk_button_Exp_INT = gtk_button_new_with_label ("INT");
    g_signal_connect (gui_data.gtk_button_Exp_INT, "clicked", G_CALLBACK (int_exp_callback), (void *)&gui_data);
    gui_data.css_button_Exp_INT = gtk_css_provider_new ();
    gtk_style_context_add_provider (gtk_widget_get_style_context (gui_data.gtk_button_Exp_INT),
                                      GTK_STYLE_PROVIDER (gui_data.css_button_Exp_INT),
                                      GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);

    gui_data.gtk_button_Exp_EXT = gtk_button_new_with_label ("EXT");
    g_signal_connect (gui_data.gtk_button_Exp_EXT, "clicked", G_CALLBACK (ext_exp_callback), (void *)&gui_data);
    gui_data.css_button_Exp_EXT = gtk_css_provider_new ();
    gtk_style_context_add_provider (gtk_widget_get_style_context (gui_data.gtk_button_Exp_EXT),
                                      GTK_STYLE_PROVIDER (gui_data.css_button_Exp_EXT),
                                      GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);

    gui_data.gtk_button_Trig_INT = gtk_button_new_with_label ("INT");
    g_signal_connect (gui_data.gtk_button_Trig_INT, "clicked", G_CALLBACK (int_trig_callback), (void *)&gui_data);
    gui_data.css_button_Trig_INT = gtk_css_provider_new ();
    gtk_style_context_add_provider (gtk_widget_get_style_context (gui_data.gtk_button_Trig_INT),
                                      GTK_STYLE_PROVIDER (gui_data.css_button_Trig_INT),
                                      GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);

    gui_data.gtk_button_Trig_EXT = gtk_button_new_with_label ("EXT");
    g_signal_connect (gui_data.gtk_button_Trig_EXT, "clicked", G_CALLBACK (ext_trig_callback), (void *)&gui_data);
    gui_data.css_button_Trig_EXT = gtk_css_provider_new ();
    gtk_style_context_add_provider (gtk_widget_get_style_context (gui_data.gtk_button_Trig_EXT),
                                      GTK_STYLE_PROVIDER (gui_data.css_button_Trig_EXT),
                                      GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);

    gui_data.gtk_button_Trig_USB = gtk_button_new_with_label ("USB");
    g_signal_connect (gui_data.gtk_button_Trig_USB, "button-press-event", G_CALLBACK (usb_trig_press_callback), (void *)&gui_data);
    g_signal_connect (gui_data.gtk_button_Trig_USB, "button-release-event", G_CALLBACK (usb_trig_release_callback), (void *)&gui_data);
    gui_data.css_button_Trig_USB = gtk_css_provider_new ();
    gtk_style_context_add_provider (gtk_widget_get_style_context (gui_data.gtk_button_Trig_USB),
                                      GTK_STYLE_PROVIDER (gui_data.css_button_Trig_USB),
                                      GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);

    gui_data.gtk_button_Trig_OFF = gtk_button_new_with_label ("OFF");
    g_signal_connect (gui_data.gtk_button_Trig_OFF, "clicked", G_CALLBACK (off_trig_callback), (void *)&gui_data);
    gui_data.css_button_Trig_OFF = gtk_css_provider_new ();
    gtk_style_context_add_provider (gtk_widget_get_style_context (gui_data.gtk_button_Trig_OFF),
                                      GTK_STYLE_PROVIDER (gui_data.css_button_Trig_OFF),
                                      GTK_STYLE_PROVIDER_PRIORITY_APPLICATION);

    gtk_css_provider_load_from_data (GTK_CSS_PROVIDER (gui_data.css_button_Exp_INT),  "*{background-color: #ff7f7f; background-image: none; }",-1,NULL);
    gtk_css_provider_load_from_data (GTK_CSS_PROVIDER (gui_data.css_button_Exp_EXT),  "*{background-color: #ff7f7f; background-image: none; }",-1,NULL);
    gtk_css_provider_load_from_data (GTK_CSS_PROVIDER (gui_data.css_button_Trig_INT), "*{background-color: #ff7f7f; background-image: none; }",-1,NULL);
    gtk_css_provider_load_from_data (GTK_CSS_PROVIDER (gui_data.css_button_Trig_EXT), "*{background-color: #ff7f7f; background-image: none; }",-1,NULL);
    gtk_css_provider_load_from_data (GTK_CSS_PROVIDER (gui_data.css_button_Trig_USB), "*{background-color: #ff7f7f; background-image: none; }",-1,NULL);
    gtk_css_provider_load_from_data (GTK_CSS_PROVIDER (gui_data.css_button_Trig_OFF), "*{background-color: #ff7f7f; background-image: none; }",-1,NULL);
    gui_data.ui_control_reg_copy = 0;

// initalize check button for trigger debounce
    gui_data.gtk_check_debounce = gtk_check_button_new_with_mnemonic ("debounce");
    gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON(gui_data.gtk_check_debounce), TRUE);
    g_signal_connect (gui_data.gtk_check_debounce, "toggled", G_CALLBACK (ext_trig_callback), (void *)&gui_data);

// initialize pause button, callback 
    gui_data.gtk_image_pause = gtk_image_new_from_icon_name ("media-playback-pause", GTK_ICON_SIZE_DIALOG);
    gtk_button_pause = gtk_button_new_with_label (NULL);
    gtk_button_set_image (GTK_BUTTON (gtk_button_pause), gui_data.gtk_image_pause);
    g_signal_connect (gtk_button_pause, "clicked", G_CALLBACK (pause_callback), (void *)&gui_data);
    gui_data.i_pause = 0;

// initialize save button, callback 
    gtk_button_save = gtk_button_new_from_icon_name ("document-save", GTK_ICON_SIZE_DIALOG);
    g_signal_connect (gtk_button_save, "clicked", G_CALLBACK (save_callback), (void *)&gui_data);

// initialize quit button, callback 
    gtk_button_fullscreen = gtk_button_new_from_icon_name ("view-fullscreen", GTK_ICON_SIZE_DIALOG);
    g_signal_connect (gtk_button_fullscreen, "clicked", G_CALLBACK (fullscreen_callback), (void *)&gui_data);

// initialize quit button, callback 
    gtk_button_quit = gtk_button_new_from_icon_name ("process-stop", GTK_ICON_SIZE_DIALOG);
    g_signal_connect (gtk_button_quit, "clicked", G_CALLBACK (exit) , NULL);

// initialize image and set size,
// filling the pixel buffer with black, initaliazing the pixel buffer is done in the callbak
    gui_data.ui_width = 0;
    gui_data.ui_height = 0;
    gui_data.ui_redraw = 0;
    gui_data.ui8_pixel = NULL;
    gui_data.gtk_image = gtk_image_new ();
    gtk_widget_set_hexpand (gui_data.gtk_image, TRUE);
    gtk_widget_set_vexpand (gui_data.gtk_image, TRUE);
    g_signal_connect (gui_data.gtk_image, "size-allocate", G_CALLBACK (size_allocate_callback), (void *)&gui_data);
    gtk_widget_set_size_request (gui_data.gtk_image, 1024, 256);

// labels for frame counter and time stamp:
    gui_data.gtk_label_frame_count = gtk_label_new (" frame no.: ");
    gtk_label_set_xalign (GTK_LABEL (gui_data.gtk_label_frame_count), 0.0);

    gui_data.gtk_label_time_stamp = gtk_label_new (" time stamp: ");
    gtk_label_set_xalign (GTK_LABEL (gui_data.gtk_label_time_stamp), 0.0);

    gui_data.gtk_label_fps = gtk_label_new (" fps: ");
    gtk_label_set_xalign (GTK_LABEL (gui_data.gtk_label_fps), 0.0);

    gui_data.gtk_label_mean = gtk_label_new (" mean: ");
    gtk_label_set_xalign (GTK_LABEL (gui_data.gtk_label_mean), 0.0);

    gui_data.gtk_label_sigma = gtk_label_new (" sigma: ");
    gtk_label_set_xalign (GTK_LABEL (gui_data.gtk_label_sigma), 0.0);

// connect to on-idle function:
    g_idle_add ((GSourceFunc)idle_callback, (void *)&gui_data );

// expand some widgets:
    gtk_widget_set_hexpand (gui_data.gtk_scale_frame, TRUE);
    gtk_widget_set_hexpand (gui_data.gtk_scale_exp, TRUE);

// pack all widgets
    gtk_container_add (GTK_CONTAINER (gui_data.gtk_window), gtk_frame);
    gtk_container_add (GTK_CONTAINER (gtk_frame), gtk_grid);

    gtk_grid_attach (GTK_GRID (gtk_grid), gtk_label_exp, 1, 1, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid), gui_data.gtk_scale_exp, 2, 1, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid), gui_data.gtk_entry_exp, 3, 1, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid), gui_data.gtk_button_Exp_INT, 4, 1, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid), gui_data.gtk_button_Exp_EXT, 5, 1, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid), gui_data.gtk_check_debounce, 6, 1, 2, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid), gtk_button_pause, 8, 1, 1, 2);
    gtk_grid_attach (GTK_GRID (gtk_grid), gtk_button_save, 9, 1, 1, 2);
    gtk_grid_attach (GTK_GRID (gtk_grid), gtk_button_fullscreen, 10, 1, 1, 2);
    gtk_grid_attach (GTK_GRID (gtk_grid), gtk_button_quit, 11, 1, 1, 2);

    gtk_grid_attach (GTK_GRID (gtk_grid), gtk_label_frame, 1, 2, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid), gui_data.gtk_scale_frame, 2, 2, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid), gui_data.gtk_entry_frame, 3, 2, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid), gui_data.gtk_button_Trig_INT, 4, 2, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid), gui_data.gtk_button_Trig_EXT, 5, 2, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid), gui_data.gtk_button_Trig_USB, 6, 2, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid), gui_data.gtk_button_Trig_OFF, 7, 2, 1, 1);

    gtk_grid_attach (GTK_GRID (gtk_grid), gui_data.gtk_image, 1, 3, 11, 1);

    gtk_grid_attach (GTK_GRID (gtk_grid), gtk_grid_status_line, 1, 4, 11, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid_status_line), gui_data.gtk_label_time_stamp, 1, 1, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid_status_line), gui_data.gtk_label_frame_count, 2, 1, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid_status_line), gui_data.gtk_label_fps, 3, 1, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid_status_line), gui_data.gtk_label_mean, 4, 1, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid_status_line), gui_data.gtk_label_sigma, 5, 1, 1, 1);

// show window on screen
    gtk_widget_show_all (gui_data.gtk_window);

// start thread to read camera continuesly:
    pthread_create (&thread, NULL, read_camera_thread, NULL);

// start gtk main loop
    gtk_main ();

// stop camera
    if (e9u_LSMD_end (0) == e9u_LSMD_FAIL)
        exit (3);

    return (0);
}





void *read_camera_thread (void *para)
{
    while (1) {
// read camera:
        if (e9u_LSMD_read_camera (0) == e9u_LSMD_FAIL)
            exit (5);

// send registers to camera, if changed
        if (e9u_LSMD_update_regs (0) == e9u_LSMD_FAIL)
            exit (6);
    }
    
    pthread_exit (NULL);
}



int draw_line (unsigned int ui_x0, unsigned int ui_y0, unsigned int ui_x1, unsigned int ui_y1, unsigned int ui_col, uint8_t *ui8_pixel, unsigned int ui_width)
{
unsigned int ui_position_x;
unsigned int ui_position_y;
double d_counter;
double d_diff_x;
double d_diff_y;
double d_diff_max;

    d_diff_x = (double)ui_x0 - (double)ui_x1;
    d_diff_y = (double)ui_y0 - (double)ui_y1;

    d_diff_max = fabs (d_diff_x);
    if (d_diff_max < fabs (d_diff_y))
        d_diff_max = fabs (d_diff_y);

    if (d_diff_max < 1.)
        d_diff_max = 1.;

    for (d_counter = 0.; d_counter <= 1.; d_counter += 1. / d_diff_max)
    {
        ui_position_x = (double)ui_x0 * d_counter + (double)ui_x1 * (1. - d_counter);
        ui_position_y = (double)ui_y0 * d_counter + (double)ui_y1 * (1. - d_counter);

        ui8_pixel[ui_position_y * ui_width * 3 + ui_position_x * 3 + 0] = (ui_col & 0x00ff0000) >> 16;
        ui8_pixel[ui_position_y * ui_width * 3 + ui_position_x * 3 + 1] = (ui_col & 0x0000ff00) >> 8;
        ui8_pixel[ui_position_y * ui_width * 3 + ui_position_x * 3 + 2] = (ui_col & 0x000000ff);
    }

    return (0);
}







// function to be called if gtk main loop is idle:
gboolean idle_callback (gpointer *Pointer)
{
// make struct from pointer again:
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;
unsigned int        ui_counter_pix;
unsigned int        ui_position_x, ui_position_x_old;
unsigned int        ui_position_y, ui_position_y_old;
static unsigned int ui_frame_counter = 0;
static unsigned int ui_time_stamp = 0;

char                c_string[256];
double              d_mean_dark;
double              d_mean;
double              d_sigma;
double              d_fps;


// update button colors for triger mode
    if (gui_data->ui_control_reg_copy != e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_CONTROL, e9u_LSMD_RX)) {
        gui_data->ui_control_reg_copy = e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_CONTROL, e9u_LSMD_RX);
        update_button_colors (gui_data);
    }    


// copy shadow memory to user memory:
    if (gui_data->i_pause == 0)
        e9u_LSMD_update_memory (0, 0);

// check for new image data:
    if ((ui_frame_counter != e9u_LSMD_get_frame_counter (0, 0)) || (gui_data->ui_redraw == 1)) {
        gui_data->ui_redraw = 0;
        
// reset pixels to black
        memset (gui_data->ui8_pixel, 0, gui_data->ui_width * gui_data->ui_height * 3);

        sprintf (c_string, " frame no.: %u ", e9u_LSMD_get_frame_counter (0, 0));
        gtk_label_set_label (GTK_LABEL(gui_data->gtk_label_frame_count), c_string);

        sprintf (c_string, " time stamp: %.3f ms", 0.001 * e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_T_STAMP_EXP_START, e9u_LSMD_DT));
        gtk_label_set_label (GTK_LABEL(gui_data->gtk_label_time_stamp), c_string);

// draw dark pixels in cyan:
        d_mean_dark = 0.;
        for (ui_counter_pix = 0; ui_counter_pix < e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_DARK_PRE, e9u_LSMD_HOR, e9u_LSMD_RX); ++ui_counter_pix) {

            ui_position_x = ui_counter_pix * gui_data->ui_width 
                          / (e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_DARK_PRE, e9u_LSMD_HOR, e9u_LSMD_RX) + e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX));

            ui_position_y = gui_data->ui_height - 1 
                          - (gui_data->ui_height * e9u_LSMD_get_dark_value (0, 0, ui_counter_pix, 0) / 65536);
                          
            if (ui_counter_pix != 0)
                draw_line (ui_position_x, ui_position_y, ui_position_x_old, ui_position_y_old, 0x00ffff, gui_data->ui8_pixel, gui_data->ui_width);

            ui_position_x_old = ui_position_x;
            ui_position_y_old = ui_position_y;
            d_mean_dark += e9u_LSMD_get_dark_value (0, 0, ui_counter_pix, 0);
        }

// draw dark value in blue:
        d_mean_dark /= e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_DARK_PRE, e9u_LSMD_HOR, e9u_LSMD_RX);
        ui_position_x = e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_DARK_PRE, e9u_LSMD_HOR, e9u_LSMD_RX) * gui_data->ui_width
                      / (e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_DARK_PRE, e9u_LSMD_HOR, e9u_LSMD_RX) + e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX));
        ui_position_y = gui_data->ui_height - 1 
                      - (gui_data->ui_height * d_mean_dark / 65536);
        draw_line (ui_position_x, ui_position_y, gui_data->ui_width - 1, ui_position_y, 0x0000ff, gui_data->ui8_pixel, gui_data->ui_width);


// draw pixels in yellow:
        d_mean = 0.;
        for (ui_counter_pix = 0; ui_counter_pix < e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX); ++ui_counter_pix) {
            ui_position_x = (e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_DARK_PRE, e9u_LSMD_HOR, e9u_LSMD_RX) + ui_counter_pix) * gui_data->ui_width 
                          / (e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_DARK_PRE, e9u_LSMD_HOR, e9u_LSMD_RX) + e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX));

            ui_position_y = gui_data->ui_height - 1 
                          - (gui_data->ui_height * e9u_LSMD_get_pixel_value (0, 0, ui_counter_pix, 0) / 65536);

            if (ui_counter_pix != 0)
                draw_line (ui_position_x, ui_position_y, ui_position_x_old, ui_position_y_old, 0xffff00, gui_data->ui8_pixel, gui_data->ui_width);

            ui_position_x_old = ui_position_x;
            ui_position_y_old = ui_position_y;
            d_mean += e9u_LSMD_get_pixel_value (0, 0, ui_counter_pix, 0);
        }
        

// update status line only with new values
        if (ui_frame_counter != e9u_LSMD_get_frame_counter (0, 0)) {
            d_mean /= e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX);
            sprintf (c_string, " mean: %7.1f ", d_mean - d_mean_dark);
            gtk_label_set_label (GTK_LABEL(gui_data->gtk_label_mean), c_string);

            d_sigma = 0.;
            for (ui_counter_pix = 0; ui_counter_pix < e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX); ++ui_counter_pix) {
                 d_sigma += pow (d_mean - e9u_LSMD_get_pixel_value (0, 0, ui_counter_pix, 0), 2.);
            }
            d_sigma /= e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX) - 1;
            d_sigma = pow (d_sigma, 0.5);
            sprintf (c_string, " sigma: %7.1f ", d_sigma);
            gtk_label_set_label (GTK_LABEL(gui_data->gtk_label_sigma), c_string);

            d_fps = e9u_LSMD_diff32 (e9u_LSMD_get_frame_counter (0, 0), ui_frame_counter);
            d_fps /= e9u_LSMD_diff32 (e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_T_STAMP_EXP_START, e9u_LSMD_DT), ui_time_stamp);
            d_fps *= 1000000;
        
            sprintf (c_string, " fps: %.1f", d_fps);
            gtk_label_set_label (GTK_LABEL(gui_data->gtk_label_fps), c_string);
        }

        ui_frame_counter = e9u_LSMD_get_frame_counter (0, 0);
        ui_time_stamp    = e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_T_STAMP_EXP_START, e9u_LSMD_DT);

// update image from pixel buffer
        gtk_image_set_from_pixbuf (GTK_IMAGE(gui_data->gtk_image), gui_data->gdk_pixbuf);
    }
    else
        e9u_LSMD_SLEEP_ms (1);

    return (TRUE);
}



gboolean scale_exp_changed_callback (GtkWidget *Widget, gpointer *Pointer)
{
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;
unsigned int ui_frame_time;
unsigned int ui_exp_time;
char         c_buffer[256];


    ui_frame_time = gtk_range_get_value (GTK_RANGE(gui_data->gtk_scale_frame)) * 1000;
    
// read scale and set integration time in us, if changed:
    ui_exp_time = gtk_range_get_value (GTK_RANGE(gui_data->gtk_scale_exp)) * 1000;
    if (ui_exp_time > ui_frame_time) {
        ui_exp_time = ui_frame_time;
        gtk_range_set_value (GTK_RANGE(gui_data->gtk_scale_exp), (double)ui_exp_time / 1000.);
    }

    if (ui_exp_time != e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_EXP_TIME, e9u_LSMD_TX))
        if (e9u_LSMD_set_reg (0, e9u_LSMD_CH0_EXP_TIME, ui_exp_time) == e9u_LSMD_FAIL)
            exit (8);

    sprintf (c_buffer, "%1.2f", (double)ui_exp_time / 1000.);
    gtk_entry_set_text (GTK_ENTRY(gui_data->gtk_entry_exp), c_buffer);

    return (TRUE);
}



gboolean scale_frame_changed_callback (GtkWidget *Widget, gpointer *Pointer)
{
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;
unsigned int ui_frame_time;
char         c_buffer[256];


// read scale and set frame time in us, if changed:
    ui_frame_time = gtk_range_get_value (GTK_RANGE(gui_data->gtk_scale_frame)) * 1000;
    if (ui_frame_time != e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_FRAME_TIME, e9u_LSMD_TX)) {
        gtk_range_set_range (GTK_RANGE(gui_data->gtk_scale_exp), 0.01, (double)ui_frame_time / 1000.);
        if (e9u_LSMD_set_reg (0, e9u_LSMD_CH0_FRAME_TIME, ui_frame_time) == e9u_LSMD_FAIL)
            exit (7);
    }

    sprintf (c_buffer, "%1.2f", (double)ui_frame_time / 1000.);
    gtk_entry_set_text (GTK_ENTRY(gui_data->gtk_entry_frame), c_buffer);

    return (TRUE);
}



gboolean entry_exp_activate_callback (GtkWidget *Widget, gpointer *Pointer)
{
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;
double d_exp_time;

    d_exp_time = atof (gtk_entry_get_text (GTK_ENTRY(gui_data->gtk_entry_exp)));
    gtk_range_set_value (GTK_RANGE(gui_data->gtk_scale_exp), d_exp_time);

    return (scale_exp_changed_callback (Widget, Pointer));
}


gboolean entry_frame_activate_callback (GtkWidget *Widget, gpointer *Pointer)
{
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;
double d_frame_time;

    d_frame_time = atof (gtk_entry_get_text (GTK_ENTRY(gui_data->gtk_entry_frame)));
    gtk_range_set_value (GTK_RANGE(gui_data->gtk_scale_frame), d_frame_time);

    return (TRUE);
}


gboolean pause_callback (GtkWidget *Widget, gpointer *Pointer)
{
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;

    if (gui_data->i_pause) {
        gtk_image_set_from_icon_name (GTK_IMAGE (gui_data->gtk_image_pause), "media-playback-pause", GTK_ICON_SIZE_DIALOG);
        gui_data->i_pause = 0;
    } else {
        gtk_image_set_from_icon_name (GTK_IMAGE (gui_data->gtk_image_pause), "media-playback-start", GTK_ICON_SIZE_DIALOG);
        gui_data->i_pause = 1;
    }
            
    return (TRUE);
}





// callback to save camera data as CSV
gboolean save_callback (GtkWidget *Widget, gpointer *Pointer)
{
// restore pointer with pixel data
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;
GtkWidget    *gtk_dialog;
gint         gi_result;
unsigned int ui_counter; 
char         *c_filename;
FILE         *fp_csv_table;

// create a dialog window to choose file name to save to:
    gtk_dialog = gtk_file_chooser_dialog_new ("Save File", GTK_WINDOW(gui_data->gtk_window), GTK_FILE_CHOOSER_ACTION_SAVE, "Cancel", GTK_RESPONSE_CANCEL, "Save", GTK_RESPONSE_ACCEPT, NULL);
    gi_result = gtk_dialog_run (GTK_DIALOG (gtk_dialog));

// if file name is accepted, get file name:
    if (gi_result == GTK_RESPONSE_ACCEPT) {
        GtkFileChooser *chooser = GTK_FILE_CHOOSER (gtk_dialog);
        c_filename = gtk_file_chooser_get_filename (chooser);

// save CSV table:
        fp_csv_table = fopen (c_filename, "wt");
        if (fp_csv_table == NULL) {
            perror ("open csv table");
            exit (4);
        }
        
        for (ui_counter = 0; ui_counter < e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX); ++ui_counter)
            fprintf (fp_csv_table, "%6u,\t%6u\n", ui_counter, e9u_LSMD_get_pixel_value (0, 0, ui_counter, 0));

// close file:
        fclose (fp_csv_table);
        free (c_filename);
    }

// close chooser widget:
    gtk_widget_destroy (gtk_dialog);

    return (TRUE);
}




gboolean int_exp_callback (GtkWidget *Widget, gpointer *Pointer)
{
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;

    gui_data->ui_control_reg_copy = e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_CONTROL, e9u_LSMD_RX);
    gui_data->ui_control_reg_copy |= e9u_LSMD_C0C_EXP_INT;

    if (e9u_LSMD_set_reg (0, e9u_LSMD_CH0_CONTROL, gui_data->ui_control_reg_copy) == e9u_LSMD_FAIL)
        exit (8);

    update_button_colors (gui_data);

    return (TRUE);
}


gboolean ext_exp_callback (GtkWidget *Widget, gpointer *Pointer)
{
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;

    gui_data->ui_control_reg_copy = e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_CONTROL, e9u_LSMD_RX);
    gui_data->ui_control_reg_copy &= ~e9u_LSMD_C0C_EXP_INT;

    if (e9u_LSMD_set_reg (0, e9u_LSMD_CH0_CONTROL, gui_data->ui_control_reg_copy) == e9u_LSMD_FAIL)
        exit (8);

    update_button_colors (gui_data);

    return (TRUE);
}



gboolean int_trig_callback (GtkWidget *Widget, gpointer *Pointer)
{
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;

    gui_data->ui_control_reg_copy = e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_CONTROL, e9u_LSMD_RX);
    gui_data->ui_control_reg_copy |= e9u_LSMD_C0C_TRIG_INT;
    gui_data->ui_control_reg_copy &= ~e9u_LSMD_C0C_TRIG_EXT;
    gui_data->ui_control_reg_copy &= ~e9u_LSMD_C0C_TRIG_USB;

    if (e9u_LSMD_set_reg (0, e9u_LSMD_CH0_CONTROL, gui_data->ui_control_reg_copy) == e9u_LSMD_FAIL)
        exit (8);

    update_button_colors (gui_data);

    return (TRUE);
}



gboolean ext_trig_callback (GtkWidget *Widget, gpointer *Pointer)
{
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;

    gui_data->ui_control_reg_copy = e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_CONTROL, e9u_LSMD_RX);
    gui_data->ui_control_reg_copy &= ~e9u_LSMD_C0C_TRIG_INT;
    gui_data->ui_control_reg_copy |= e9u_LSMD_C0C_TRIG_EXT;
    gui_data->ui_control_reg_copy &= ~e9u_LSMD_C0C_TRIG_USB;

   if (gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(gui_data->gtk_check_debounce)))
      gui_data->ui_control_reg_copy |= e9u_LSMD_C0C_TRIG_DEBOUNCE;
    else
      gui_data->ui_control_reg_copy &= ~e9u_LSMD_C0C_TRIG_DEBOUNCE;

    if (e9u_LSMD_set_reg (0, e9u_LSMD_CH0_CONTROL, gui_data->ui_control_reg_copy) == e9u_LSMD_FAIL)
        exit (8);

    update_button_colors (gui_data);

    return (TRUE);
}



gboolean usb_trig_press_callback (GtkWidget *Widget, GdkEvent *event, gpointer *Pointer)
{
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;

    gui_data->ui_control_reg_copy = e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_CONTROL, e9u_LSMD_RX);
    gui_data->ui_control_reg_copy &= ~e9u_LSMD_C0C_TRIG_INT;
    gui_data->ui_control_reg_copy &= ~e9u_LSMD_C0C_TRIG_EXT;
    gui_data->ui_control_reg_copy |= e9u_LSMD_C0C_TRIG_USB;

    if (e9u_LSMD_set_reg (0, e9u_LSMD_CH0_CONTROL, gui_data->ui_control_reg_copy) == e9u_LSMD_FAIL)
        exit (8);

    update_button_colors (gui_data);

    return (TRUE);
}




gboolean usb_trig_release_callback (GtkWidget *Widget, GdkEvent *event, gpointer *Pointer)
{
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;

    gui_data->ui_control_reg_copy = e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_CONTROL, e9u_LSMD_RX);
    gui_data->ui_control_reg_copy &= ~e9u_LSMD_C0C_TRIG_INT;
    gui_data->ui_control_reg_copy &= ~e9u_LSMD_C0C_TRIG_EXT;
    gui_data->ui_control_reg_copy &= ~e9u_LSMD_C0C_TRIG_USB;

    if (e9u_LSMD_set_reg (0, e9u_LSMD_CH0_CONTROL, gui_data->ui_control_reg_copy) == e9u_LSMD_FAIL)
        exit (8);

    update_button_colors (gui_data);

    return (TRUE);
}




gboolean off_trig_callback (GtkWidget *Widget, gpointer *Pointer)
{
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;

    gui_data->ui_control_reg_copy = e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_CONTROL, e9u_LSMD_RX);
    gui_data->ui_control_reg_copy &= ~e9u_LSMD_C0C_TRIG_INT;
    gui_data->ui_control_reg_copy &= ~e9u_LSMD_C0C_TRIG_EXT;
    gui_data->ui_control_reg_copy &= ~e9u_LSMD_C0C_TRIG_USB;

    if (e9u_LSMD_set_reg (0, e9u_LSMD_CH0_CONTROL, gui_data->ui_control_reg_copy) == e9u_LSMD_FAIL)
        exit (8);

    update_button_colors (gui_data);

    return (TRUE);
}




int update_button_colors (struct GUI_DATA *gui_data)
{        
    if (gui_data->ui_control_reg_copy & e9u_LSMD_C0C_EXP_INT) {
        gtk_css_provider_load_from_data (GTK_CSS_PROVIDER (gui_data->css_button_Exp_INT),  "*{background-color: #7fff7f; background-image: none; }",-1,NULL);
        gtk_css_provider_load_from_data (GTK_CSS_PROVIDER (gui_data->css_button_Exp_EXT),  "*{background-color: #ff7f7f; background-image: none; }",-1,NULL);
    } else {
        gtk_css_provider_load_from_data (GTK_CSS_PROVIDER (gui_data->css_button_Exp_INT),  "*{background-color: #ff7f7f; background-image: none; }",-1,NULL);
        gtk_css_provider_load_from_data (GTK_CSS_PROVIDER (gui_data->css_button_Exp_EXT),  "*{background-color: #7fff7f; background-image: none; }",-1,NULL);
    }

    if (gui_data->ui_control_reg_copy & e9u_LSMD_C0C_TRIG_INT) {
        if (gui_data->ui_control_reg_copy & e9u_LSMD_C0C_EXPOSURE)
            gtk_css_provider_load_from_data (GTK_CSS_PROVIDER (gui_data->css_button_Trig_INT),  "*{background-color: #ffff7f; background-image: none; }",-1,NULL);
        else
            gtk_css_provider_load_from_data (GTK_CSS_PROVIDER (gui_data->css_button_Trig_INT),  "*{background-color: #7fff7f; background-image: none; }",-1,NULL);
    } else
        gtk_css_provider_load_from_data (GTK_CSS_PROVIDER (gui_data->css_button_Trig_INT),  "*{background-color: #ff7f7f; background-image: none; }",-1,NULL);

    if (gui_data->ui_control_reg_copy & e9u_LSMD_C0C_TRIG_EXT) {
        if (gui_data->ui_control_reg_copy & e9u_LSMD_C0C_EXPOSURE)
            gtk_css_provider_load_from_data (GTK_CSS_PROVIDER (gui_data->css_button_Trig_EXT),  "*{background-color: #ffff7f; background-image: none; }",-1,NULL);
        else
            gtk_css_provider_load_from_data (GTK_CSS_PROVIDER (gui_data->css_button_Trig_EXT),  "*{background-color: #7fff7f; background-image: none; }",-1,NULL);
    } else
        gtk_css_provider_load_from_data (GTK_CSS_PROVIDER (gui_data->css_button_Trig_EXT),  "*{background-color: #ff7f7f; background-image: none; }",-1,NULL);
                    

    if (gui_data->ui_control_reg_copy & e9u_LSMD_C0C_TRIG_USB) {
        if (gui_data->ui_control_reg_copy & e9u_LSMD_C0C_EXPOSURE)
            gtk_css_provider_load_from_data (GTK_CSS_PROVIDER (gui_data->css_button_Trig_USB),  "*{background-color: #ffff7f; background-image: none; }",-1,NULL);
        else
            gtk_css_provider_load_from_data (GTK_CSS_PROVIDER (gui_data->css_button_Trig_USB),  "*{background-color: #7fff7f; background-image: none; }",-1,NULL);
    } else 
        gtk_css_provider_load_from_data (GTK_CSS_PROVIDER (gui_data->css_button_Trig_USB),  "*{background-color: #ff7f7f; background-image: none; }",-1,NULL);


    if (gui_data->ui_control_reg_copy & (e9u_LSMD_C0C_TRIG_INT | e9u_LSMD_C0C_TRIG_EXT | e9u_LSMD_C0C_TRIG_USB))
        gtk_css_provider_load_from_data (GTK_CSS_PROVIDER (gui_data->css_button_Trig_OFF),  "*{background-color: #ff7f7f; background-image: none; }",-1,NULL);
    else {
        if (gui_data->ui_control_reg_copy & e9u_LSMD_C0C_EXPOSURE)
            gtk_css_provider_load_from_data (GTK_CSS_PROVIDER (gui_data->css_button_Trig_OFF),  "*{background-color: #ffff7f; background-image: none; }",-1,NULL);
        else
            gtk_css_provider_load_from_data (GTK_CSS_PROVIDER (gui_data->css_button_Trig_OFF),  "*{background-color: #7fff7f; background-image: none; }",-1,NULL);
    }
 
    return (0);
}


gboolean fullscreen_callback (GtkWidget *Widget, gpointer *Pointer)
{
// restore pointer with pixel data
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;

    gtk_window_fullscreen (GTK_WINDOW (gui_data->gtk_window));
    
    return (TRUE);
}



// callback to configure pixbuf
gboolean size_allocate_callback (GtkWidget *Widget, GtkAllocation *gtk_alloc, gpointer *Pointer)
{
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;

    if ( (gui_data->ui_width  != gtk_alloc->width)
      || (gui_data->ui_height != gtk_alloc->height) )
    {
        gui_data->ui_width  = gtk_alloc->width;
        gui_data->ui_height = gtk_alloc->height;

        if (gui_data->ui8_pixel != NULL) {
           g_object_unref (gui_data->gdk_pixbuf);
           free (gui_data->ui8_pixel);
        }

        gui_data->ui8_pixel = malloc (gui_data->ui_width * gui_data->ui_height * 3 * sizeof (char));
        memset (gui_data->ui8_pixel, 0, gui_data->ui_width * gui_data->ui_height * 3);
        gui_data->gdk_pixbuf = gdk_pixbuf_new_from_data (gui_data->ui8_pixel, GDK_COLORSPACE_RGB, FALSE, 8, gui_data->ui_width, gui_data->ui_height, gui_data->ui_width * 3, NULL, NULL);
        gtk_image_set_from_pixbuf (GTK_IMAGE(gui_data->gtk_image), gui_data->gdk_pixbuf);
        gui_data->ui_redraw = 1;
    }

    return (TRUE);
}
