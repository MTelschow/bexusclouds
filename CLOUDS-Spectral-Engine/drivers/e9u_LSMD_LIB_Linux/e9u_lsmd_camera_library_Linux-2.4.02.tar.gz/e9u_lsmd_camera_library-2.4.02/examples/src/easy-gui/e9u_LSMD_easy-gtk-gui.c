/*
    EURECA's e9u_LSMD camera software – connect to a e9u_LSMD camera USB module
    Copyright (C) 2020 Eureca Messtechnik GmbH, <info@eureca.de>

	This file is part of EURECA's e9u_LSMD camera software.

	EURECA's e9u_LSMD camera software is free software: you can redistribute
	it and/or modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation, either
	version 3 of the License, or (at your option) any later version.

	EURECA's e9u_LSMD camera software is distributed in the hope that it
	will be useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
	See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
	along with Foobar.  If not, see <http://www.gnu.org/licenses/>.



    Diese Datei ist Teil von EURECAs e9u_LSMD Kamera-Software.

	EURECAs e9u_LSMD Kamera-Software ist Freie Software: Sie können sie
	unter den Bedingungen der GNU Lesser General Public License, wie von
	der Free Software Foundation, Version 3 der Lizenz oder (nach Ihrer
	Wahl) jeder neueren veröffentlichten Version, weiter verteilen
	und/oder modifizieren.

	EURECAs e9u_LSMD Kamera-Software wird in der Hoffnung, dass es nützlich
	sein wird, aber OHNE JEDE GEWÄHRLEISTUNG, bereitgestellt; sogar ohne
	die implizite Gewährleistung der MARKTFÄHIGKEIT oder EIGNUNG FÜR
	EINEN BESTIMMTEN ZWECK.  Siehe die GNU General Public License für
	weitere Details.

    Sie sollten eine Kopie der GNU General Public License zusammen mit diesem
    Programm erhalten haben. Wenn nicht, siehe <https://www.gnu.org/licenses/>.

*/

// include for "exit"
#include <stdlib.h>

// include for "strcpy"
#include <string.h>

// include for "uint8_t" "uint16_t" and "uint32_t"
#include <stdint.h>

// include for "gtk_init"
#include <gtk/gtk.h>


#include <e9u_LSMD_defs.h>
#include <e9u_LSMD.h>



// a struct containing all objects to get passed by a pointer to the callback
struct GUI_DATA { GtkWidget *gtk_window;
                  GtkWidget *gtk_scale_exp;
                  GtkWidget *gtk_scale_frame;
                  GdkPixbuf *gdk_pixbuf;
                  GtkWidget *gtk_image;
                  uint8_t   ui8_pixel[256][1024][3]; };

gboolean idle_callback (gpointer *Pointer);
gboolean scale_exp_changed_callback (GtkWidget *Widget, gpointer *Pointer);
gboolean save_callback (GtkWidget *Widget, gpointer *Pointer);





int main (int i_argc, char *c_argv[])
{
// pack all neccessary widgets, etc in a struct to pass them as a pointer to the callback
struct GUI_DATA gui_data;
GtkWidget       *gtk_frame;
GtkWidget       *gtk_grid;
GtkWidget       *gtk_label_exp;
GtkWidget       *gtk_label_frame;
GtkWidget       *gtk_button_save;
int             i_status;
int             i_UART;
char            c_dev_name[256];
char            c_string[256];

// initialize GTK and process GTK command line options, i_argc and c_argv will be changed and only include remaining non GTK command line options then:
    gtk_init (&i_argc, &c_argv);

// test UARTs:
    i_UART = 99;
    do {
        sprintf (c_dev_name, "%s%s%d", e9u_LSMD_UART_DIRPREFIX, e9u_LSMD_UART_DEVPREFIX, i_UART);
        i_status = e9u_LSMD_UART_exists (c_dev_name);
        if (i_status == e9u_LSMD_OK) {
            i_status = e9u_LSMD_begin (0, c_dev_name);
            if (i_status == e9u_LSMD_FAIL)
                e9u_LSMD_end (0);
        }
        
        if (i_status == e9u_LSMD_FAIL) {
            --i_UART;
            if (i_UART < 0) {
                printf ("ERROR: did not find any e9u_LSMD camera!\n");
                exit (1);
            }
        }
    } while (i_status == e9u_LSMD_FAIL);

// print camera information:
    printf ("API Version %X, using device %s:\n", e9u_LSMD_API_VERSION, c_dev_name);
    i_status = e9u_LSMD_board_info (0);
    i_status |= e9u_LSMD_eeprom_info (0, e9u_LSMD_SENSOR_BOARD);

// set 40 ms frame time, 10 ms exposure time, 0 s trigger delay
// enable internal timers, send Dark Pixels und Pixels: e9u_LSMD_C0C_DEFAULT = e9u_LSMD_C0C_EXP_INT | e9u_LSMD_C0C_TRIG_INT | e9u_LSMD_C0C_TRIG_DEBOUNCE | e9u_LSMD_C0C_PIX_DARK | e9u_LSMD_C0C_PIX_VALUE | e9u_LSMD_C0C_FILL_DITH
// configure to send Stay-Alive Packages and Timings: e9u_LSMD_GC_DEFAULT = e9u_LSMD_GC_CHANNEL_0 | e9u_LSMD_GC_STAY_ALIVE | e9u_LSMD_GC_SEND_CONF | e9u_LSMD_GC_SEND_TIME
// then update registers and start the camera:
    i_status |= e9u_LSMD_set_reg (0, e9u_LSMD_CH0_FRAME_TIME, 100000);
    i_status |= e9u_LSMD_set_reg (0, e9u_LSMD_CH0_EXP_TIME, 10000);
    i_status |= e9u_LSMD_set_reg (0, e9u_LSMD_CH0_TRIG_DELAY, 0);
    i_status |= e9u_LSMD_set_reg (0, e9u_LSMD_CH0_CONTROL, e9u_LSMD_C0C_DEFAULT);
    i_status |= e9u_LSMD_set_reg (0, e9u_LSMD_GLOBAL_CONTROL, e9u_LSMD_GC_DEFAULT);
    i_status |= e9u_LSMD_update_regs (0);
    if (i_status == e9u_LSMD_FAIL)
        exit (2);

// create a window and callback "exit" if window is destroyed
    gui_data.gtk_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    g_signal_connect (gui_data.gtk_window, "destroy", G_CALLBACK (exit) , NULL);

// create a frame around window:
    sprintf (c_string, " %s ", e9u_LSMD_board_type (0));
    gtk_frame = gtk_frame_new (c_string);

// create vbox and add into window
    gtk_grid = gtk_grid_new ();

// initialize scale for integration time and frame time
    gui_data.gtk_scale_frame = gtk_scale_new_with_range (GTK_ORIENTATION_HORIZONTAL, 8., 1000., 1.);
    gtk_range_set_value (GTK_RANGE(gui_data.gtk_scale_frame), 100.);
    g_signal_connect (gui_data.gtk_scale_frame, "value-changed", G_CALLBACK (scale_exp_changed_callback), (void *)&gui_data);
    gtk_label_frame = gtk_label_new (" frame time [ms]: ");
    gtk_label_set_xalign (GTK_LABEL (gtk_label_frame), 1.0);

    gui_data.gtk_scale_exp = gtk_scale_new_with_range (GTK_ORIENTATION_HORIZONTAL, 0.01, 100., 0.01);
    gtk_range_set_value (GTK_RANGE(gui_data.gtk_scale_exp), 10.);
    g_signal_connect (gui_data.gtk_scale_exp, "value-changed", G_CALLBACK (scale_exp_changed_callback), (void *)&gui_data);
    gtk_label_exp = gtk_label_new (" exposure time [ms]: ");
    gtk_label_set_xalign (GTK_LABEL (gtk_label_exp), 1.0);

// initialize button, callback (passes pointer onto pixel values)
    gtk_button_save = gtk_button_new_with_label ("save as CSV");
    g_signal_connect (gtk_button_save, "clicked", G_CALLBACK (save_callback), (void *)&gui_data);

// fill the pixel buffer with black, initalize pixel buffer, use as image und pack into vbox:
    memset (gui_data.ui8_pixel, 0, 1024 * 256 * 3);
    gui_data.gdk_pixbuf = gdk_pixbuf_new_from_data (gui_data.ui8_pixel[0][0], GDK_COLORSPACE_RGB, FALSE, 8, 1024, 256, 1024 * 3, NULL, NULL);
    gui_data.gtk_image = gtk_image_new_from_pixbuf (gui_data.gdk_pixbuf);

// connect to on-idle function:
    g_idle_add ((GSourceFunc)idle_callback, (void *)&gui_data );

// expand some widgets:
    gtk_widget_set_hexpand (gui_data.gtk_scale_frame, TRUE);
    gtk_widget_set_hexpand (gui_data.gtk_scale_exp, TRUE);

// pack all widgets
    gtk_container_add (GTK_CONTAINER (gui_data.gtk_window), gtk_frame);
    gtk_container_add (GTK_CONTAINER (gtk_frame), gtk_grid);
    
    gtk_grid_attach (GTK_GRID (gtk_grid), gtk_label_exp, 1, 1, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid), gui_data.gtk_scale_exp, 2, 1, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid), gtk_button_save, 3, 1, 1, 2);

    gtk_grid_attach (GTK_GRID (gtk_grid), gtk_label_frame, 1, 2, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid), gui_data.gtk_scale_frame, 2, 2, 1, 1);

    gtk_grid_attach (GTK_GRID (gtk_grid), gui_data.gtk_image, 1, 3, 3, 1);

// show window on screen
    gtk_widget_show_all (gui_data.gtk_window);

// start gtk main loop
    gtk_main ();

// stop camera
    if (e9u_LSMD_end (0) == e9u_LSMD_FAIL)
        exit (3);

    return (0);
}





// function to be called if gtk main loop is idle:
gboolean idle_callback (gpointer *Pointer)
{
// make struct from pointer again:
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;
uint16_t        ui16_counter_pix;
uint16_t        ui16_position_x;
uint16_t        ui16_position_y;

    if (e9u_LSMD_read_camera (0) == e9u_LSMD_FAIL)
        exit (5);

// send registers to camera, if changed
    if (e9u_LSMD_update_regs (0) == e9u_LSMD_FAIL)
        exit (6);

// check for new frame:
    if (e9u_LSMD_check_new_frames (0, 0)) {
    
// copy shadow memory to user memory:
        e9u_LSMD_update_memory (0, 0);

// reset pixels to black, then draw pixels: calculate pixel position and set pixel to yellow:
        memset (gui_data->ui8_pixel, 0, 1024 * 256 * 3);
        for (ui16_counter_pix = 0; ui16_counter_pix < e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX); ++ui16_counter_pix) {
            ui16_position_x = ui16_counter_pix * 1024 / e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX);
            ui16_position_y = 255 - (e9u_LSMD_get_pixel_value (0, 0, ui16_counter_pix, 0) >> 8);
            gui_data->ui8_pixel[ui16_position_y][ui16_position_x][0] = 255;
            gui_data->ui8_pixel[ui16_position_y][ui16_position_x][1] = 255;
        }

// update image from pixel buffer
        gtk_image_set_from_pixbuf (GTK_IMAGE(gui_data->gtk_image), gui_data->gdk_pixbuf);
    }

    return (TRUE);
}





gboolean scale_exp_changed_callback (GtkWidget *Widget, gpointer *Pointer)
{
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;
uint32_t        ui32_frame_time;
uint32_t        ui32_exp_time;


// read scale and set frame time in us, if changed:
    ui32_frame_time = gtk_range_get_value (GTK_RANGE(gui_data->gtk_scale_frame)) * 1000;
    if (ui32_frame_time != e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_FRAME_TIME, e9u_LSMD_TX)) {
        gtk_range_set_range (GTK_RANGE(gui_data->gtk_scale_exp), 0.01, (double)ui32_frame_time / 1000.);
        if (e9u_LSMD_set_reg (0, e9u_LSMD_CH0_FRAME_TIME, ui32_frame_time) == e9u_LSMD_FAIL)
            exit (7);
    }
    
// read scale and set integration time in us, if changed:
    ui32_exp_time = gtk_range_get_value (GTK_RANGE(gui_data->gtk_scale_exp)) * 1000;
    if (ui32_exp_time > ui32_frame_time) {
        ui32_exp_time = ui32_frame_time;
        gtk_range_set_value (GTK_RANGE(gui_data->gtk_scale_exp), (double)ui32_exp_time / 1000.);
    }

    if (ui32_exp_time != e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_EXP_TIME, e9u_LSMD_TX))
        if (e9u_LSMD_set_reg (0, e9u_LSMD_CH0_EXP_TIME, ui32_exp_time) == e9u_LSMD_FAIL)
            exit (8);

    return (TRUE);
}





// callback to save camera data as CSV
gboolean save_callback (GtkWidget *Widget, gpointer *Pointer)
{
// restore pointer with pixel data
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;
GtkWidget *gtk_dialog;
gint      gi_result;
uint16_t  ui16_counter; 
char      *c_filename;
FILE      *fp_csv_table;

// create a dialog window to choose file name to save to:
    gtk_dialog = gtk_file_chooser_dialog_new ("Save File", GTK_WINDOW(gui_data->gtk_window), GTK_FILE_CHOOSER_ACTION_SAVE, "Cancel", GTK_RESPONSE_CANCEL, "Save", GTK_RESPONSE_ACCEPT, NULL);
    gi_result = gtk_dialog_run (GTK_DIALOG (gtk_dialog));

// if file name is accepted, get file name:
    if (gi_result == GTK_RESPONSE_ACCEPT) {
        GtkFileChooser *chooser = GTK_FILE_CHOOSER (gtk_dialog);
        c_filename = gtk_file_chooser_get_filename (chooser);

// save CSV table:
        fp_csv_table = fopen (c_filename, "wt");
        if (fp_csv_table == NULL) {
            perror ("open csv table");
            exit (4);
        }
        
        for (ui16_counter = 0; ui16_counter < e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX); ++ui16_counter)
            fprintf (fp_csv_table, "%6u,\t%6u\n", ui16_counter, e9u_LSMD_get_pixel_value (0, 0, ui16_counter, 0));

// close file:
        fclose (fp_csv_table);
        free (c_filename);
    }

// close chooser widget:
    gtk_widget_destroy (gtk_dialog);
    
    return (TRUE);
}
