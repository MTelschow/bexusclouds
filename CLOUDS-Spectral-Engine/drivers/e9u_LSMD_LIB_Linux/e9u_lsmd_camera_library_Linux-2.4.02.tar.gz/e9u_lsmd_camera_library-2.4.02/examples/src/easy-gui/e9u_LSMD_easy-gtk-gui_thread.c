/*
    EURECA's e9u_LSMD camera software – connect to a e9u_LSMD camera USB module
    Copyright (C) 2020 Eureca Messtechnik GmbH, <info@eureca.de>

	This file is part of EURECA's e9u_LSMD camera software.

	EURECA's e9u_LSMD camera software is free software: you can redistribute
	it and/or modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation, either
	version 3 of the License, or (at your option) any later version.

	EURECA's e9u_LSMD camera software is distributed in the hope that it
	will be useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
	See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
	along with Foobar.  If not, see <http://www.gnu.org/licenses/>.



    Diese Datei ist Teil von EURECAs e9u_LSMD Kamera-Software.

	EURECAs e9u_LSMD Kamera-Software ist Freie Software: Sie können sie
	unter den Bedingungen der GNU Lesser General Public License, wie von
	der Free Software Foundation, Version 3 der Lizenz oder (nach Ihrer
	Wahl) jeder neueren veröffentlichten Version, weiter verteilen
	und/oder modifizieren.

	EURECAs e9u_LSMD Kamera-Software wird in der Hoffnung, dass es nützlich
	sein wird, aber OHNE JEDE GEWÄHRLEISTUNG, bereitgestellt; sogar ohne
	die implizite Gewährleistung der MARKTFÄHIGKEIT oder EIGNUNG FÜR
	EINEN BESTIMMTEN ZWECK.  Siehe die GNU General Public License für
	weitere Details.

    Sie sollten eine Kopie der GNU General Public License zusammen mit diesem
    Programm erhalten haben. Wenn nicht, siehe <https://www.gnu.org/licenses/>.

*/

// include for "exit"
#include <stdlib.h>

// include for "strcpy"
#include <string.h>

// include for "uint8_t"
#include <stdint.h>

// include for "pthread_create"
#include <pthread.h>

// include for "gtk_init"
#include <gtk/gtk.h>

// include for "pow"
#include <math.h>

#include <e9u_LSMD_defs.h>
#include <e9u_LSMD.h>



//! a struct containing all objects to get passed by a pointer to the callback
struct GUI_DATA { GtkWidget *gtk_window;
                  GtkWidget *gtk_scale_exp;
                  GtkWidget *gtk_scale_frame;
                  GtkWidget *gtk_image_pause;
                  int       i_pause;
                  GtkWidget *gtk_label_frame_count;
                  GtkWidget *gtk_label_time_stamp;
                  GtkWidget *gtk_label_fps;
                  GtkWidget *gtk_label_mean;
                  GtkWidget *gtk_label_sigma;
                  GdkPixbuf *gdk_pixbuf;
                  GtkWidget *gtk_image;
                  uint8_t   ui8_pixel[256][1024][3]; };

void *read_camera_thread (void *para);
gboolean idle_callback (gpointer *Pointer);
gboolean scale_changed_callback (GtkWidget *Widget, gpointer *Pointer);
gboolean pause_callback (GtkWidget *Widget, gpointer *Pointer);
gboolean save_callback (GtkWidget *Widget, gpointer *Pointer);




int main (int i_argc, char *c_argv[])
{
// pack all neccessary widgets, etc in a struct to pass them as a pointer to the callback
struct GUI_DATA gui_data;
GtkWidget       *gtk_frame;
GtkWidget       *gtk_grid;
GtkWidget       *gtk_grid_status_line;
GtkWidget       *gtk_label_exp;
GtkWidget       *gtk_label_frame;
GtkWidget       *gtk_button_pause;
GtkWidget       *gtk_button_save;
GtkWidget       *gtk_button_quit;
pthread_t       thread;
int             i_status;
int             i_UART;
char            c_dev_name[256];
char            c_string[256];

// initialize GTK and process GTK command line options, i_argc and c_argv will be changed and only include remaining non GTK command line options then:
    gtk_init (&i_argc, &c_argv);

// test UARTs:
    i_UART = 99;
    do {
        sprintf (c_dev_name, "%s%s%d", e9u_LSMD_UART_DIRPREFIX, e9u_LSMD_UART_DEVPREFIX, i_UART);
        i_status = e9u_LSMD_UART_exists (c_dev_name);
        if (i_status == e9u_LSMD_OK) {
            i_status = e9u_LSMD_begin (0, c_dev_name);
            if (i_status == e9u_LSMD_FAIL)
                e9u_LSMD_end (0);
        }
        
        if (i_status == e9u_LSMD_FAIL) {
            --i_UART;
            if (i_UART < 0) {
                printf ("ERROR: did not find any e9u_LSMD camera!\n");
                exit (1);
            }
        }
    } while (i_status == e9u_LSMD_FAIL);

// print camera information:
    printf ("API Version %X, using device %s:\n", e9u_LSMD_API_VERSION, c_dev_name);
    i_status = e9u_LSMD_board_info (0);
    i_status |= e9u_LSMD_eeprom_info (0, e9u_LSMD_SENSOR_BOARD);

// set 100 ms frame time, 10 ms exposure time, 0 s trigger delay
// enable internal timers, send Dark Pixels und Pixels: e9u_LSMD_C0C_DEFAULT = e9u_LSMD_C0C_EXP_INT | e9u_LSMD_C0C_TRIG_INT | e9u_LSMD_C0C_TRIG_DEBOUNCE | e9u_LSMD_C0C_PIX_DARK | e9u_LSMD_C0C_PIX_VALUE | e9u_LSMD_C0C_FILL_DITH
// configure to send Stay-Alive Packages and Timings: e9u_LSMD_GC_DEFAULT = e9u_LSMD_GC_CHANNEL_0 | e9u_LSMD_GC_STAY_ALIVE | e9u_LSMD_GC_SEND_CONF | e9u_LSMD_GC_SEND_TIME
// then update registers and start the camera:
    i_status |= e9u_LSMD_set_reg (0, e9u_LSMD_CH0_FRAME_TIME, 100000);
    i_status |= e9u_LSMD_set_reg (0, e9u_LSMD_CH0_EXP_TIME, 10000);
    i_status |= e9u_LSMD_set_reg (0, e9u_LSMD_CH0_TRIG_DELAY, 0);
    i_status |= e9u_LSMD_set_reg (0, e9u_LSMD_CH0_CONTROL, e9u_LSMD_C0C_DEFAULT);
    i_status |= e9u_LSMD_set_reg (0, e9u_LSMD_GLOBAL_CONTROL, e9u_LSMD_GC_DEFAULT);
    i_status |= e9u_LSMD_update_regs (0);
    if (i_status == e9u_LSMD_FAIL)
        exit (2);

// create a window and callback "exit" if window is destroyed
    gui_data.gtk_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    g_signal_connect (gui_data.gtk_window, "destroy", G_CALLBACK (exit) , NULL);

// create a frame around window:
    sprintf (c_string, " %s ", e9u_LSMD_board_type (0));
    gtk_frame = gtk_frame_new (c_string);

// create a grid:
    gtk_grid = gtk_grid_new ();
    gtk_grid_status_line = gtk_grid_new ();
    gtk_grid_set_column_homogeneous (GTK_GRID(gtk_grid_status_line), TRUE);

// initialize scale for integration time and frame time
    gui_data.gtk_scale_frame = gtk_scale_new_with_range (GTK_ORIENTATION_HORIZONTAL, 8., 1000., 1.);
    gtk_range_set_value (GTK_RANGE(gui_data.gtk_scale_frame), 100.);
    g_signal_connect (gui_data.gtk_scale_frame, "value-changed", G_CALLBACK (scale_changed_callback), (void *)&gui_data);
    gtk_label_frame = gtk_label_new (" frame time [ms]: ");
    gtk_label_set_xalign (GTK_LABEL (gtk_label_frame), 1.0);

    gui_data.gtk_scale_exp = gtk_scale_new_with_range (GTK_ORIENTATION_HORIZONTAL, 0.01, 100., 0.01);
    gtk_range_set_value (GTK_RANGE(gui_data.gtk_scale_exp), 10.);
    g_signal_connect (gui_data.gtk_scale_exp, "value-changed", G_CALLBACK (scale_changed_callback), (void *)&gui_data);
    gtk_label_exp = gtk_label_new (" exposure time [ms]: ");
    gtk_label_set_xalign (GTK_LABEL (gtk_label_exp), 1.0);

// initialize pause button, callback 
    gui_data.gtk_image_pause = gtk_image_new_from_icon_name ("media-playback-pause", GTK_ICON_SIZE_DIALOG);
    gtk_button_pause = gtk_button_new_with_label (NULL);
    gtk_button_set_image (GTK_BUTTON (gtk_button_pause), gui_data.gtk_image_pause);
    g_signal_connect (gtk_button_pause, "clicked", G_CALLBACK (pause_callback), (void *)&gui_data);
    gui_data.i_pause = 0;

// initialize save button, callback 
    gtk_button_save = gtk_button_new_from_icon_name ("document-save", GTK_ICON_SIZE_DIALOG);
    g_signal_connect (gtk_button_save, "clicked", G_CALLBACK (save_callback), (void *)&gui_data);

// initialize quit button, callback 
    gtk_button_quit = gtk_button_new_from_icon_name ("process-stop", GTK_ICON_SIZE_DIALOG);
    g_signal_connect (gtk_button_quit, "clicked", G_CALLBACK (exit) , NULL);


// fill the pixel buffer with black, initalize pixel buffer, use as image und pack into vbox:
    memset (gui_data.ui8_pixel, 0, 1024 * 256 * 3);
    gui_data.gdk_pixbuf = gdk_pixbuf_new_from_data (gui_data.ui8_pixel[0][0], GDK_COLORSPACE_RGB, FALSE, 8, 1024, 256, 1024 * 3, NULL, NULL);
    gui_data.gtk_image = gtk_image_new_from_pixbuf (gui_data.gdk_pixbuf);

// labels for frame counter and time stamp:
    gui_data.gtk_label_frame_count = gtk_label_new (" frame no.: ");
    gtk_label_set_xalign (GTK_LABEL (gui_data.gtk_label_frame_count), 0.0);

    gui_data.gtk_label_time_stamp = gtk_label_new (" time stamp: ");
    gtk_label_set_xalign (GTK_LABEL (gui_data.gtk_label_time_stamp), 0.0);

    gui_data.gtk_label_fps = gtk_label_new (" fps: ");
    gtk_label_set_xalign (GTK_LABEL (gui_data.gtk_label_fps), 0.0);

    gui_data.gtk_label_mean = gtk_label_new (" mean: ");
    gtk_label_set_xalign (GTK_LABEL (gui_data.gtk_label_mean), 0.0);

    gui_data.gtk_label_sigma = gtk_label_new (" sigma: ");
    gtk_label_set_xalign (GTK_LABEL (gui_data.gtk_label_sigma), 0.0);

// connect to on-idle function:
    g_idle_add ((GSourceFunc)idle_callback, (void *)&gui_data );

// expand some widgets:
    gtk_widget_set_hexpand (gui_data.gtk_scale_frame, TRUE);
    gtk_widget_set_hexpand (gui_data.gtk_scale_exp, TRUE);

// pack all widgets
    gtk_container_add (GTK_CONTAINER (gui_data.gtk_window), gtk_frame);
    gtk_container_add (GTK_CONTAINER (gtk_frame), gtk_grid);

    gtk_grid_attach (GTK_GRID (gtk_grid), gtk_label_exp, 1, 1, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid), gui_data.gtk_scale_exp, 2, 1, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid), gtk_button_pause, 3, 1, 1, 2);
    gtk_grid_attach (GTK_GRID (gtk_grid), gtk_button_save, 4, 1, 1, 2);
    gtk_grid_attach (GTK_GRID (gtk_grid), gtk_button_quit, 5, 1, 1, 2);

    gtk_grid_attach (GTK_GRID (gtk_grid), gtk_label_frame, 1, 2, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid), gui_data.gtk_scale_frame, 2, 2, 1, 1);

    gtk_grid_attach (GTK_GRID (gtk_grid), gui_data.gtk_image, 1, 3, 5, 1);

    gtk_grid_attach (GTK_GRID (gtk_grid), gtk_grid_status_line, 1, 4, 5, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid_status_line), gui_data.gtk_label_time_stamp, 1, 1, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid_status_line), gui_data.gtk_label_frame_count, 2, 1, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid_status_line), gui_data.gtk_label_fps, 3, 1, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid_status_line), gui_data.gtk_label_mean, 4, 1, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid_status_line), gui_data.gtk_label_sigma, 5, 1, 1, 1);

// show window on screen
    gtk_widget_show_all (gui_data.gtk_window);

// start thread to read camera continuesly:
    pthread_create (&thread, NULL, read_camera_thread, NULL);

// start gtk main loop
    gtk_main ();

// stop camera
    if (e9u_LSMD_end (0) == e9u_LSMD_FAIL)
        exit (3);

    return (0);
}





void *read_camera_thread (void *para)
{
    while (1) {
// read camera:
        if (e9u_LSMD_read_camera (0) == e9u_LSMD_FAIL)
            exit (5);

// send registers to camera, if changed
        if (e9u_LSMD_update_regs (0) == e9u_LSMD_FAIL)
            exit (6);
    }
    
    pthread_exit (NULL);
}





// function to be called if gtk main loop is idle:
gboolean idle_callback (gpointer *Pointer)
{
// make struct from pointer again:
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;
unsigned int        ui_counter_pix;
unsigned int        ui_position_x;
unsigned int        ui_position_y;
static unsigned int ui_frame_counter = 0;
static unsigned int ui_time_stamp = 0;

char                c_string[256];
double              d_mean;
double              d_sigma;
double              d_fps;

// return, if pause
    if (gui_data->i_pause) {
        e9u_LSMD_SLEEP_ms (1);
        return (TRUE);
    }
    

// check for new frame    
    if (e9u_LSMD_check_new_frames (0, 0)) {
    
// copy shadow memory to user memory:
        e9u_LSMD_update_memory (0, 0);

// reset pixels to black, then draw pixels: calculate pixel position and set pixel to yellow:
        memset (gui_data->ui8_pixel, 0, 1024 * 256 * 3);

        sprintf (c_string, " frame no.: %u ", e9u_LSMD_get_frame_counter (0, 0));
        gtk_label_set_label (GTK_LABEL(gui_data->gtk_label_frame_count), c_string);

        sprintf (c_string, " time stamp: %.3f ms", 0.001 * e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_T_STAMP_EXP_START, e9u_LSMD_DT));
        gtk_label_set_label (GTK_LABEL(gui_data->gtk_label_time_stamp), c_string);

        d_mean = 0.;
        for (ui_counter_pix = 0; ui_counter_pix < e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX); ++ui_counter_pix) {
            ui_position_x = ui_counter_pix * 1024 / e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX);
            ui_position_y = 255 - (e9u_LSMD_get_pixel_value (0, 0, ui_counter_pix, 0) >> 8);
            gui_data->ui8_pixel[ui_position_y][ui_position_x][0] = 255;
            gui_data->ui8_pixel[ui_position_y][ui_position_x][1] = 255;
            d_mean += e9u_LSMD_get_pixel_value (0, 0, ui_counter_pix, 0);
        }
        d_mean /= e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX);
        sprintf (c_string, " mean: %7.1f ", d_mean);
        gtk_label_set_label (GTK_LABEL(gui_data->gtk_label_mean), c_string);

        d_sigma = 0.;
        for (ui_counter_pix = 0; ui_counter_pix < e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX); ++ui_counter_pix) {
            d_sigma += pow (d_mean - e9u_LSMD_get_pixel_value (0, 0, ui_counter_pix, 0), 2.);
        }
        d_sigma /= e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX) - 1;
        d_sigma = pow (d_sigma, 0.5);
        sprintf (c_string, " sigma: %7.1f ", d_sigma);
        gtk_label_set_label (GTK_LABEL(gui_data->gtk_label_sigma), c_string);

        d_fps = e9u_LSMD_diff32 (e9u_LSMD_get_frame_counter (0, 0), ui_frame_counter);
        d_fps /= e9u_LSMD_diff32 (e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_T_STAMP_EXP_START, e9u_LSMD_DT), ui_time_stamp);
        d_fps *= 1000000;

        sprintf (c_string, " fps: %.1f", d_fps);
        gtk_label_set_label (GTK_LABEL(gui_data->gtk_label_fps), c_string);

        ui_frame_counter = e9u_LSMD_get_frame_counter (0, 0);
        ui_time_stamp    = e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_T_STAMP_EXP_START, e9u_LSMD_DT);

// update image from pixel buffer
        gtk_image_set_from_pixbuf (GTK_IMAGE(gui_data->gtk_image), gui_data->gdk_pixbuf);
    } else
        e9u_LSMD_SLEEP_ms (1);

    return (TRUE);
}



gboolean scale_changed_callback (GtkWidget *Widget, gpointer *Pointer)
{
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;
unsigned int ui_frame_time;
unsigned int ui_exp_time;


// read scale and set frame time in us, if changed:
    ui_frame_time = gtk_range_get_value (GTK_RANGE(gui_data->gtk_scale_frame)) * 1000;
    if (ui_frame_time != e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_FRAME_TIME, e9u_LSMD_TX)) {
        gtk_range_set_range (GTK_RANGE(gui_data->gtk_scale_exp), 0.01, (double)ui_frame_time / 1000.);
        if (e9u_LSMD_set_reg (0, e9u_LSMD_CH0_FRAME_TIME, ui_frame_time) == e9u_LSMD_FAIL)
            exit (7);
    }
    
// read scale and set integration time in us, if changed:
    ui_exp_time = gtk_range_get_value (GTK_RANGE(gui_data->gtk_scale_exp)) * 1000;
    if (ui_exp_time > ui_frame_time) {
        ui_exp_time = ui_frame_time;
        gtk_range_set_value (GTK_RANGE(gui_data->gtk_scale_exp), (double)ui_exp_time / 1000.);
    }

    if (ui_exp_time != e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_EXP_TIME, e9u_LSMD_TX))
        if (e9u_LSMD_set_reg (0, e9u_LSMD_CH0_EXP_TIME, ui_exp_time) == e9u_LSMD_FAIL)
            exit (8);

    return (TRUE);
}



gboolean pause_callback (GtkWidget *Widget, gpointer *Pointer)
{
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;

    if (gui_data->i_pause) {
        gtk_image_set_from_icon_name (GTK_IMAGE (gui_data->gtk_image_pause), "media-playback-pause", GTK_ICON_SIZE_DIALOG);
        gui_data->i_pause = 0;
    } else {
        gtk_image_set_from_icon_name (GTK_IMAGE (gui_data->gtk_image_pause), "media-playback-start", GTK_ICON_SIZE_DIALOG);
        gui_data->i_pause = 1;
    }
            
    return (TRUE);
}





// callback to save camera data as CSV
gboolean save_callback (GtkWidget *Widget, gpointer *Pointer)
{
// restore pointer with pixel data
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;
GtkWidget    *gtk_dialog;
gint         gi_result;
unsigned int ui_counter; 
char         *c_filename;
FILE         *fp_csv_table;

// create a dialog window to choose file name to save to:
    gtk_dialog = gtk_file_chooser_dialog_new ("Save File", GTK_WINDOW(gui_data->gtk_window), GTK_FILE_CHOOSER_ACTION_SAVE, "Cancel", GTK_RESPONSE_CANCEL, "Save", GTK_RESPONSE_ACCEPT, NULL);
    gi_result = gtk_dialog_run (GTK_DIALOG (gtk_dialog));

// if file name is accepted, get file name:
    if (gi_result == GTK_RESPONSE_ACCEPT) {
        GtkFileChooser *chooser = GTK_FILE_CHOOSER (gtk_dialog);
        c_filename = gtk_file_chooser_get_filename (chooser);

// save CSV table:
        fp_csv_table = fopen (c_filename, "wt");
        if (fp_csv_table == NULL) {
            perror ("open csv table");
            exit (4);
        }
        
        for (ui_counter = 0; ui_counter < e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX); ++ui_counter)
            fprintf (fp_csv_table, "%6u,\t%6u\n", ui_counter, e9u_LSMD_get_pixel_value (0, 0, ui_counter, 0));

// close file:
        fclose (fp_csv_table);
        free (c_filename);
    }

// close chooser widget:
    gtk_widget_destroy (gtk_dialog);

    return (TRUE);
}
