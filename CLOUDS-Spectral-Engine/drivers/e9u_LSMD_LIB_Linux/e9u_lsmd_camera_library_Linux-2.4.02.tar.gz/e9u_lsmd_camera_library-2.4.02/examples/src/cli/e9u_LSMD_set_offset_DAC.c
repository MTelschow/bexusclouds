/*
    EURECA's e9u_LSMD camera software – connect to a e9u_LSMD camera USB module
    Copyright (C) 2020 Eureca Messtechnik GmbH, <info@eureca.de>

	This file is part of EURECA's e9u_LSMD camera software.

	EURECA's e9u_LSMD camera software is free software: you can redistribute
	it and/or modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation, either
	version 3 of the License, or (at your option) any later version.

	EURECA's e9u_LSMD camera software is distributed in the hope that it
	will be useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
	See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
	along with Foobar.  If not, see <http://www.gnu.org/licenses/>.



    Diese Datei ist Teil von EURECAs e9u_LSMD Kamera-Software.

	EURECAs e9u_LSMD Kamera-Software ist Freie Software: Sie können sie
	unter den Bedingungen der GNU Lesser General Public License, wie von
	der Free Software Foundation, Version 3 der Lizenz oder (nach Ihrer
	Wahl) jeder neueren veröffentlichten Version, weiter verteilen
	und/oder modifizieren.

	EURECAs e9u_LSMD Kamera-Software wird in der Hoffnung, dass es nützlich
	sein wird, aber OHNE JEDE GEWÄHRLEISTUNG, bereitgestellt; sogar ohne
	die implizite Gewährleistung der MARKTFÄHIGKEIT oder EIGNUNG FÜR
	EINEN BESTIMMTEN ZWECK.  Siehe die GNU General Public License für
	weitere Details.

    Sie sollten eine Kopie der GNU General Public License zusammen mit diesem
    Programm erhalten haben. Wenn nicht, siehe <https://www.gnu.org/licenses/>.

*/


// include for "printf"
#include <stdio.h>

// include for "exit"
#include <stdlib.h>

// include for "strcmp"
#include <string.h>

#include <e9u_LSMD_defs.h>
#include <e9u_LSMD.h>
#include <e9u_LSMD_macros.h>


// 0 = new camera with adress bit = 0
// 1 = old camera with adress bit = 1
#define V_ALPHA 0

// 0 = CCD like output, voltage decreases with light
// 1 = CMOS like output, voltage increases with light
#define INVERT 0


int main (int i_argc, char *c_argv[])
{
unsigned int ui_pixels;
unsigned int ui_counter;

// Statistik
double  d_offset;
double  d_mean;
double  d_dac_value = 2048.;
double  d_dac_increment = 1024.;
int     i_dac_value;
int 	i_status;
char    c_i2c_transfer[4];

char	c_string[256];

    if (i_argc > 2) {
        printf ("usage:\n");
        printf ("%s [#offset]\n", c_argv[0]);
        exit (1);
    }

    if (i_argc > 1) 
        d_offset = atof (c_argv[1]);
    else
        d_offset = 1536;


    printf ("\n\nAttention!\n\n");
    printf ("This program will permanentely change the line scan camera offset!\n");
    printf ("Only continuer, if you exactly know what you are doing!\n\n");
    printf ("Type 'YES' to continue or 'no' to exit: ");
    scanf ("%s", c_string);
    
    if (strcmp (c_string, "YES") != 0)
      exit (0);


    printf ("\n\nNote!\n\n");
    printf ("Make sure that the sensor is completely covered and dark!\n");
    printf ("Any light on the sensor will cause an offset which is too high.\n\n");
    printf ("Type 'dark' to continue or 'no' to exit: ");
    scanf ("%s", c_string);
    
    if (strcmp (c_string, "dark") != 0)
      exit (0);


// search for camera:
    e9u_LSMD_search_for_camera (0);

// search for camera:
    e9u_LSMD_start_camera_freerun (0);

// set high frame rate and discard 10 framce to clear sensor:
//    e9u_LSMD_wait_times (0, -1, -1); // -1 = minimum frame time
    e9u_LSMD_wait_times (0, 1, 10); // -1 = minimum frame time
    e9u_LSMD_discard_frames (0, 10);

// read number of pixels:
    ui_pixels      = e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX);

// loop, until offset is set
    do {
        // set ADC with new value temporarly:
        i_dac_value = (int)(d_dac_value + 0.5);
        c_i2c_transfer[0] = (i_dac_value >> 8) & 0x0f;
        c_i2c_transfer[1] = i_dac_value & 0xff;
        if (V_ALPHA > 0)
            i_status = e9u_LSMD_I2C_transfer (0, 0b11000010, 2, e9u_LSMD_TX, c_i2c_transfer);
        else
            i_status = e9u_LSMD_I2C_transfer (0, 0b11000000, 2, e9u_LSMD_TX, c_i2c_transfer);

        if (i_status == e9u_LSMD_FAIL)
            exit (2);

        // read camera four times to give the DAC time to settle
        e9u_LSMD_discard_frames (0, 10);

        // then read a line with new offset and calculate mean value:
        e9u_LSMD_get_next_frame (0);
        e9u_LSMD_update_memory (0, 0);
        d_mean = 0.;

        // calculate mean value of the line
        for (ui_counter = 0; ui_counter < ui_pixels; ++ui_counter)
            d_mean += e9u_LSMD_get_pixel_value (0, 0, ui_counter, 0);

        d_mean /= ui_pixels;
        // print values:
        printf ("%4d: %6.1f\n", i_dac_value, d_mean);


        // adjust offset value:
        if (INVERT) {
            if (d_mean > d_offset)
                d_dac_value += d_dac_increment;
            else
                d_dac_value -= d_dac_increment;
        } else {
            if (d_mean > d_offset)
                d_dac_value -= d_dac_increment;
            else
                d_dac_value += d_dac_increment;
        }


        // limit dac value to 12 bit
        if (d_dac_value < 0.)
            d_dac_value = 0.;
        if (d_dac_value > 4095.)
            d_dac_value = 4095.;

        // decrement the increment:
        d_dac_increment /= 2.;

    } while (d_dac_increment > 0.1);

    // set dac permanently:
    i_dac_value = (int)(d_dac_value + 0.5);
    c_i2c_transfer[0] = 0b01100000;
    c_i2c_transfer[1] = (i_dac_value >> 4) & 0xff;
    c_i2c_transfer[2] = (i_dac_value << 4) & 0xff;
    if (V_ALPHA > 0)
        i_status = e9u_LSMD_I2C_transfer (0, 0b11000010, 3, e9u_LSMD_TX, c_i2c_transfer);
    else
        i_status = e9u_LSMD_I2C_transfer (0, 0b11000000, 3, e9u_LSMD_TX, c_i2c_transfer);

    if (i_status == e9u_LSMD_FAIL)
        exit (2);


    e9u_LSMD_SLEEP_ms (1000); // sleep for 1 s to let the change take effect in EEPROM
    printf ("Offset prgrammed!\n");

// stop camera, free memory and close uart:
    if (e9u_LSMD_end (0) == e9u_LSMD_FAIL)
        exit (5);

    return (0);
}
