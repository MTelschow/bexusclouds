/*
    EURECA's e9u_LSMD camera software – connect to a e9u_LSMD camera USB module
    Copyright (C) 2020 Eureca Messtechnik GmbH, <info@eureca.de>

	This file is part of EURECA's e9u_LSMD camera software.

	EURECA's e9u_LSMD camera software is free software: you can redistribute
	it and/or modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation, either
	version 3 of the License, or (at your option) any later version.

	EURECA's e9u_LSMD camera software is distributed in the hope that it
	will be useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
	See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
	along with Foobar.  If not, see <http://www.gnu.org/licenses/>.



    Diese Datei ist Teil von EURECAs e9u_LSMD Kamera-Software.

	EURECAs e9u_LSMD Kamera-Software ist Freie Software: Sie können sie
	unter den Bedingungen der GNU Lesser General Public License, wie von
	der Free Software Foundation, Version 3 der Lizenz oder (nach Ihrer
	Wahl) jeder neueren veröffentlichten Version, weiter verteilen
	und/oder modifizieren.

	EURECAs e9u_LSMD Kamera-Software wird in der Hoffnung, dass es nützlich
	sein wird, aber OHNE JEDE GEWÄHRLEISTUNG, bereitgestellt; sogar ohne
	die implizite Gewährleistung der MARKTFÄHIGKEIT oder EIGNUNG FÜR
	EINEN BESTIMMTEN ZWECK.  Siehe die GNU General Public License für
	weitere Details.

    Sie sollten eine Kopie der GNU General Public License zusammen mit diesem
    Programm erhalten haben. Wenn nicht, siehe <https://www.gnu.org/licenses/>.

*/


// include for "printf"
#include <stdio.h>

// include for "exit"
#include <stdlib.h>

// include for "strcpy"
#include <string.h>

#include <e9u_LSMD_defs.h>
#include <e9u_LSMD.h>


int main (int i_argc, char *c_argv[])
{
unsigned int ui_counter;
int          i_status;
char         c_dev_name[256];
char         c_file_name[256];
double       d_exp_time;
unsigned int ui_exp_time;
unsigned int ui_frame_time;
FILE         *fp_csv_table;

// ask user for information:
    printf ("Please enter device name, e.g. \"COM4\" or \"ttyUSB1\": ");
    scanf ("%s", c_file_name);
// generate native device name:
    strcpy (c_dev_name, e9u_LSMD_UART_DIRPREFIX);
    strcat (c_dev_name, c_file_name);
    
    printf ("Please enter exposure time in [ms]: ");
    scanf ("%lf", &d_exp_time);
    ui_exp_time = d_exp_time * 1000;
    printf ("Please enter file name for CSV table: ");
    scanf ("%s", c_file_name);

    
// allocate memory and open camera:
    if (e9u_LSMD_begin (0, c_dev_name) == e9u_LSMD_FAIL) {
        printf ("ERROR: did not find e9u_LSMD camera!\n");
        e9u_LSMD_end (0);        
        exit (1);
    }


// print camera information:
    printf ("API Version %X, using device %s:\n", e9u_LSMD_API_VERSION, c_dev_name);
    i_status = e9u_LSMD_board_info (0);
//    i_status |= e9u_LSMD_eeprom_info (0, e9u_LSMD_SENSOR_BOARD);

// set  frame time and exposure time, 0 s trigger delay
// enable internal timers, send Dark Pixels und Pixels: e9u_LSMD_C0C_EXP_INT | e9u_LSMD_C0C_TRIG_INT | e9u_LSMD_C0C_TRIG_DEBOUNCE | e9u_LSMD_C0C_PIX_DARK | e9u_LSMD_C0C_PIX_VALUE | e9u_LSMD_C0C_FILL_DITH
// configure to send Stay-Alive Packages and Timings; e9u_LSMD_GC_CHANNEL_0 | e9u_LSMD_GC_STAY_ALIVE | e9u_LSMD_GC_SEND_CONF | e9u_LSMD_GC_SEND_TIME

// round exposure time to multiple of step_exposure:
    ui_exp_time /= e9u_LSMD_step_exposure(0);
    ui_exp_time *= e9u_LSMD_step_exposure(0);

// check for minimum exposure:
    if (ui_exp_time < e9u_LSMD_minimum_exposure(0))
        ui_exp_time = e9u_LSMD_minimum_exposure(0);

// set frame time:    
    ui_frame_time = ui_exp_time;

// round frame time to multiple of step_frame:
    ui_frame_time /= e9u_LSMD_step_frame(0);
    ui_frame_time *= e9u_LSMD_step_frame(0);

// check for minimum frame time:
    if (ui_frame_time < e9u_LSMD_minimum_frame(0))
        ui_frame_time = e9u_LSMD_minimum_frame(0);

    printf ("eposure time: %5.3f ms\n", 0.001 * ui_exp_time);
    printf ("frame time:   %5.3f ms\n", 0.001 * ui_frame_time);
    i_status |= e9u_LSMD_set_reg (0, e9u_LSMD_CH0_FRAME_TIME, ui_frame_time);
    i_status |= e9u_LSMD_set_reg (0, e9u_LSMD_CH0_EXP_TIME,   ui_exp_time);
    i_status |= e9u_LSMD_set_reg (0, e9u_LSMD_CH0_TRIG_DELAY, 0);
    i_status |= e9u_LSMD_set_reg (0, e9u_LSMD_CH0_CONTROL,    e9u_LSMD_C0C_DEFAULT);
    i_status |= e9u_LSMD_set_reg (0, e9u_LSMD_GLOBAL_CONTROL, e9u_LSMD_GC_DEFAULT);
                  
// update registers and start the camera:
    i_status |= e9u_LSMD_update_regs (0);
    if (i_status == e9u_LSMD_FAIL)
        exit (2);
        
// read camera until exposure time is set:
    do {
        do {
            i_status = e9u_LSMD_read_camera (0);
            if (i_status == e9u_LSMD_FAIL)
                exit (3);
        } while (!e9u_LSMD_check_new_frames (0, 0));

    } while ( (ui_exp_time != e9u_LSMD_diff32 (e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_T_STAMP_EXP_STOP, e9u_LSMD_SH), 
                                               e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_T_STAMP_EXP_START, e9u_LSMD_SH))));

// copy shadow memory to user memory:
    e9u_LSMD_update_memory (0, 0);

// save CSV table:
    printf ("Writing CSV-table ....\n");
    fp_csv_table = fopen (c_file_name, "wt");
    if (fp_csv_table == NULL) {
        perror ("open csv table");
        exit (4);
    }
        
    for (ui_counter = 0; ui_counter < e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX); ++ui_counter)
        fprintf (fp_csv_table, "%6u,\t%6u\n", ui_counter, e9u_LSMD_get_pixel_value (0, 0, ui_counter, 0));
    
    fclose (fp_csv_table);
    printf ("ready!\n");
    
// stop camera, free memory and close uart:
    if (e9u_LSMD_end (0) == e9u_LSMD_FAIL)
        exit (5);

// sleep for fife seconds before windows closes:
    e9u_LSMD_SLEEP_ms (5000);
    return (0);
}
