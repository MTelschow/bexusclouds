/*
    EURECA's e9u_LSMD camera software – connect to a e9u_LSMD camera USB module
    Copyright (C) 2020 Eureca Messtechnik GmbH, <info@eureca.de>

	This file is part of EURECA's e9u_LSMD camera software.

	EURECA's e9u_LSMD camera software is free software: you can redistribute
	it and/or modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation, either
	version 3 of the License, or (at your option) any later version.

	EURECA's e9u_LSMD camera software is distributed in the hope that it
	will be useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
	See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
	along with Foobar.  If not, see <http://www.gnu.org/licenses/>.



    Diese Datei ist Teil von EURECAs e9u_LSMD Kamera-Software.

	EURECAs e9u_LSMD Kamera-Software ist Freie Software: Sie können sie
	unter den Bedingungen der GNU Lesser General Public License, wie von
	der Free Software Foundation, Version 3 der Lizenz oder (nach Ihrer
	Wahl) jeder neueren veröffentlichten Version, weiter verteilen
	und/oder modifizieren.

	EURECAs e9u_LSMD Kamera-Software wird in der Hoffnung, dass es nützlich
	sein wird, aber OHNE JEDE GEWÄHRLEISTUNG, bereitgestellt; sogar ohne
	die implizite Gewährleistung der MARKTFÄHIGKEIT oder EIGNUNG FÜR
	EINEN BESTIMMTEN ZWECK.  Siehe die GNU General Public License für
	weitere Details.

    Sie sollten eine Kopie der GNU General Public License zusammen mit diesem
    Programm erhalten haben. Wenn nicht, siehe <https://www.gnu.org/licenses/>.

*/


// include for "printf"
#include <stdio.h>

// include for "exit"
#include <stdlib.h>

// include for "strcpy"
#include <string.h>

// include for "pow"
#include <math.h>

#include <e9u_LSMD_defs.h>
#include <e9u_LSMD.h>
#include <e9u_LSMD_macros.h>


int main (int i_argc, char *c_argv[])
{
char         c_file_name[256];
double       d_exp_time;
double       d_frame_time;
unsigned int ui_scans;
unsigned int ui_pixels;
FILE         *fp_csv_table;

unsigned int ui_counter_scan;
unsigned int ui_counter_pix;
unsigned     *ui_values;

// search for camera:
    e9u_LSMD_search_for_camera (0);

// search for camera:
    e9u_LSMD_start_camera_freerun (0);

// set high frame rate and discard 10 framce to clear sensor:
    e9u_LSMD_wait_times (0, -1, -1); // -1 = minimum frame time
    e9u_LSMD_discard_frames (0, 10);
    

// user entry:
    printf ("Please enter the exposure time in [ms]: ");
    scanf ("%lf", &d_exp_time);
 
    printf ("Please enter the frame time in [ms]: ");
    scanf ("%lf", &d_frame_time);

    printf ("Please enter the number of scans to take: ");
    scanf ("%u", &ui_scans);
    if (ui_scans < 1)
        ui_scans = 1;

    printf ("Please enter a file name for the CSV table: ");
    scanf ("%s", c_file_name);
    

// read number of pixels:
    ui_pixels      = e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX);


// allocate memory:
    ui_values = malloc (ui_pixels * ui_scans * sizeof (unsigned int));
    if (ui_values == NULL) {
        perror ("malloc ui_values:");
        exit (1);
    }
    

// set required exposure and frame time and wait for first frame with correct exposure time:
    e9u_LSMD_wait_times (0, d_exp_time, d_frame_time); 


// loop for the number of scans:
    printf ("\n taking %d scans with %f ms exposure time und %f fps ...\n", ui_scans, d_exp_time, 1000. / d_frame_time);
    for (ui_counter_scan = 0; ui_counter_scan < ui_scans; ++ui_counter_scan) {
    
// read camera, except for the first scan which is already in the shadow memory:
        if (ui_counter_scan > 0)
            e9u_LSMD_get_next_frame (0);

// copy shadow memory to user memory:
        e9u_LSMD_update_memory (0, 0);

// copy the pixel values into the array:
        for (ui_counter_pix = 0; ui_counter_pix < ui_pixels; ++ui_counter_pix)
            ui_values[ui_counter_pix + ui_pixels * ui_counter_scan] = e9u_LSMD_get_pixel_value (0, 0, ui_counter_pix, 0);
    }


// go back to high frame rate idle state to keep sensor empty:
    e9u_LSMD_wait_times (0, -1, -1); // -1 = minimum frame time

// open CSV table:
    printf ("Writing CSV-table ....\n");
    fp_csv_table = fopen (c_file_name, "wt");
    if (fp_csv_table == NULL) {
        perror ("open csv table");
        exit (4);
    }

// calculate mean and sigma and save CSV table:
    for (ui_counter_pix = 0; ui_counter_pix < ui_pixels; ++ui_counter_pix) {
        fprintf (fp_csv_table, "%5u", ui_counter_pix);

        for (ui_counter_scan = 0; ui_counter_scan < ui_scans; ++ui_counter_scan)
            fprintf (fp_csv_table, ", %5u", ui_values[ui_counter_pix + ui_pixels * ui_counter_scan]);
        
        fprintf (fp_csv_table, "\n");
    }         

    fclose (fp_csv_table);
    printf ("ready!\n");
    
// stop camera, free memory and close uart:
    if (e9u_LSMD_end (0) == e9u_LSMD_FAIL)
        exit (5);

// sleep for fife seconds before windows closes:
    e9u_LSMD_SLEEP_ms (5000);
    return (0);
}
