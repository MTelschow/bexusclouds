/*
    EURECA's e9u_LSMD camera software – connect to a e9u_LSMD camera USB module
    Copyright (C) 2020 Eureca Messtechnik GmbH, <info@eureca.de>

	This file is part of EURECA's e9u_LSMD camera software.

	EURECA's e9u_LSMD camera software is free software: you can redistribute
	it and/or modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation, either
	version 3 of the License, or (at your option) any later version.

	EURECA's e9u_LSMD camera software is distributed in the hope that it
	will be useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
	See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
	along with Foobar.  If not, see <http://www.gnu.org/licenses/>.



    Diese Datei ist Teil von EURECAs e9u_LSMD Kamera-Software.

	EURECAs e9u_LSMD Kamera-Software ist Freie Software: Sie können sie
	unter den Bedingungen der GNU Lesser General Public License, wie von
	der Free Software Foundation, Version 3 der Lizenz oder (nach Ihrer
	Wahl) jeder neueren veröffentlichten Version, weiter verteilen
	und/oder modifizieren.

	EURECAs e9u_LSMD Kamera-Software wird in der Hoffnung, dass es nützlich
	sein wird, aber OHNE JEDE GEWÄHRLEISTUNG, bereitgestellt; sogar ohne
	die implizite Gewährleistung der MARKTFÄHIGKEIT oder EIGNUNG FÜR
	EINEN BESTIMMTEN ZWECK.  Siehe die GNU General Public License für
	weitere Details.

    Sie sollten eine Kopie der GNU General Public License zusammen mit diesem
    Programm erhalten haben. Wenn nicht, siehe <https://www.gnu.org/licenses/>.

*/


// include for "printf"
#include <stdio.h>

// include for "exit"
#include <stdlib.h>

// include for "strcpy"
#include <string.h>

// include for "pow"
#include <math.h>

#include <e9u_LSMD_defs.h>
#include <e9u_LSMD.h>
#include <e9u_LSMD_macros.h>


int main (int i_argc, char *c_argv[])
{
unsigned int ui_pixels;
unsigned int ui_cameras;

unsigned int ui_counter_cameras;
unsigned int ui_counter_pix;
double       d_mean;


// search for cameras:
    ui_cameras = 0;
    ui_counter_cameras = 0;
        
    do {
        if (e9u_LSMD_search_for_camera (ui_counter_cameras) != 0)
           ui_cameras = ui_counter_cameras;

        ++ui_counter_cameras;
   } while ((ui_cameras == 0) && (ui_counter_cameras < 16));
   
   printf ("found %d camera(s)!\n", ui_cameras);

   if (ui_cameras == 0)
      exit (1);
   
   
// start cameras:
    for (ui_counter_cameras = 0; ui_counter_cameras < ui_cameras; ++ui_counter_cameras) {
        printf ("serial number of camera %d: %s\n", ui_counter_cameras, e9u_LSMD_eeprom_string (ui_counter_cameras, 1));
        e9u_LSMD_start_camera_freerun (ui_counter_cameras);
    }
    
    
// set 500 ms frame time and 10 ms exposure time
    for (ui_counter_cameras = 0; ui_counter_cameras < ui_cameras; ++ui_counter_cameras)
        e9u_LSMD_wait_times (ui_counter_cameras, 10., 500.); 
        
// read number of pixels (asuming same type of cameras for all!):
    ui_pixels = e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX);


// loop for ever:
    do {
    
        for (ui_counter_cameras = 0; ui_counter_cameras < ui_cameras; ++ui_counter_cameras) {
// read camera in the shadow memory:
            e9u_LSMD_get_next_frame (ui_counter_cameras);

// copy shadow memory to user memory:
            e9u_LSMD_update_memory (ui_counter_cameras, 0);

// calculate mean value:
            d_mean = 0.;
            for (ui_counter_pix = 0; ui_counter_pix < ui_pixels; ++ui_counter_pix)
                d_mean += e9u_LSMD_get_pixel_value (ui_counter_cameras, 0, ui_counter_pix, 0);
            d_mean /= ui_pixels;
 
            printf ("%5.1f ", d_mean);
        }
        printf ("\n");

    } while (1);

// stop camera, free memory and close uart:
    if (e9u_LSMD_end (0) == e9u_LSMD_FAIL)
        exit (5);

// sleep for fife seconds before windows closes:
    e9u_LSMD_SLEEP_ms (5000);
    return (0);
}
