/*
    EURECA's e9u_LSMD camera software – connect to a e9u_LSMD camera USB module
    Copyright (C) 2020 Eureca Messtechnik GmbH, <info@eureca.de>

	This file is part of EURECA's e9u_LSMD camera software.

	EURECA's e9u_LSMD camera software is free software: you can redistribute
	it and/or modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation, either
	version 3 of the License, or (at your option) any later version.

	EURECA's e9u_LSMD camera software is distributed in the hope that it
	will be useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
	See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
	along with Foobar.  If not, see <http://www.gnu.org/licenses/>.



    Diese Datei ist Teil von EURECAs e9u_LSMD Kamera-Software.

	EURECAs e9u_LSMD Kamera-Software ist Freie Software: Sie können sie
	unter den Bedingungen der GNU Lesser General Public License, wie von
	der Free Software Foundation, Version 3 der Lizenz oder (nach Ihrer
	Wahl) jeder neueren veröffentlichten Version, weiter verteilen
	und/oder modifizieren.

	EURECAs e9u_LSMD Kamera-Software wird in der Hoffnung, dass es nützlich
	sein wird, aber OHNE JEDE GEWÄHRLEISTUNG, bereitgestellt; sogar ohne
	die implizite Gewährleistung der MARKTFÄHIGKEIT oder EIGNUNG FÜR
	EINEN BESTIMMTEN ZWECK.  Siehe die GNU General Public License für
	weitere Details.

    Sie sollten eine Kopie der GNU General Public License zusammen mit diesem
    Programm erhalten haben. Wenn nicht, siehe <https://www.gnu.org/licenses/>.

*/


// include for "printf"
#include <stdio.h>

// include for "exit"
#include <stdlib.h>

// include for "strcpy"
#include <string.h>

// includes for e9u_LSMD camera
#include <e9u_LSMD_defs.h>
#include <e9u_LSMD.h>
#include <e9u_LSMD_macros.h>


int main (int i_argc, char *c_argv[])
{
double       d_exp_time;
unsigned int ui_pixels;

unsigned int ui_counter_pix;
int          c_char;


// search for camera:
    e9u_LSMD_search_for_camera (0);

// start camera in asynchrone mode, i.e. a scan is startet by read request:
    e9u_LSMD_start_camera_async (0);

// print cameras serial number:
    printf ("%s\n", e9u_LSMD_eeprom_string (0, e9u_LSMD_EEPROM_SN));

// read number of pixels:
    ui_pixels = e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX);

// user entry:
    printf ("Please enter the exposure time in [ms]: ");
    scanf ("%lf", &d_exp_time);
 
// set required exposure time, frame time should be set at least to the same
    e9u_LSMD_set_times (0, d_exp_time, d_exp_time); 


    do {
// wait for user entry:
        printf ("press enter to take a scan (q = end):\n");
        c_char = getchar ();
    
// read camera, in asynchrone mode this triggers one scan:
        e9u_LSMD_get_next_frame (0);

// print pixel values to stdout:
        for (ui_counter_pix = 0; ui_counter_pix < ui_pixels; ++ui_counter_pix)
            printf ("%4d: %4d\n", ui_counter_pix, e9u_LSMD_get_pixel_value (0, 0, ui_counter_pix, 0));

    } while (c_char != 'q');

// stop camera, free memory and close uart:
    if (e9u_LSMD_end (0) == e9u_LSMD_FAIL)
        exit (5);

    return (0);
}
