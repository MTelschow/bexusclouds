/*
    EURECA's e9u_LSMD camera software – connect to a e9u_LSMD camera USB module
    Copyright (C) 2020 Eureca Messtechnik GmbH, <info@eureca.de>

	This file is part of EURECA's e9u_LSMD camera software.

	EURECA's e9u_LSMD camera software is free software: you can redistribute
	it and/or modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation, either
	version 3 of the License, or (at your option) any later version.

	EURECA's e9u_LSMD camera software is distributed in the hope that it
	will be useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
	See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
	along with Foobar.  If not, see <http://www.gnu.org/licenses/>.



    Diese Datei ist Teil von EURECAs e9u_LSMD Kamera-Software.

	EURECAs e9u_LSMD Kamera-Software ist Freie Software: Sie können sie
	unter den Bedingungen der GNU Lesser General Public License, wie von
	der Free Software Foundation, Version 3 der Lizenz oder (nach Ihrer
	Wahl) jeder neueren veröffentlichten Version, weiter verteilen
	und/oder modifizieren.

	EURECAs e9u_LSMD Kamera-Software wird in der Hoffnung, dass es nützlich
	sein wird, aber OHNE JEDE GEWÄHRLEISTUNG, bereitgestellt; sogar ohne
	die implizite Gewährleistung der MARKTFÄHIGKEIT oder EIGNUNG FÜR
	EINEN BESTIMMTEN ZWECK.  Siehe die GNU General Public License für
	weitere Details.

    Sie sollten eine Kopie der GNU General Public License zusammen mit diesem
    Programm erhalten haben. Wenn nicht, siehe <https://www.gnu.org/licenses/>.

*/


// include for "printf"
#include <stdio.h>

// include for "exit"
#include <stdlib.h>

// include for "strcpy"
#include <string.h>

#include <e9u_LSMD_defs.h>
#include <e9u_LSMD.h>


int main (int i_argc, char *c_argv[])
{
unsigned int ui_exp_time;
unsigned int ui_counter_pix;
double       d_mean_dark;
double       d_mean;

    if (i_argc != 3) {
        fprintf (stderr, "Usage: %s <shared_memory_name> #exposure_time_ms\n", c_argv[0]);
        exit (1);
    }

// allocate memory:
    if (e9u_LSMD_attach_shm (0, c_argv[1]) == e9u_LSMD_FAIL) {
        fprintf (stderr, "ERROR: did not shared memory!\n");
        exit (1);
    }

// get exposure time
    ui_exp_time = atof (c_argv[2]) * 1000;

// round to multiple of step_exposure:
    ui_exp_time /= e9u_LSMD_step_exposure(0);
    ui_exp_time *= e9u_LSMD_step_exposure(0);

// check for minimum exposure:
    if (ui_exp_time < e9u_LSMD_minimum_exposure(0))
        ui_exp_time = e9u_LSMD_minimum_exposure(0);
    
// set exposure time
    if (e9u_LSMD_set_reg (0, e9u_LSMD_CH0_EXP_TIME, ui_exp_time) == e9u_LSMD_FAIL)
        exit (2);

// wait until exposure time is set:
    while (ui_exp_time != e9u_LSMD_diff32 (e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_T_STAMP_EXP_STOP,  e9u_LSMD_SH), 
                                           e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_T_STAMP_EXP_START, e9u_LSMD_SH)))
        e9u_LSMD_SLEEP_ms (1);


    do {
        // wait for new frame:
        while (!e9u_LSMD_check_new_frames (0, 0))
            e9u_LSMD_SLEEP_ms (1);

        // get actual image data:
        e9u_LSMD_update_memory (0, 0);

        // calculate and print mean value
        d_mean_dark = 0.;
        for (ui_counter_pix = 0; ui_counter_pix < e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_DARK_PRE, e9u_LSMD_HOR, e9u_LSMD_RX); ++ui_counter_pix)
            d_mean_dark += e9u_LSMD_get_dark_value (0, 0, ui_counter_pix, 0);
        d_mean_dark /= e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_DARK_PRE, e9u_LSMD_HOR, e9u_LSMD_RX);

        d_mean = 0.;
        for (ui_counter_pix = 0; ui_counter_pix < e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX); ++ui_counter_pix)
            d_mean += e9u_LSMD_get_pixel_value (0, 0, ui_counter_pix, 0);
        d_mean /= e9u_LSMD_get_reg16 (0, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX);

        printf ("mean: %f\n", d_mean - d_mean_dark);

    } while (1);

    if (e9u_LSMD_detach_shm (0) == e9u_LSMD_FAIL)
        exit(3);

    return (0);
}
