/*
    EURECA's e9u_LSMD camera software – connect to a e9u_LSMD camera USB module
    Copyright (C) 2020 Eureca Messtechnik GmbH, <info@eureca.de>

	This file is part of EURECA's e9u_LSMD camera software.

	EURECA's e9u_LSMD camera software is free software: you can redistribute
	it and/or modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation, either
	version 3 of the License, or (at your option) any later version.

	EURECA's e9u_LSMD camera software is distributed in the hope that it
	will be useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
	See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
	along with Foobar.  If not, see <http://www.gnu.org/licenses/>.



    Diese Datei ist Teil von EURECAs e9u_LSMD Kamera-Software.

	EURECAs e9u_LSMD Kamera-Software ist Freie Software: Sie können sie
	unter den Bedingungen der GNU Lesser General Public License, wie von
	der Free Software Foundation, Version 3 der Lizenz oder (nach Ihrer
	Wahl) jeder neueren veröffentlichten Version, weiter verteilen
	und/oder modifizieren.

	EURECAs e9u_LSMD Kamera-Software wird in der Hoffnung, dass es nützlich
	sein wird, aber OHNE JEDE GEWÄHRLEISTUNG, bereitgestellt; sogar ohne
	die implizite Gewährleistung der MARKTFÄHIGKEIT oder EIGNUNG FÜR
	EINEN BESTIMMTEN ZWECK.  Siehe die GNU General Public License für
	weitere Details.

    Sie sollten eine Kopie der GNU General Public License zusammen mit diesem
    Programm erhalten haben. Wenn nicht, siehe <https://www.gnu.org/licenses/>.

*/

// include for "exit"
#include <stdlib.h>

// include for "strcpy"
#include <string.h>

// include for "uint8_t" "uint16_t" and "uint32_t"
#include <stdint.h>

// include for "gtk_init"
#include <gtk/gtk.h>

// include for "fabs"
#include <math.h>

// include for sockets
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>

// include for "gethostbyname"
#include <netdb.h>


#include <e9u_LSMD_defs.h>
#include <e9u_LSMD.h>


int draw_line (unsigned int ui_x0, unsigned int ui_y0, unsigned int ui_x1, unsigned int ui_y1, unsigned int ui_col, uint8_t *ui8_pixel, unsigned int ui_width);


// a struct containing all objects to get passed by a pointer to the callback
struct GUI_DATA { GtkWidget *gtk_window;
                  GtkWidget *gtk_scale_exp;
                  GtkWidget *gtk_scale_frame;
                  GdkPixbuf *gdk_pixbuf;
                  GtkWidget *gtk_image;
                  uint8_t   *ui8_pixel; 
                  int       i_socket_fd; };

gboolean idle_callback (gpointer *Pointer);



int main (int i_argc, char *c_argv[])
{
// pack all neccessary widgets, etc in a struct to pass them as a pointer to the callback
struct GUI_DATA gui_data;
GtkWidget       *gtk_frame;
GtkWidget       *gtk_grid;
GtkWidget       *gtk_label_exp;
GtkWidget       *gtk_label_frame;

struct hostent *hst_host;
char           c_host_name[32];

struct sockaddr_un unix_address;
struct sockaddr_in inet_address;
unsigned short int usi_port;


// initialize GTK and process GTK command line options, i_argc and c_argv will be changed and only include remaining non GTK command line options then:
    gtk_init (&i_argc, &c_argv);

    if ((i_argc != 2) && (i_argc != 3)) {
        fprintf (stderr, "Usage: %s <socket_name>\n", c_argv[0]);
        fprintf (stderr, "       connect to Unix domain socket\n\n");
        fprintf (stderr, "Usage: %s <server> <port>\n", c_argv[0]);
        fprintf (stderr, "       connect to server:port via tcp\n");
        exit (1);
    }

    if (i_argc == 2) {
// open socket
        gui_data.i_socket_fd = socket (PF_UNIX, SOCK_STREAM, 0);
        if (gui_data.i_socket_fd < 0) {
            perror ("socket() failed");
            exit (2);
        } 
                  
// set adress structure:
        memset (&unix_address, 0, sizeof (unix_address));
        unix_address.sun_family = AF_UNIX;
        sprintf (unix_address.sun_path, c_argv[1]);

// accept connection:
        if (connect (gui_data.i_socket_fd, (struct sockaddr *) (struct sockaddr *) &unix_address, sizeof (unix_address)) != 0) {
            perror ("accept() failed");
            exit (2);
        } 
    } else {
// open socket
        gui_data.i_socket_fd = socket (AF_INET, SOCK_STREAM, 0);
        if (gui_data.i_socket_fd < 0) {
            perror ("socket() failed");
            exit (2);
        } 

// nslookup:
        hst_host = gethostbyname (c_argv[1]);
        if (hst_host==NULL) {
            perror ("gethostbyname() failed");
            exit (2);
        } 

// set adress structure:
        usi_port = atoi (c_argv[2]);
        sprintf (c_host_name, "%u.%u.%u.%u", hst_host->h_addr_list[0][0] & 0xff, hst_host->h_addr_list[0][1] & 0xff, hst_host->h_addr_list[0][2] & 0xff, hst_host->h_addr_list[0][3] & 0xff);
        printf ("connect to %s:%u\n", c_host_name, usi_port);

        memset (&inet_address, '0', sizeof (inet_address));
        inet_address.sin_family = AF_INET;
        inet_address.sin_addr.s_addr = inet_addr (c_host_name);
        inet_address.sin_port = htons (usi_port); 

// accept connection:
        if (connect (gui_data.i_socket_fd, (struct sockaddr *) (struct sockaddr *) &inet_address, sizeof (inet_address)) != 0) {
            perror ("accept() failed");
            exit (2);
        } 
    }


    printf ("connected\n");

// create a window and callback "exit" if window is destroyed
    gui_data.gtk_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    g_signal_connect (gui_data.gtk_window, "destroy", G_CALLBACK (exit) , NULL);

// create a frame around window:
    gtk_frame = gtk_frame_new ("e9u_LSMD Socket GUI");

// create vbox and add into window
    gtk_grid = gtk_grid_new ();

// initialize scale for integration time and frame time
    gui_data.gtk_scale_frame = gtk_scale_new_with_range (GTK_ORIENTATION_HORIZONTAL, 8., 1000., 1.);
    gtk_range_set_value (GTK_RANGE(gui_data.gtk_scale_frame), 100.);
    gtk_label_frame = gtk_label_new (" frame time [ms]: ");
    gtk_label_set_xalign (GTK_LABEL (gtk_label_frame), 1.0);

    gui_data.gtk_scale_exp = gtk_scale_new_with_range (GTK_ORIENTATION_HORIZONTAL, 0.01, 100., 0.01);
    gtk_range_set_value (GTK_RANGE(gui_data.gtk_scale_exp), 10.);
    gtk_label_exp = gtk_label_new (" exposure time [ms]: ");
    gtk_label_set_xalign (GTK_LABEL (gtk_label_exp), 1.0);

// fill the pixel buffer with black, initalize pixel buffer, use as image und pack into vbox:
    gui_data.ui8_pixel = malloc (1024 * 256 * 3 * sizeof (char));
    memset (gui_data.ui8_pixel, 0, 1024 * 256 * 3);
    gui_data.gdk_pixbuf = gdk_pixbuf_new_from_data (gui_data.ui8_pixel, GDK_COLORSPACE_RGB, FALSE, 8, 1024, 256, 1024 * 3, NULL, NULL);
    gui_data.gtk_image = gtk_image_new_from_pixbuf (gui_data.gdk_pixbuf);

// connect to on-idle function:
    g_idle_add ((GSourceFunc)idle_callback, (void *)&gui_data );

// expand some widgets:
    gtk_widget_set_hexpand (gui_data.gtk_scale_frame, TRUE);
    gtk_widget_set_hexpand (gui_data.gtk_scale_exp, TRUE);

// pack all widgets
    gtk_container_add (GTK_CONTAINER (gui_data.gtk_window), gtk_frame);
    gtk_container_add (GTK_CONTAINER (gtk_frame), gtk_grid);
    
    gtk_grid_attach (GTK_GRID (gtk_grid), gtk_label_exp, 1, 1, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid), gui_data.gtk_scale_exp, 2, 1, 1, 1);

    gtk_grid_attach (GTK_GRID (gtk_grid), gtk_label_frame, 1, 2, 1, 1);
    gtk_grid_attach (GTK_GRID (gtk_grid), gui_data.gtk_scale_frame, 2, 2, 1, 1);

    gtk_grid_attach (GTK_GRID (gtk_grid), gui_data.gtk_image, 1, 3, 2, 1);

// show window on screen
    gtk_widget_show_all (gui_data.gtk_window);

// start gtk main loop
    gtk_main ();

// stop camera
    if (e9u_LSMD_end (0) == e9u_LSMD_FAIL)
        exit (3);

    return (0);
}





// function to be called if gtk main loop is idle:
gboolean idle_callback (gpointer *Pointer)
{
// make struct from pointer again:
struct GUI_DATA *gui_data = (struct GUI_DATA *) Pointer;
uint16_t        ui16_counter_pix;
unsigned int    ui_position_x, ui_position_x_old;
unsigned int    ui_position_y, ui_position_y_old;
static uint32_t ui32_frame_counter = 0;
static uint32_t ui32_exp_time = 0;
static uint32_t ui32_frame_time = 0;

uint16_t        ui16_n;
uint8_t         ui8_register;
uint32_t        ui32_value;
uint16_t        ui16_value;


    ui16_value = 0;
    
    if (ui32_frame_time != 1000 * gtk_range_get_value (GTK_RANGE(gui_data->gtk_scale_frame))) {
        ui32_frame_time = 1000 * gtk_range_get_value (GTK_RANGE(gui_data->gtk_scale_frame));
        gtk_range_set_range (GTK_RANGE(gui_data->gtk_scale_exp), 0.01, (double)ui32_frame_time / 1000.);
        ui16_value = 1;
    }

    if (ui32_exp_time != 1000 * gtk_range_get_value (GTK_RANGE(gui_data->gtk_scale_exp))) {
        ui32_exp_time = 1000 * gtk_range_get_value (GTK_RANGE(gui_data->gtk_scale_exp));
        ui16_value = 1;
    }
    
    if (ui16_value == 0) {
        ui8_register = 0;
        write (gui_data->i_socket_fd, (char *)&ui8_register, 1);
    } else {
        ui8_register = 2;
        write (gui_data->i_socket_fd, (char *)&ui8_register, 1);

        ui8_register = e9u_LSMD_CH0_EXP_TIME;
        write (gui_data->i_socket_fd, (char *)&ui8_register, 1);
        write (gui_data->i_socket_fd, (char *)&ui32_exp_time, 4);

        ui8_register = e9u_LSMD_CH0_FRAME_TIME;
        write (gui_data->i_socket_fd, (char *)&ui8_register, 1);
        write (gui_data->i_socket_fd, (char *)&ui32_frame_time, 4);
    }
    
    read (gui_data->i_socket_fd, (char *)&ui32_value, 4);
    read (gui_data->i_socket_fd, (char *)&ui32_value, 4);

    read (gui_data->i_socket_fd, (char *)&ui16_n, 2);
    for (ui16_counter_pix = 0; ui16_counter_pix < ui16_n; ++ui16_counter_pix)
        read (gui_data->i_socket_fd, (char *)&ui16_value, 2);

    
    
    if (ui32_frame_counter != ui32_value) {
        ui32_frame_counter = ui32_value;

// reset pixels to black, then draw pixels: calculate pixel position and set pixel to yellow:
        memset (gui_data->ui8_pixel, 0, 1024 * 256 * 3);

        read (gui_data->i_socket_fd, (char *)&ui16_n, 2);
        for (ui16_counter_pix = 0; ui16_counter_pix < ui16_n; ++ui16_counter_pix) {
            read (gui_data->i_socket_fd, (char *)&ui16_value, 2);
            ui_position_x = ui16_counter_pix * 1024 / ui16_n;
            ui_position_y = 255 - (ui16_value >> 8);
            
            if (ui16_counter_pix != 0)
                draw_line (ui_position_x, ui_position_y, ui_position_x_old, ui_position_y_old, 0xffff00, gui_data->ui8_pixel, 1024);

            ui_position_x_old = ui_position_x;
            ui_position_y_old = ui_position_y;
        }

// update image from pixel buffer
        gtk_image_set_from_pixbuf (GTK_IMAGE(gui_data->gtk_image), gui_data->gdk_pixbuf);
    } else {
        read (gui_data->i_socket_fd, (char *)&ui16_n, 2);
        for (ui16_counter_pix = 0; ui16_counter_pix < ui16_n; ++ui16_counter_pix) 
            read (gui_data->i_socket_fd, (char *)&ui16_value, 2);
            
        e9u_LSMD_SLEEP_ms (1);
    }
    
    return (TRUE);
}



int draw_line (unsigned int ui_x0, unsigned int ui_y0, unsigned int ui_x1, unsigned int ui_y1, unsigned int ui_col, uint8_t *ui8_pixel, unsigned int ui_width)
{
unsigned int ui_position_x;
unsigned int ui_position_y;
double d_counter;
double d_diff_x;
double d_diff_y;
double d_diff_max;

    d_diff_x = (double)ui_x0 - (double)ui_x1;
    d_diff_y = (double)ui_y0 - (double)ui_y1;

    d_diff_max = fabs (d_diff_x);
    if (d_diff_max < fabs (d_diff_y))
        d_diff_max = fabs (d_diff_y);

    if (d_diff_max < 1.)
        d_diff_max = 1.;

    for (d_counter = 0.; d_counter <= 1.; d_counter += 1. / d_diff_max)
    {
        ui_position_x = (double)ui_x0 * d_counter + (double)ui_x1 * (1. - d_counter);
        ui_position_y = (double)ui_y0 * d_counter + (double)ui_y1 * (1. - d_counter);

        ui8_pixel[ui_position_y * ui_width * 3 + ui_position_x * 3 + 0] = (ui_col & 0x00ff0000) >> 16;
        ui8_pixel[ui_position_y * ui_width * 3 + ui_position_x * 3 + 1] = (ui_col & 0x0000ff00) >> 8;
        ui8_pixel[ui_position_y * ui_width * 3 + ui_position_x * 3 + 2] = (ui_col & 0x000000ff);
    }

    return (0);
}
