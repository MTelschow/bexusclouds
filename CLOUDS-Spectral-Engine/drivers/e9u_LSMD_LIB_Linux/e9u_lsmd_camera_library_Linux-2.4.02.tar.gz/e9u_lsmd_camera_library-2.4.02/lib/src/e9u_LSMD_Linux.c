/*
    EURECA's e9u_LSMD camera software – connect to a e9u_LSMD camera USB module
    Copyright (C) 2020 - 2022 Eureca Messtechnik GmbH, <info@eureca.de>

	This file is part of EURECA's e9u_LSMD camera software.

	EURECA's e9u_LSMD camera software is free software: you can redistribute
	it and/or modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation, either
	version 3 of the License, or (at your option) any later version.

	EURECA's e9u_LSMD camera software is distributed in the hope that it
	will be useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
	See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
	along with Foobar.  If not, see <http://www.gnu.org/licenses/>.



    Diese Datei ist Teil von EURECAs e9u_LSMD Kamera-Software.

	EURECAs e9u_LSMD Kamera-Software ist Freie Software: Sie können sie
	unter den Bedingungen der GNU Lesser General Public License, wie von
	der Free Software Foundation, Version 3 der Lizenz oder (nach Ihrer
	Wahl) jeder neueren veröffentlichten Version, weiter verteilen
	und/oder modifizieren.

	EURECAs e9u_LSMD Kamera-Software wird in der Hoffnung, dass es nützlich
	sein wird, aber OHNE JEDE GEWÄHRLEISTUNG, bereitgestellt; sogar ohne
	die implizite Gewährleistung der MARKTFÄHIGKEIT oder EIGNUNG FÜR
	EINEN BESTIMMTEN ZWECK.  Siehe die GNU General Public License für
	weitere Details.

    Sie sollten eine Kopie der GNU General Public License zusammen mit diesem
    Programm erhalten haben. Wenn nicht, siehe <https://www.gnu.org/licenses/>.

*/


#ifdef __linux__

// include for "printf"
#include <stdio.h>

// include for "malloc"
#include <stdlib.h>

// include for fixed length integer
#include <stdint.h>

// include for "write" and "read" and "mmap"
#include <unistd.h>

// include for "memset" and "strlen"
#include <string.h>

// include for "cfmakeraw", "cfsetspeed" and "tcsetattr"
#include <termios.h>

// include for "ioctl" (optional)
#include <sys/ioctl.h>

// include for "flock" (optional)
#include <sys/file.h>

// include for "clock_gettime"
#include <time.h>

// includes for "stat"
#include <sys/types.h>
#include <sys/stat.h>

// include for "open"
#include <fcntl.h>

// include for "mmap"
#include <sys/mman.h>


#include "e9u_LSMD_defs.h"
#include "e9u_LSMD_interface.h"



// sleep in [ms]
/** @brief Sleep for the given time.
 * @param[in] ui_ms time to sleep (in micro seconds)
 * @returns always returns #e9u_LSMD_OK
 */
int e9u_LSMD_SLEEP_ms (unsigned int ui_ms)
{
    usleep (1000l * ui_ms);
    return (e9u_LSMD_OK);
}



// test, if device exists:
/** @brief Test whether the device exists.
 * @param[in] c_devname the device's name
 * 
 * @todo Was sind mögliche Rückgabe-Werte?
 */
int e9u_LSMD_UART_exists (char* c_devname)
{
    return (access (c_devname, R_OK | W_OK));
}



// opens the UART:
// e9u_LSMD_TTY_HANDLE *ttyUSB: pointer to new file descriptor to tty device
// char *c_devname:    device name as file name
// return:             zero on success
/** @brief Open the UART.
 * @param[out] h_ttyUSB handle to the UART once it's opened
 * @param[in] c_devname device name as file name
 * @returns #e9u_LSMD_OK in case of success, #e9u_LSMD_ERROR_OPEN in case of any problems
 */
int e9u_LSMD_UART_open (e9u_LSMD_TTY_HANDLE *h_ttyUSB, char *c_devname)
{
struct termios t_termios;

// open device:
    *h_ttyUSB = open (c_devname, O_RDWR | O_NOCTTY | O_SYNC);
    if (*h_ttyUSB < 0) {
         perror ("open ttyUSB:");
         return (e9u_LSMD_ERROR_OPEN);
    }

// lock device:
    if (ioctl (*h_ttyUSB, TIOCEXCL) < 0) {
         perror ("ioctl:");
         e9u_LSMD_UART_close (*h_ttyUSB);
         return (e9u_LSMD_ERROR_OPEN);
    }
    
    if (flock (*h_ttyUSB, LOCK_EX | LOCK_NB) < 0) {
         perror ("flock:");
         e9u_LSMD_UART_close (*h_ttyUSB);
         return (e9u_LSMD_ERROR_OPEN);
    }
    
// set serial port parameters:
    memset (&t_termios, 0, sizeof(t_termios)); // clear the configuration
    t_termios.c_cflag = CS8 | CREAD | CLOCAL;  // 8n1, no handshake
    t_termios.c_cc[VMIN] = 0;                  // return a read even with no character received
    t_termios.c_cc[VTIME] = 2;                 // return after 0.2s timeout
    cfsetspeed (&t_termios, B921600);          // set maximum Windows supported speed of 921.6 kbaud
//    cfsetspeed (&t_termios, B4000000);       // set maximum supported speed of 4 Mbaud
    if (tcsetattr(*h_ttyUSB, TCSANOW, &t_termios) < 0) {   // set the configuration
         perror ("tcsetattr:");
         e9u_LSMD_UART_close (*h_ttyUSB);
         return (e9u_LSMD_ERROR_OPEN);
    }
    
    usleep (200000);                           // give the port time to update the configuration
    if (tcflush (*h_ttyUSB, TCIOFLUSH) < 0) {  // flush all buffers, if not empty
         perror ("tcflush after tcsetattr:");
         e9u_LSMD_UART_close (*h_ttyUSB);
         return (e9u_LSMD_ERROR_OPEN);
    }

    return (e9u_LSMD_OK);
}



// closes the UART:
// e9u_LSMD_TTY_HANDLE ttyUSB: file descripto to tty device
// return:            zero
/** @brief Close the UART.
 * @param[in] h_ttyUSB handle to the UART
 * @returns #e9u_LSMD_OK on success, #e9u_LSMD_ERROR_CLOSE if the handle cannot be closed.
 */
int e9u_LSMD_UART_close (e9u_LSMD_TTY_HANDLE h_ttyUSB)
{
    usleep (200000);                          // give the port time to update the configuration
    if (tcflush (h_ttyUSB, TCIOFLUSH) < 0)    // flush all input AND output buffers, if not empty
         perror ("tcflush:");

    if (ioctl(h_ttyUSB, TCFLSH, 2) < 0)
         perror ("tcflush:");

    if (close (h_ttyUSB) < 0) {
         perror ("close ttyUSB:");
         return (e9u_LSMD_ERROR_CLOSE);
    }

    return (e9u_LSMD_OK);
}



// replaces the "normal" read and write by a function
// which guarantees that all data are written not depending
// on buffer size
// e9u_LSMD_TTY_HANDLE ttyUSB: file descriptor to tty device
// char *v_buffer:    pointer to memory
// ssize_t sz_count:  number of bytes to receive / transmit
// double d_timeout:  timeout in seconds
// return:            number of byte read / sent
/** @brief Send bytes to the e9u_LSMD device.
 *
 *  This funktion replaces the "normal" write by a function which guarantees
 *  that all data are written and which is independent of buffer size.
 *  @param[in] h_ttyUSB handle to the e9u_LSMD device
 *  @param[in] c_buffer buffer containing the bytes to be sent
 *  @param[in] sz_count number of bytes to be sent
 *  @param[out] sz_written upon exit, this parameter contains the number of bytes sent
 *  @returns #e9u_LSMD_OK upon success, #e9u_LSMD_TIMEOUT_WRITE if a timeout occurs, #e9u_LSMD_ERROR_WRITE in case of any other write errors
 *
 *  @todo kann man den Timeout setzen? Der war mal hier Parameter...
 */
int e9u_LSMD_UART_write (e9u_LSMD_TTY_HANDLE h_ttyUSB, char *c_buffer, size_t sz_count, size_t *sz_written)
{
ssize_t         sz_total;
ssize_t         sz_package;
ssize_t         sz_transfered;
ssize_t         sz_bytes;

    sz_total = sz_count;
    sz_transfered = 0;
    do {
        sz_package = sz_total - sz_transfered;
        if (sz_package > 2048)
            sz_package = 2048;

        sz_bytes = write (h_ttyUSB, c_buffer + sz_transfered, sz_package);

        if (sz_bytes > 0)
            sz_transfered += sz_bytes;
        *sz_written = sz_transfered;

        if (sz_bytes == 0)
            return (e9u_LSMD_TIMEOUT_WRITE);

        if (sz_bytes < 0) {
             perror ("write:");
             return (e9u_LSMD_ERROR_WRITE);
        }

    } while ((sz_transfered < sz_total));

    return (e9u_LSMD_OK);
}



// replaces the "normal" read and write by a function
// which guarantees that all data are written not depending
// on buffer size
// e9u_LSMD_TTY_HANDLE ttyUSB: file descriptor to tty device
// char *v_buffer:    pointer to memory
// size_t sz_count:  number of bytes to receive / transmit
// double d_timeout:  timeout in seconds
// return:            number of byte read / sent
/** @brief Receive bytes from the e9u_LSMD device.
 *
 *  This funktion replaces the "normal" read by a function which guarantees
 *  that all data are received and which is independent of buffer size.
 *  @param[in]  h_ttyUSB handle to the e9u_LSMD device
 *  @param[out] c_buffer buffer which will receive the bytes received
 *  @param[in] sz_count number of bytes to be received
 *  @param[out] sz_read upon exit, this parameter contains the number of bytes received
 *  @returns #e9u_LSMD_OK upon success, #e9u_LSMD_TIMEOUT_READ if a timeout occurs, #e9u_LSMD_ERROR_READ in case of any other read errors
 *
 *  @todo kann man den Timeout setzen? Der war mal hier Parameter...
 */
int e9u_LSMD_UART_read (e9u_LSMD_TTY_HANDLE h_ttyUSB, char *c_buffer, size_t sz_count, size_t *sz_read)
{
ssize_t         sz_total;
ssize_t         sz_package;
ssize_t         sz_transfered;
ssize_t         sz_bytes;

    sz_transfered = 0;
    sz_total = sz_count;
    do {
        sz_package = sz_total - sz_transfered;
        if (sz_package > 2048)
            sz_package = 2048;

        sz_bytes = read (h_ttyUSB, c_buffer + sz_transfered, sz_package);
        if (sz_bytes > 0)
            sz_transfered += sz_bytes;
        *sz_read = sz_transfered;
        
        if (sz_bytes == 0)
            return (e9u_LSMD_TIMEOUT_READ);

        if (sz_bytes < 0) {
             perror ("read:");
             return (e9u_LSMD_ERROR_READ);
        }

    } while ((sz_transfered < sz_total));

    return (e9u_LSMD_OK);
}





// flushes all data in the tty buffer
// e9u_LSMD_TTY_HANDLE ttyUSB: file descriptor to tty device
// return:            zero
/** @brief Flush all data from the device's buffers.
 * @param[in] h_ttyUSB handle to the device
 * @returns #e9u_LSMD_OK upon success, #e9u_LSMD_ERROR_FLUSH in case of any errors
 */
int e9u_LSMD_UART_flush (e9u_LSMD_TTY_HANDLE h_ttyUSB)
{

// wait until data are written to camera:
// note: tcdrain does not time out (perhaps we do not use it and hope transfer is completed during sleep)
    if (tcdrain (h_ttyUSB) < 0) {
         perror ("tcdrain:");
         return (e9u_LSMD_ERROR_FLUSH);
    }

// flush input buffers a second time:
// the camera still sends up to 16 KiB of data from internal fifo,
// this is up to fife times the buffer size:
    usleep (10000);                          // give the camera time to fill the buffer
    if (tcflush (h_ttyUSB, TCIFLUSH) < 0) {    // flush all input buffers, if not empty
         perror ("tcflush:");
         return (e9u_LSMD_ERROR_FLUSH);
    }
    usleep (10000);                          // give the camera time to fill the buffer
    if (tcflush (h_ttyUSB, TCIFLUSH) < 0) {    // flush all input buffers, if not empty
         perror ("tcflush:");
         return (e9u_LSMD_ERROR_FLUSH);
    }
    usleep (10000);                          // give the camera time to fill the buffer
    if (tcflush (h_ttyUSB, TCIFLUSH) < 0) {    // flush all input buffers, if not empty
         perror ("tcflush:");
         return (e9u_LSMD_ERROR_FLUSH);
    }
    usleep (10000);                          // give the camera time to fill the buffer
    if (tcflush (h_ttyUSB, TCIFLUSH) < 0) {    // flush all input buffers, if not empty
         perror ("tcflush:");
         return (e9u_LSMD_ERROR_FLUSH);
    }
    usleep (10000);                          // give the camera time to fill the buffer
    if (tcflush (h_ttyUSB, TCIFLUSH) < 0) {    // flush all input buffers, if not empty
         perror ("tcflush:");
         return (e9u_LSMD_ERROR_FLUSH);
    }

    return (e9u_LSMD_OK);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_SEM_create  (e9u_LSMD_SEM_HANDLE *h_semaphore)
{
    if (sem_init (h_semaphore, 0, 1) < 0)
        return (e9u_LSMD_ERROR_SEMAPHORE);    
     
    return (e9u_LSMD_OK);
}
    


/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_SEM_lock    (e9u_LSMD_SEM_HANDLE *h_semaphore)
{
struct timespec ts;

    if (clock_gettime (CLOCK_REALTIME, &ts) < 0)
        return (e9u_LSMD_ERROR_SEMAPHORE);    
    ts.tv_sec += 1;
    
    if (sem_timedwait (h_semaphore, &ts) < 0)
        return (e9u_LSMD_ERROR_SEMAPHORE);    

    return (e9u_LSMD_OK);
}

/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_SEM_unlock  (e9u_LSMD_SEM_HANDLE *h_semaphore)
{
    if (sem_post (h_semaphore) < 0)
        return (e9u_LSMD_ERROR_SEMAPHORE);    
     
    return (e9u_LSMD_OK);
}

/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_SEM_close  (e9u_LSMD_SEM_HANDLE *h_semaphore)
{
    if (sem_destroy (h_semaphore) < 0)
        return (e9u_LSMD_ERROR_SEMAPHORE);    
     
    return (e9u_LSMD_OK);
}






/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_SHM_allocate_interface (struct e9u_LSMD_DATA *e9u_lsmd_data, const char *c_mmap_name)
{
uint8_t     ui8_channel;
char        c_filename[1024];
FILE        *filep;
struct stat st_filep;


// make sure we have pointers initialized with NULL to detect, if free or close is valid:
    e9u_lsmd_data->e9u_lsmd_interface   = NULL;
    e9u_lsmd_data->i_ttyUSB_open    = 0;

    for (ui8_channel = 0; ui8_channel < 8; ++ui8_channel) {
        e9u_lsmd_data->ui8_e9u_lsmd_buffer[ui8_channel] = NULL;
        e9u_lsmd_data->ui8_e9u_lsmd_shadow[ui8_channel] = NULL;
        e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel]   = NULL;
    }


// test, if file for shared memory exists with correct size:
    sprintf (c_filename, "%s.e9u_lsmd_regs.mmap", c_mmap_name);
    if (access (c_filename, F_OK ) >= 0 ) {
        stat (c_filename, &st_filep);
        if (st_filep.st_size != sizeof (struct e9u_LSMD_INTERFACE))
            unlink (c_filename);
    }

// create a new file with the correct size:
    if (access (c_filename, F_OK ) < 0 ) 
    {
        printf ("create file with %u  byte ...\n", (unsigned int)sizeof (struct e9u_LSMD_INTERFACE));
        filep = fopen (c_filename, "wb");
        if (filep == NULL)
        {
            perror ("fopen mmap e9u_lsmd_interface\n");
            return (e9u_LSMD_ERROR_MALLOC);
        }

        fseek (filep, sizeof (struct e9u_LSMD_INTERFACE) - 1, SEEK_SET);
        putc (0, filep);
        fclose (filep); 
        printf ("done.\n\n");
    }


// open file for shared memory:
    e9u_lsmd_data->hd_e9u_lsmd_interface = open (c_filename, O_RDWR);
    if (e9u_lsmd_data->hd_e9u_lsmd_interface == -1)
    {
        perror ("open mmap e9u_lsmd_interface\n");
        return (e9u_LSMD_ERROR_MALLOC);
    }

// open shared memory:
    e9u_lsmd_data->e9u_lsmd_interface = mmap (NULL, sizeof (struct e9u_LSMD_INTERFACE), PROT_READ | PROT_WRITE, MAP_SHARED, e9u_lsmd_data->hd_e9u_lsmd_interface, 0);
    if (e9u_lsmd_data->e9u_lsmd_interface == MAP_FAILED) 
    {
        close (e9u_lsmd_data->hd_e9u_lsmd_interface);
        perror ("mmap e9u_lsmd_interface\n");
        e9u_lsmd_data->e9u_lsmd_interface = NULL;
        return (e9u_LSMD_ERROR_MALLOC);
    }

// empty strings:
    e9u_lsmd_data->e9u_lsmd_interface->c_ttyUSB_name[0] = 0;
    e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.c_type[0] = 0;
    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status = e9u_LSMD_NONE;
    e9u_LSMD_SEM_create  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_shadow);
    e9u_LSMD_SEM_create  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
    e9u_LSMD_SEM_create  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);

    for (ui8_channel = 0; ui8_channel < 8; ++ui8_channel) {
        e9u_lsmd_data->e9u_lsmd_interface->ui32_frame_count_shadow[ui8_channel] = 0;
        e9u_lsmd_data->e9u_lsmd_interface->ui32_frame_count_data[ui8_channel] = 0;
        e9u_lsmd_data->e9u_lsmd_interface->sz_e9u_lsmd_data[ui8_channel] = 0;
    }
    
    return (e9u_LSMD_OK);
}




/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_SHM_allocate_data (struct e9u_LSMD_DATA *e9u_lsmd_data, const char *c_mmap_name)
{
// actually hard coded channel 0!
uint8_t     ui8_channel = 0;
char        c_filename[1024];
FILE        *filep;
struct stat st_filep;


// calculate sizes once:
    e9u_lsmd_data->e9u_lsmd_interface->sz_e9u_lsmd_data[ui8_channel] = sizeof (uint8_t) * e9u_LSMD_IO_get_reg8  (e9u_lsmd_data, e9u_LSMD_CH0_ADC, 3, e9u_LSMD_RX) / 8 *
                                                         ( e9u_lsmd_data->e9u_lsmd_interface->register_rx[e9u_LSMD_CH0_DARK_PRE].ui16_value[1] 
                                                         + e9u_lsmd_data->e9u_lsmd_interface->register_rx[e9u_LSMD_CH0_PIXEL].ui16_value[1] );


// test, if file for shared memory exists with correct size:
    sprintf (c_filename, "%s.e9u_lsmd_shadow.mmap", c_mmap_name);
    if (access (c_filename, F_OK ) >= 0 ) {
        stat (c_filename, &st_filep);
        if (st_filep.st_size != e9u_lsmd_data->e9u_lsmd_interface->sz_e9u_lsmd_data[ui8_channel])
            unlink (c_filename);
    }

// create a new file with the correct size:
    if (access (c_filename, F_OK ) < 0 ) {
        printf ("create %s file with %u  byte ...\n", c_filename, (unsigned int)e9u_lsmd_data->e9u_lsmd_interface->sz_e9u_lsmd_data[ui8_channel]);
        filep = fopen (c_filename, "wb");
        if (filep == NULL)
        {
            perror ("e9u_LSMD_SHM_allocate_data: fopen mmap e9u_lsmd_shadow\n");
            return (e9u_LSMD_ERROR_MALLOC);
        }

        fseek (filep, e9u_lsmd_data->e9u_lsmd_interface->sz_e9u_lsmd_data[ui8_channel] - 1, SEEK_SET);
        putc (0, filep);
        fclose (filep); 
    }

// open file for shared memory
    e9u_lsmd_data->hd_e9u_lsmd_shadow[ui8_channel] = open (c_filename, O_RDWR);
    if (e9u_lsmd_data->hd_e9u_lsmd_shadow[ui8_channel] == -1)
    {
        perror ("e9u_LSMD_SHM_allocate_data: open mmap e9u_lsmd_shadow\n");
        return (e9u_LSMD_ERROR_MALLOC);
    }

    e9u_lsmd_data->ui8_e9u_lsmd_buffer[ui8_channel] = (uint8_t *)malloc (e9u_lsmd_data->e9u_lsmd_interface->sz_e9u_lsmd_data[ui8_channel]);
    if (e9u_lsmd_data->ui8_e9u_lsmd_buffer[ui8_channel] == NULL) {
        perror ("e9u_LSMD_SHM_allocate_data: malloc e9u_lsmd_buffer:");
        return (e9u_LSMD_ERROR_MALLOC);
    }

    e9u_lsmd_data->ui8_e9u_lsmd_shadow[ui8_channel] = mmap (NULL, e9u_lsmd_data->e9u_lsmd_interface->sz_e9u_lsmd_data[ui8_channel], PROT_READ | PROT_WRITE, MAP_SHARED, e9u_lsmd_data->hd_e9u_lsmd_shadow[ui8_channel], 0);
    if (e9u_lsmd_data->ui8_e9u_lsmd_shadow[ui8_channel] == MAP_FAILED) 
    {
        close (e9u_lsmd_data->hd_e9u_lsmd_shadow[ui8_channel]);
        perror ("e9u_LSMD_SHM_allocate_data: mmap e9u_lsmd_shadow\n");
        e9u_lsmd_data->ui8_e9u_lsmd_shadow[ui8_channel] = NULL;
        return (e9u_LSMD_ERROR_MALLOC);
    }

    e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel] = (uint8_t *)malloc (e9u_lsmd_data->e9u_lsmd_interface->sz_e9u_lsmd_data[ui8_channel]);
    if (e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel] == NULL) {
        perror ("e9u_LSMD_SHM_allocate_data: malloc e9u_lsmd_data:");
        return (e9u_LSMD_ERROR_MALLOC);
    }

// copy pointers to other width:
    e9u_lsmd_data->ui16_e9u_lsmd_data[ui8_channel] = (uint16_t *)e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel];
    e9u_lsmd_data->ui32_e9u_lsmd_data[ui8_channel] = (uint32_t *)e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel];
    e9u_lsmd_data->i32_e9u_lsmd_data[ui8_channel]  = (int32_t  *)e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel];

    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status |= e9u_LSMD_ALLOCATED;
    return (e9u_LSMD_OK);
}




/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_SHM_free_memory (struct e9u_LSMD_DATA *e9u_lsmd_data)
{
// actually hard coded channel 0!
uint8_t ui8_channel = 0;

    if (e9u_lsmd_data->ui8_e9u_lsmd_buffer[ui8_channel] != NULL)
        free (e9u_lsmd_data->ui8_e9u_lsmd_buffer[ui8_channel]);

    if (e9u_lsmd_data->ui8_e9u_lsmd_shadow[ui8_channel] != NULL) {
        munmap (e9u_lsmd_data->ui8_e9u_lsmd_shadow[ui8_channel], e9u_lsmd_data->e9u_lsmd_interface->sz_e9u_lsmd_data[ui8_channel]);
        close (e9u_lsmd_data->hd_e9u_lsmd_shadow[ui8_channel]);
    }

    if (e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel] != NULL) {
        free (e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel]);
        e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel]   = NULL;
        e9u_lsmd_data->ui16_e9u_lsmd_data[ui8_channel]  = NULL;
        e9u_lsmd_data->ui32_e9u_lsmd_data[ui8_channel]  = NULL;
        e9u_lsmd_data->i32_e9u_lsmd_data[ui8_channel]   = NULL;
    }

    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status &= ~e9u_LSMD_ALLOCATED;
    e9u_LSMD_SEM_close (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_shadow);
    e9u_LSMD_SEM_close (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
    e9u_LSMD_SEM_close (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);
    
    if (e9u_lsmd_data->e9u_lsmd_interface != NULL) {
        munmap (e9u_lsmd_data->e9u_lsmd_interface, sizeof (struct e9u_LSMD_INTERFACE));
        close (e9u_lsmd_data->hd_e9u_lsmd_interface);
    }

    return (e9u_LSMD_OK);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_SHM_begin (struct e9u_LSMD_DATA *e9u_lsmd_data, const char *c_device, const char *c_mmap_name)
{
uint8_t ui8_register;
int status;

// allocate memory and initialize registers with default values:
    status = e9u_LSMD_SHM_allocate_interface (e9u_lsmd_data, c_mmap_name);
    if (status != e9u_LSMD_OK)
        return (status);

    status = e9u_LSMD_IO_initialize_regs (e9u_lsmd_data);
    if (status != e9u_LSMD_OK)
        return (status);

// set device name and open camera:
    status = e9u_LSMD_IO_set_tty_device (e9u_lsmd_data, c_device);
    if (status != e9u_LSMD_OK)
        return (status);

    status = e9u_LSMD_IO_open_camera (e9u_lsmd_data);
    if (status != e9u_LSMD_OK)
        return (status);

// stop camera twice, just to be sure:
    status = e9u_LSMD_IO_stop_camera (e9u_lsmd_data);
    if (status != e9u_LSMD_OK)
        return (status);

    status = e9u_LSMD_IO_stop_camera (e9u_lsmd_data);
    if (status != e9u_LSMD_OK)
        return (status);

// query registers:
    status = e9u_LSMD_IO_send_reg (e9u_lsmd_data, e9u_LSMD_QUERY_REGS);
    if (status != e9u_LSMD_OK)
        return (status);

    status = e9u_LSMD_IO_sync_camera (e9u_lsmd_data, &ui8_register);
    if (status != e9u_LSMD_OK)
        return (status);
    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status |= e9u_LSMD_QUERIED;

// get e9u_LSMD type:
    status = e9u_LSMD_IO_get_name (e9u_lsmd_data);
    if (status != e9u_LSMD_OK)
        return (status);

// allocate image data:
    status = e9u_LSMD_SHM_allocate_data (e9u_lsmd_data, c_mmap_name);
    if (status != e9u_LSMD_OK)
        return (status);

    return (0);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_SHM_end (struct e9u_LSMD_DATA *e9u_lsmd_data)
{
int status;

// stop camera twice
    status = e9u_LSMD_IO_stop_camera (e9u_lsmd_data);
    if (status != e9u_LSMD_OK)
        return (status);

    status = e9u_LSMD_IO_stop_camera (e9u_lsmd_data);
    if (status != e9u_LSMD_OK)
        return (status);

// free memory and close uart:
    status = e9u_LSMD_IO_close_camera (e9u_lsmd_data);
    if (status != e9u_LSMD_OK)
        return (status);
    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status &= ~e9u_LSMD_VERIFIED;
    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status &= ~e9u_LSMD_QUERIED;

    status = e9u_LSMD_SHM_free_memory (e9u_lsmd_data);

    if (status != e9u_LSMD_OK)
        return (status);

    return (e9u_LSMD_OK);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_SHM_attach (struct e9u_LSMD_DATA *e9u_lsmd_data, const char *c_mmap_name)
{
uint8_t     ui8_channel;
char        c_filename[1024];
struct stat st_filep;


// make sure we have pointers initialized with NULL to detect, if free or close is valid:
    e9u_lsmd_data->e9u_lsmd_interface   = NULL;
    e9u_lsmd_data->i_ttyUSB_open    = 0;

    for (ui8_channel = 0; ui8_channel < 8; ++ui8_channel) {
        e9u_lsmd_data->ui8_e9u_lsmd_buffer[ui8_channel] = NULL;
        e9u_lsmd_data->ui8_e9u_lsmd_shadow[ui8_channel] = NULL;
        e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel]   = NULL;
        e9u_lsmd_data->ui16_e9u_lsmd_data[ui8_channel]  = NULL;
        e9u_lsmd_data->ui32_e9u_lsmd_data[ui8_channel]  = NULL;
        e9u_lsmd_data->i32_e9u_lsmd_data[ui8_channel]   = NULL;
    }


// test, if file for shared memory exists with correct size:
    sprintf (c_filename, "%s.e9u_lsmd_regs.mmap", c_mmap_name);
    if (access (c_filename, F_OK ) >= 0 ) {
        stat (c_filename, &st_filep);
        if (st_filep.st_size != sizeof (struct e9u_LSMD_INTERFACE)) {
            fprintf (stderr, "e9u_LSMD_SHM_attach: mmap e9u_lsmd_interface (%s) wrong size\n", c_filename);
            return (e9u_LSMD_ERROR_MALLOC);
        }
    } else {
        fprintf (stderr, "e9u_LSMD_SHM_attach: mmap e9u_lsmd_interface (%s)  does not exist\n", c_filename);
        return (e9u_LSMD_ERROR_MALLOC);
    }

    
// open file for shared memory:
    e9u_lsmd_data->hd_e9u_lsmd_interface = open (c_filename, O_RDWR);
    if (e9u_lsmd_data->hd_e9u_lsmd_interface == -1)
    {
        perror ("e9u_LSMD_SHM_attach: open mmap e9u_lsmd_interface\n");
        return (e9u_LSMD_ERROR_MALLOC);
    }

// open shared memory:
    e9u_lsmd_data->e9u_lsmd_interface = mmap (NULL, sizeof (struct e9u_LSMD_INTERFACE), PROT_READ | PROT_WRITE, MAP_SHARED, e9u_lsmd_data->hd_e9u_lsmd_interface, 0);
    if (e9u_lsmd_data->e9u_lsmd_interface == MAP_FAILED) 
    {
        close (e9u_lsmd_data->hd_e9u_lsmd_interface);
        perror ("e9u_LSMD_SHM_attach: mmap e9u_lsmd_interface\n");
        e9u_lsmd_data->e9u_lsmd_interface = NULL;
        return (e9u_LSMD_ERROR_MALLOC);
    }


// if camera not final startet, sleep fife seconds to give the server some time:
    if ((e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status & e9u_LSMD_ALLOCATED) == 0)
        e9u_LSMD_SLEEP_ms (5000);


    ui8_channel = 0;
// calculate sizes once:
    e9u_lsmd_data->e9u_lsmd_interface->sz_e9u_lsmd_data[ui8_channel] = sizeof (uint8_t) * e9u_LSMD_IO_get_reg8  (e9u_lsmd_data, e9u_LSMD_CH0_ADC, 3, e9u_LSMD_RX) / 8 * 
                                                         ( e9u_lsmd_data->e9u_lsmd_interface->register_rx[e9u_LSMD_CH0_DARK_PRE].ui16_value[1] 
                                                         + e9u_lsmd_data->e9u_lsmd_interface->register_rx[e9u_LSMD_CH0_PIXEL].ui16_value[1] );


// test, if file for shared memory exists with correct size:
    sprintf (c_filename, "%s.e9u_lsmd_shadow.mmap", c_mmap_name);
    if (access (c_filename, F_OK ) >= 0 ) {
        stat (c_filename, &st_filep);
        if (st_filep.st_size != e9u_lsmd_data->e9u_lsmd_interface->sz_e9u_lsmd_data[ui8_channel]) {
            fprintf (stderr, "e9u_LSMD_SHM_attach: mmap e9u_lsmd_shadow wrong size\n");
            return (e9u_LSMD_ERROR_MALLOC);
        }
    } else {
        fprintf (stderr, "e9u_LSMD_SHM_attach: mmap e9u_lsmd_shadow does not exist\n");
        return (e9u_LSMD_ERROR_MALLOC);
    }


// open file for shared memory
    e9u_lsmd_data->hd_e9u_lsmd_shadow[ui8_channel] = open (c_filename, O_RDWR);
    if (e9u_lsmd_data->hd_e9u_lsmd_shadow[ui8_channel] == -1)
    {
        perror ("e9u_LSMD_SHM_attach: open mmap e9u_lsmd_shadow\n");
        return (e9u_LSMD_ERROR_MALLOC);
    }

    e9u_lsmd_data->ui8_e9u_lsmd_buffer[ui8_channel] = (uint8_t *)malloc (e9u_lsmd_data->e9u_lsmd_interface->sz_e9u_lsmd_data[ui8_channel]);
    if (e9u_lsmd_data->ui8_e9u_lsmd_buffer[ui8_channel] == NULL) {
        perror ("e9u_LSMD_SHM_attach: malloc e9u_lsmd_buffer:");
        return (e9u_LSMD_ERROR_MALLOC);
    }

    e9u_lsmd_data->ui8_e9u_lsmd_shadow[ui8_channel] = mmap (NULL, e9u_lsmd_data->e9u_lsmd_interface->sz_e9u_lsmd_data[ui8_channel], PROT_READ | PROT_WRITE, MAP_SHARED, e9u_lsmd_data->hd_e9u_lsmd_shadow[ui8_channel], 0);
    if (e9u_lsmd_data->ui8_e9u_lsmd_shadow[ui8_channel] == MAP_FAILED) 
    {
        close (e9u_lsmd_data->hd_e9u_lsmd_shadow[ui8_channel]);
        perror ("e9u_LSMD_SHM_attach: mmap e9u_lsmd_shadow\n");
        e9u_lsmd_data->ui8_e9u_lsmd_shadow[ui8_channel] = NULL;
        return (e9u_LSMD_ERROR_MALLOC);
    }

    e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel] = (uint8_t *)malloc (e9u_lsmd_data->e9u_lsmd_interface->sz_e9u_lsmd_data[ui8_channel]);
    if (e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel] == NULL) {
        perror ("e9u_LSMD_SHM_attach: malloc e9u_lsmd_data:");
        return (e9u_LSMD_ERROR_MALLOC);
    }

// copy pointers to other width:
    e9u_lsmd_data->ui16_e9u_lsmd_data[ui8_channel] = (uint16_t *)e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel];
    e9u_lsmd_data->ui32_e9u_lsmd_data[ui8_channel] = (uint32_t *)e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel];
    e9u_lsmd_data->i32_e9u_lsmd_data[ui8_channel]  = (int32_t  *)e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel];

    return (e9u_LSMD_OK);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_SHM_detach (struct e9u_LSMD_DATA *e9u_lsmd_data)
{
// actually hard coded channel 0!
uint8_t ui8_channel = 0;

    if (e9u_lsmd_data->ui8_e9u_lsmd_buffer[ui8_channel] != NULL)
        free (e9u_lsmd_data->ui8_e9u_lsmd_buffer[ui8_channel]);

    if (e9u_lsmd_data->ui8_e9u_lsmd_shadow[ui8_channel] != NULL) {
        munmap (e9u_lsmd_data->ui8_e9u_lsmd_shadow[ui8_channel], e9u_lsmd_data->e9u_lsmd_interface->sz_e9u_lsmd_data[ui8_channel]);
        close (e9u_lsmd_data->hd_e9u_lsmd_shadow[ui8_channel]);
    }

    if (e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel] != NULL) {
        free (e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel]);
        e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel]   = NULL;
        e9u_lsmd_data->ui16_e9u_lsmd_data[ui8_channel]  = NULL;
        e9u_lsmd_data->ui32_e9u_lsmd_data[ui8_channel]  = NULL;
        e9u_lsmd_data->i32_e9u_lsmd_data[ui8_channel]   = NULL;
    }

    e9u_LSMD_SEM_close (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_shadow);
    e9u_LSMD_SEM_close (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
    e9u_LSMD_SEM_close (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);
    
    if (e9u_lsmd_data->e9u_lsmd_interface != NULL) {
        munmap (e9u_lsmd_data->e9u_lsmd_interface, sizeof (struct e9u_LSMD_INTERFACE));
        close (e9u_lsmd_data->hd_e9u_lsmd_interface);
    }

    return (e9u_LSMD_OK);
}

#endif // ifdef __linux__
