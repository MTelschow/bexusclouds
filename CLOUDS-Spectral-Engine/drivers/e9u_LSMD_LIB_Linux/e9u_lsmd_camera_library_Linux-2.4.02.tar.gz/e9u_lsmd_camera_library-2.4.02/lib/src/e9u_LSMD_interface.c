/*
    EURECA's e9u_LSMD camera software – connect to a e9u_LSMD camera USB module
    Copyright (C) 2020 - 2022 Eureca Messtechnik GmbH, <info@eureca.de>

	This file is part of EURECA's e9u_LSMD camera software.

	EURECA's e9u_LSMD camera software is free software: you can redistribute
	it and/or modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation, either
	version 3 of the License, or (at your option) any later version.

	EURECA's e9u_LSMD camera software is distributed in the hope that it
	will be useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
	See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
	along with Foobar.  If not, see <http://www.gnu.org/licenses/>.



    Diese Datei ist Teil von EURECAs e9u_LSMD Kamera-Software.

	EURECAs e9u_LSMD Kamera-Software ist Freie Software: Sie können sie
	unter den Bedingungen der GNU Lesser General Public License, wie von
	der Free Software Foundation, Version 3 der Lizenz oder (nach Ihrer
	Wahl) jeder neueren veröffentlichten Version, weiter verteilen
	und/oder modifizieren.

	EURECAs e9u_LSMD Kamera-Software wird in der Hoffnung, dass es nützlich
	sein wird, aber OHNE JEDE GEWÄHRLEISTUNG, bereitgestellt; sogar ohne
	die implizite Gewährleistung der MARKTFÄHIGKEIT oder EIGNUNG FÜR
	EINEN BESTIMMTEN ZWECK.  Siehe die GNU General Public License für
	weitere Details.

    Sie sollten eine Kopie der GNU General Public License zusammen mit diesem
    Programm erhalten haben. Wenn nicht, siehe <https://www.gnu.org/licenses/>.

*/

// include for "printf"
#include <stdio.h>

// include for "malloc" and "exit"
#include <stdlib.h>

// include for fixed length integer
#include <stdint.h>

// include for "memset" and "strlen"
#include <string.h>

#include "e9u_LSMD_defs.h"
#include "e9u_LSMD_interface.h"


struct e9u_LSMD_TYPE e9u_LSMD_type[] = { {0x02290001, 0x21110101, "e9u_LSMD-TCD1304-ECO", {""}, 8., 200.,  100,  100, 10000, 1000, e9u_LSMD_EXP_INT | e9u_LSMD_TRIG_INT}, 
                                         {0x02290002, 0x21110101, "e9u_LSMD-TCD1304-STD", {""}, 8., 200.,   10,   10,  7500,   10, e9u_LSMD_EXP_INT | e9u_LSMD_TRIG_INT | e9u_LSMD_TRIG_USB}, 
                                         {0x02290003, 0x21110101, "e9u_LSMD-TCD1304-PRO", {""}, 8., 200.,   10,   10,  3750,   10, e9u_LSMD_EXP_INT | e9u_LSMD_EXP_EXT | e9u_LSMD_TRIG_INT | e9u_LSMD_TRIG_EXT | e9u_LSMD_TRIG_USB | e9u_LSMD_GPIO}, 
                                         {0x02290009, 0x21110101, "e9u_LSMD-TCD1304-TRG", {""}, 8., 200.,   10,   10,  7500,   10, e9u_LSMD_EXP_INT | e9u_LSMD_TRIG_INT | e9u_LSMD_TRIG_EXT | e9u_LSMD_TRIG_USB}, 
                                         {0x02290014, 0x21110101, "e9u_LSMD-TCD1304-PCB", {""}, 8., 200.,   10,   10,  8000,   10, e9u_LSMD_EXP_INT | e9u_LSMD_TRIG_INT | e9u_LSMD_TRIG_EXT | e9u_LSMD_TRIG_USB}, 
                                         {0x02290001, 0x21021801, "e9u_LSMD-TCD1304-ECO", {""}, 8., 200., 1000, 1000, 10000, 1000, e9u_LSMD_EXP_INT | e9u_LSMD_TRIG_INT}, 
                                         {0x02290002, 0x21021801, "e9u_LSMD-TCD1304-STD", {""}, 8., 200.,   10,   10,  8000,   10, e9u_LSMD_EXP_INT | e9u_LSMD_TRIG_INT | e9u_LSMD_TRIG_USB}, 
                                         {0x02290003, 0x21021801, "e9u_LSMD-TCD1304-PRO", {""}, 8., 200.,   10,   10,  3750,   10, e9u_LSMD_EXP_INT | e9u_LSMD_EXP_EXT | e9u_LSMD_TRIG_INT | e9u_LSMD_TRIG_EXT | e9u_LSMD_TRIG_USB | e9u_LSMD_GPIO}, 
                                         {0x02290009, 0x21021801, "e9u_LSMD-TCD1304-TRG", {""}, 8., 200.,   10,   10,  8000,   10, e9u_LSMD_EXP_INT | e9u_LSMD_TRIG_INT | e9u_LSMD_TRIG_EXT | e9u_LSMD_TRIG_USB}, 
                                         {0x02290001, 0x00000000, "e9u_LSMD-TCD1304-ECO", {""}, 8., 200., 1000, 1000, 10000, 1000, e9u_LSMD_EXP_INT | e9u_LSMD_TRIG_INT}, 
                                         {0x02290002, 0x00000000, "e9u_LSMD-TCD1304-STD", {""}, 8., 200.,   10,   10, 10000,   10, e9u_LSMD_EXP_INT | e9u_LSMD_TRIG_INT | e9u_LSMD_TRIG_USB}, 
                                         {0x02290003, 0x00000000, "e9u_LSMD-TCD1304-PRO", {""}, 8., 200.,   10,   10, 10000,   10, e9u_LSMD_EXP_INT | e9u_LSMD_EXP_EXT | e9u_LSMD_TRIG_INT | e9u_LSMD_TRIG_EXT | e9u_LSMD_TRIG_USB | e9u_LSMD_GPIO}, 
                                         {0x02290009, 0x00000000, "e9u_LSMD-TCD1304-TRG", {""}, 8., 200.,   10,   10, 10000,   10, e9u_LSMD_EXP_INT | e9u_LSMD_TRIG_INT | e9u_LSMD_TRIG_EXT | e9u_LSMD_TRIG_USB}, 
                                         {0x02290016, 0x00000000, "e9u_PDMD",             {""}, 0.,   0.,    2,    1,  1000,    1, e9u_LSMD_EXP_INT | e9u_LSMD_EXP_EXT | e9u_LSMD_TRIG_INT | e9u_LSMD_TRIG_EXT | e9u_LSMD_TRIG_USB}, 
                                         {0, 0, "", {""}, 0., 0., 0, 0, 0, 0, 0} };


/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_allocate_interface (struct e9u_LSMD_DATA *e9u_lsmd_data)
{
uint8_t ui8_channel;

// make sure we have pointers initialized with NULL to detect, if free or close is valid:
    e9u_lsmd_data->e9u_lsmd_interface   = NULL;
    e9u_lsmd_data->i_ttyUSB_open    = 0;

    for (ui8_channel = 0; ui8_channel < 8; ++ui8_channel) {
        e9u_lsmd_data->ui8_e9u_lsmd_buffer[ui8_channel] = NULL;
        e9u_lsmd_data->ui8_e9u_lsmd_shadow[ui8_channel] = NULL;
        e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel]   = NULL;
        e9u_lsmd_data->ui16_e9u_lsmd_data[ui8_channel]   = NULL;
        e9u_lsmd_data->ui32_e9u_lsmd_data[ui8_channel]   = NULL;
        e9u_lsmd_data->i32_e9u_lsmd_data[ui8_channel]   = NULL;
    }

    e9u_lsmd_data->e9u_lsmd_interface = (struct e9u_LSMD_INTERFACE *)malloc (sizeof (struct e9u_LSMD_INTERFACE));
    if (e9u_lsmd_data->e9u_lsmd_interface == NULL) {
        perror ("malloc e9u_lsmd_interface:");
        return (e9u_LSMD_ERROR_MALLOC);
    }

// empty strings:
    e9u_lsmd_data->e9u_lsmd_interface->c_ttyUSB_name[0] = 0;
    e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.c_type[0] = 0;
    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status = e9u_LSMD_NONE;
    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_quit   = e9u_LSMD_NONE;
    e9u_LSMD_SEM_create  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_shadow);
    e9u_LSMD_SEM_create  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
    e9u_LSMD_SEM_create  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);

    for (ui8_channel = 0; ui8_channel < 8; ++ui8_channel) {
        e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.c_eeprom[ui8_channel][0] = 0;
        e9u_lsmd_data->e9u_lsmd_interface->ui32_frame_count_shadow[ui8_channel] = 0;
        e9u_lsmd_data->e9u_lsmd_interface->ui32_frame_count_data[ui8_channel]   = 0;
        e9u_lsmd_data->e9u_lsmd_interface->sz_e9u_lsmd_data[ui8_channel] = 0;
    }
    
    return (e9u_LSMD_OK);
}




/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_initialize_regs (struct e9u_LSMD_DATA *e9u_lsmd_data)
{
uint16_t ui16_register;

// initialize registers:
    for (ui16_register = 0; ui16_register < 256; ++ui16_register) {
        e9u_lsmd_data->e9u_lsmd_interface->register_tx[ui16_register].ui8_register = ui16_register;
        e9u_lsmd_data->e9u_lsmd_interface->register_tx[ui16_register].ui32_value   = 0;
        e9u_lsmd_data->e9u_lsmd_interface->register_tx[ui16_register].ui8_status   = 0;
        e9u_lsmd_data->e9u_lsmd_interface->register_rx[ui16_register].ui8_register = ui16_register;
        e9u_lsmd_data->e9u_lsmd_interface->register_rx[ui16_register].ui32_value   = 0;
        e9u_lsmd_data->e9u_lsmd_interface->register_rx[ui16_register].ui8_status   = 0;
        e9u_lsmd_data->e9u_lsmd_interface->register_shadow[ui16_register].ui8_register = ui16_register;
        e9u_lsmd_data->e9u_lsmd_interface->register_shadow[ui16_register].ui32_value   = 0;
        e9u_lsmd_data->e9u_lsmd_interface->register_shadow[ui16_register].ui8_status   = 0;
        e9u_lsmd_data->e9u_lsmd_interface->register_data[ui16_register].ui8_register = ui16_register;
        e9u_lsmd_data->e9u_lsmd_interface->register_data[ui16_register].ui32_value   = 0;
        e9u_lsmd_data->e9u_lsmd_interface->register_data[ui16_register].ui8_status   = 0;
    }
 
    e9u_lsmd_data->e9u_lsmd_interface->register_tx[e9u_LSMD_QUERY_REGS].ui32_value     = 0xffffffff;
    e9u_lsmd_data->e9u_lsmd_interface->register_tx[e9u_LSMD_STAY_ALIVE].ui32_value     = 0xffffffff;

    return (e9u_LSMD_OK);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_set_tty_device (struct e9u_LSMD_DATA *e9u_lsmd_data, const char *c_device)
{
    strcpy (e9u_lsmd_data->e9u_lsmd_interface->c_ttyUSB_name, c_device);
    return (e9u_LSMD_OK);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_add_status_flag (struct e9u_LSMD_DATA *e9u_lsmd_data, int i_flag)
{
    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status |= i_flag;
    return (e9u_LSMD_OK);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_remove_status_flag (struct e9u_LSMD_DATA *e9u_lsmd_data, int i_flag)
{
    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status &= ~i_flag;
    return (e9u_LSMD_OK);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_get_status_flag (struct e9u_LSMD_DATA *e9u_lsmd_data)
{
    return (e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_open_camera(struct e9u_LSMD_DATA* e9u_lsmd_data)
{
int status;

    status = e9u_LSMD_UART_open(&e9u_lsmd_data->e9u_lsmd_interface->hd_ttyUSB, e9u_lsmd_data->e9u_lsmd_interface->c_ttyUSB_name);
    if (status == 0) {
        e9u_lsmd_data->i_ttyUSB_open = 1;
        e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status |= e9u_LSMD_OPENED;
    }

    return (status);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_stop_camera (struct e9u_LSMD_DATA *e9u_lsmd_data)
{
int status;

// first sync camera:
    status = e9u_LSMD_IO_send_reg (e9u_lsmd_data, e9u_LSMD_STAY_ALIVE);
    if (status != e9u_LSMD_OK)
        return (status);
    
// then send registers:
    e9u_lsmd_data->e9u_lsmd_interface->register_tx[e9u_LSMD_GLOBAL_CONTROL].ui32_value = 0x00000000;
    status = e9u_LSMD_IO_send_reg (e9u_lsmd_data, e9u_LSMD_GLOBAL_CONTROL);
    if (status != e9u_LSMD_OK)
        return (status);
    
    e9u_lsmd_data->e9u_lsmd_interface->register_tx[e9u_LSMD_CH0_CONTROL].ui32_value    = 0x00000000;
    status = e9u_LSMD_IO_send_reg (e9u_lsmd_data, e9u_LSMD_CH0_CONTROL);
    if (status != e9u_LSMD_OK)
        return (status);

    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status &= ~e9u_LSMD_STARTED;

    status = e9u_LSMD_UART_flush (e9u_lsmd_data->e9u_lsmd_interface->hd_ttyUSB);
    return (status);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_send_reg (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_register)
{
size_t sz_transfered;
int status;

    status = e9u_LSMD_UART_write (e9u_lsmd_data->e9u_lsmd_interface->hd_ttyUSB, (char *)&e9u_lsmd_data->e9u_lsmd_interface->register_tx[ui8_register].ui8_register, sizeof (uint8_t), &sz_transfered);
    if (status != e9u_LSMD_OK)
        return (status);
        
    status = e9u_LSMD_UART_write (e9u_lsmd_data->e9u_lsmd_interface->hd_ttyUSB, (char *)&e9u_lsmd_data->e9u_lsmd_interface->register_tx[ui8_register].ui32_value,   sizeof (uint32_t), &sz_transfered);

    return (status);
}




/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_sync_camera (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t *ui8_register)
{
uint8_t  ui8_value;
uint64_t ui64_sync;
uint64_t ui64_async;
int64_t  i64_skipped;
size_t   sz_transfered = 0;
int      status;
uint8_t  ui8_counter = 0;

// wait for sync:
    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status |= e9u_LSMD_SYNC;
    ui64_sync = 0xaaaaaaaaaaaaaaaa;
    ui64_async = 0xaaaaaaaaaaaaaaaa;
    i64_skipped = 0l;
    do {
        status = e9u_LSMD_UART_read (e9u_lsmd_data->e9u_lsmd_interface->hd_ttyUSB, (char *)&ui8_value, sizeof (uint8_t), &sz_transfered);
        if (status != e9u_LSMD_OK)
            return (status);

        if (sz_transfered == sizeof (uint8_t))
            ui64_sync = ui64_sync << 8 | ui8_value;
            
        if (e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_quit) {
            e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status &= ~e9u_LSMD_SYNC;
            return (e9u_LSMD_QUIT);
        }
        
        ++i64_skipped;
        if (i64_skipped == 8)
            ui64_async = ui64_sync;
            
    } while (ui64_sync != 0xffffffff00000000);
    
    if (i64_skipped != 8)
        printf ("Out of sync: %lX / %ld. Resyncing ...\n", (long unsigned int)ui64_async, (long unsigned int)i64_skipped - 8);

// read registers
    e9u_LSMD_SEM_lock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);
    do {
        status = e9u_LSMD_UART_read (e9u_lsmd_data->e9u_lsmd_interface->hd_ttyUSB, (char *)ui8_register, sizeof (uint8_t),  &sz_transfered);
        if (status != e9u_LSMD_OK) {
            e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);
            return (status);
        }
        
        if (*ui8_register  < e9u_LSMD_DATA_CH0) {
            status = e9u_LSMD_UART_read (e9u_lsmd_data->e9u_lsmd_interface->hd_ttyUSB, (char *)&e9u_lsmd_data->e9u_lsmd_interface->register_rx[*ui8_register].ui32_value, sizeof (uint32_t),  &sz_transfered);
            if (status != e9u_LSMD_OK) {
                e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);
                return (status);
            }
            
            e9u_lsmd_data->e9u_lsmd_interface->register_rx[*ui8_register].ui8_status = 1;
        }


// maximum 240 Registers to read (0x00 to 0xef)
// exit with protocol error, if more:        
        if (++ui8_counter > 240) {
            e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);
            return (e9u_LSMD_ERROR_PROTO);
        }

    } while (*ui8_register < e9u_LSMD_DATA_CH0);


    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status &= ~e9u_LSMD_SYNC;

    e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);
    return (e9u_LSMD_OK);
}




/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_allocate_data (struct e9u_LSMD_DATA *e9u_lsmd_data)
{
// actually hard coded channel 0!
uint8_t ui8_channel = 0;

// calculate sizes once:
    e9u_lsmd_data->e9u_lsmd_interface->sz_e9u_lsmd_data[ui8_channel] = e9u_LSMD_IO_get_reg8  (e9u_lsmd_data, e9u_LSMD_CH0_ADC, 3, e9u_LSMD_RX) / 8;
    e9u_lsmd_data->e9u_lsmd_interface->sz_e9u_lsmd_data[ui8_channel] *=
                                                         ( e9u_lsmd_data->e9u_lsmd_interface->register_rx[e9u_LSMD_CH0_DARK_PRE].ui16_value[1] 
                                                         + e9u_lsmd_data->e9u_lsmd_interface->register_rx[e9u_LSMD_CH0_PIXEL].ui16_value[1] );

    e9u_lsmd_data->ui8_e9u_lsmd_buffer[ui8_channel] = (uint8_t *)malloc (e9u_lsmd_data->e9u_lsmd_interface->sz_e9u_lsmd_data[ui8_channel]);
    if (e9u_lsmd_data->ui8_e9u_lsmd_buffer[ui8_channel] == NULL) {
        perror ("malloc e9u_lsmd_buffer:");
        return (e9u_LSMD_ERROR_MALLOC);
    }

    e9u_lsmd_data->ui8_e9u_lsmd_shadow[ui8_channel] = (uint8_t *)malloc (e9u_lsmd_data->e9u_lsmd_interface->sz_e9u_lsmd_data[ui8_channel]);
    if (e9u_lsmd_data->ui8_e9u_lsmd_shadow[ui8_channel] == NULL) {
        perror ("malloc e9u_lsmd_shadow:");
        return (e9u_LSMD_ERROR_MALLOC);
    }

    e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel] = (uint8_t *)malloc (e9u_lsmd_data->e9u_lsmd_interface->sz_e9u_lsmd_data[ui8_channel]);
    if (e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel] == NULL) {
        perror ("malloc e9u_lsmd_data:");
        return (e9u_LSMD_ERROR_MALLOC);
    }
// copy pointers to other width:
    e9u_lsmd_data->ui16_e9u_lsmd_data[ui8_channel] = (uint16_t *)e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel];
    e9u_lsmd_data->ui32_e9u_lsmd_data[ui8_channel] = (uint32_t *)e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel];
    e9u_lsmd_data->i32_e9u_lsmd_data[ui8_channel]  = (int32_t  *)e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel];
    
    
    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status |= e9u_LSMD_ALLOCATED;
    return (e9u_LSMD_OK);
}




/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_read_channel (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_channel)
{
size_t   sz_e9u_lsmd_data_size_dark;
size_t   sz_e9u_lsmd_data_size_pixel;
size_t   sz_transfered;
int      status;
uint16_t ui16_register;

// calculate sizes once:
    if (ui8_channel == 0) {
        sz_e9u_lsmd_data_size_dark  = e9u_LSMD_IO_get_reg8  (e9u_lsmd_data, e9u_LSMD_CH0_ADC, 3, e9u_LSMD_RX) / 8;
        sz_e9u_lsmd_data_size_dark  *= e9u_lsmd_data->e9u_lsmd_interface->register_rx[e9u_LSMD_CH0_DARK_PRE].ui16_value[1];
        sz_e9u_lsmd_data_size_pixel = e9u_LSMD_IO_get_reg8  (e9u_lsmd_data, e9u_LSMD_CH0_ADC, 3, e9u_LSMD_RX) / 8;
        sz_e9u_lsmd_data_size_pixel *= e9u_lsmd_data->e9u_lsmd_interface->register_rx[e9u_LSMD_CH0_PIXEL].ui16_value[1];
    } else
        return (e9u_LSMD_ERROR_PROTO);


    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status |= e9u_LSMD_READ;


// read dark pixels from camera to buffer Memory:
    if (sz_e9u_lsmd_data_size_dark > 0) {
        status = e9u_LSMD_UART_read (e9u_lsmd_data->e9u_lsmd_interface->hd_ttyUSB, 
                                 (char *)e9u_lsmd_data->ui8_e9u_lsmd_buffer[ui8_channel],  
                                 sz_e9u_lsmd_data_size_dark, 
                                 &sz_transfered);
        if (status != e9u_LSMD_OK)
            return (status);
    }


// read pixels from camera to buffer Memory:
    status = e9u_LSMD_UART_read (e9u_lsmd_data->e9u_lsmd_interface->hd_ttyUSB, 
                             (char *)e9u_lsmd_data->ui8_e9u_lsmd_buffer[ui8_channel] + sz_e9u_lsmd_data_size_dark, 
                             sz_e9u_lsmd_data_size_pixel,
                             &sz_transfered);

    if (status != e9u_LSMD_OK)
        return (status);


// Copy buffer Memory into shadow / shared Memory and update status:
// wait until user copy is finished:
    e9u_LSMD_SEM_lock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_shadow);
        
    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status |= e9u_LSMD_COPY;
    
    memcpy ((char *)e9u_lsmd_data->ui8_e9u_lsmd_shadow[ui8_channel],  
            (char *)e9u_lsmd_data->ui8_e9u_lsmd_buffer[ui8_channel], 
            e9u_lsmd_data->e9u_lsmd_interface->sz_e9u_lsmd_data[ui8_channel]);

// copy registers for current channel:
    e9u_LSMD_SEM_lock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);
    for (ui16_register = ui8_channel * 16; ui16_register < ui8_channel * 16 + 16; ++ui16_register) {
        e9u_lsmd_data->e9u_lsmd_interface->register_shadow[ui16_register].ui8_register = e9u_lsmd_data->e9u_lsmd_interface->register_rx[ui16_register].ui8_register;
        e9u_lsmd_data->e9u_lsmd_interface->register_shadow[ui16_register].ui32_value   = e9u_lsmd_data->e9u_lsmd_interface->register_rx[ui16_register].ui32_value;
        e9u_lsmd_data->e9u_lsmd_interface->register_shadow[ui16_register].ui8_status   = e9u_lsmd_data->e9u_lsmd_interface->register_rx[ui16_register].ui8_status;
    }
// copy common registers:
    for (ui16_register = 128; ui16_register < 256; ++ui16_register) {
        e9u_lsmd_data->e9u_lsmd_interface->register_shadow[ui16_register].ui8_register = e9u_lsmd_data->e9u_lsmd_interface->register_rx[ui16_register].ui8_register;
        e9u_lsmd_data->e9u_lsmd_interface->register_shadow[ui16_register].ui32_value   = e9u_lsmd_data->e9u_lsmd_interface->register_rx[ui16_register].ui32_value;
        e9u_lsmd_data->e9u_lsmd_interface->register_shadow[ui16_register].ui8_status   = e9u_lsmd_data->e9u_lsmd_interface->register_rx[ui16_register].ui8_status;
    }
    e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);


    ++e9u_lsmd_data->e9u_lsmd_interface->ui32_frame_count_shadow[ui8_channel];

    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status &= ~e9u_LSMD_READ;
    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status &= ~e9u_LSMD_COPY;

// semaphor-unlock
    e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_shadow);
    
    return (e9u_LSMD_OK);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_read_camera (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t *ui8_register)
{
int status;

    status = e9u_LSMD_IO_sync_camera (e9u_lsmd_data, ui8_register);
    if (status != e9u_LSMD_OK)
        return (status);

// if valid pixel data are received, read them:
    if (*ui8_register == e9u_LSMD_DATA_CH0) {
        status = e9u_LSMD_IO_read_channel (e9u_lsmd_data, *ui8_register & 0x0f);
        if (status != e9u_LSMD_OK)
            return (status);
    }
    
    if (e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_quit)
        return (e9u_LSMD_QUIT);

    return (e9u_LSMD_OK);
} 

 
/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int32_t e9u_LSMD_IO_get_dark_value (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_channel, size_t sz_x_position, size_t sz_y_position)
{
    if (e9u_LSMD_IO_get_reg8  (e9u_lsmd_data, e9u_LSMD_CH0_ADC, 3, e9u_LSMD_RX) / 8 == 1)
        return ((int32_t)e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel][sz_x_position]);

    if (e9u_LSMD_IO_get_reg8  (e9u_lsmd_data, e9u_LSMD_CH0_ADC, 3, e9u_LSMD_RX) / 8 == 2)
        return ((int32_t)e9u_lsmd_data->ui16_e9u_lsmd_data[ui8_channel][sz_x_position]);

    if (e9u_LSMD_IO_get_reg8  (e9u_lsmd_data, e9u_LSMD_CH0_ADC, 3, e9u_LSMD_RX) / 8 == 4)
        return ((int32_t)e9u_lsmd_data->i32_e9u_lsmd_data[ui8_channel][sz_x_position]);
        
    return (0);    
}


/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int32_t e9u_LSMD_IO_get_pixel_value (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_channel, size_t sz_x_position, size_t sz_y_position)
{
    if (e9u_LSMD_IO_get_reg8  (e9u_lsmd_data, e9u_LSMD_CH0_ADC, 3, e9u_LSMD_RX) / 8 == 1)
      return (e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel][sz_x_position + e9u_lsmd_data->e9u_lsmd_interface->register_rx[e9u_LSMD_CH0_DARK_PRE].ui16_value[1]]);

    if (e9u_LSMD_IO_get_reg8  (e9u_lsmd_data, e9u_LSMD_CH0_ADC, 3, e9u_LSMD_RX) / 8 == 2)
      return (e9u_lsmd_data->ui16_e9u_lsmd_data[ui8_channel][sz_x_position + e9u_lsmd_data->e9u_lsmd_interface->register_rx[e9u_LSMD_CH0_DARK_PRE].ui16_value[1]]);

    if (e9u_LSMD_IO_get_reg8  (e9u_lsmd_data, e9u_LSMD_CH0_ADC, 3, e9u_LSMD_RX) / 8 == 4)
      return (e9u_lsmd_data->i32_e9u_lsmd_data[ui8_channel][sz_x_position + e9u_lsmd_data->e9u_lsmd_interface->register_rx[e9u_LSMD_CH0_DARK_PRE].ui16_value[1]]);

    return (0);    
}


/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_set_dark_value (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_channel, size_t sz_x_position, size_t sz_y_position, int32_t i32_value)
{
    if (e9u_LSMD_IO_get_reg8  (e9u_lsmd_data, e9u_LSMD_CH0_ADC, 3, e9u_LSMD_RX) / 8 == 1)
        e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel][sz_x_position] = (uint8_t)i32_value;

    if (e9u_LSMD_IO_get_reg8  (e9u_lsmd_data, e9u_LSMD_CH0_ADC, 3, e9u_LSMD_RX) / 8 == 2)
        e9u_lsmd_data->ui16_e9u_lsmd_data[ui8_channel][sz_x_position] = (uint16_t)i32_value;

    if (e9u_LSMD_IO_get_reg8  (e9u_lsmd_data, e9u_LSMD_CH0_ADC, 3, e9u_LSMD_RX) / 8 == 4)
        e9u_lsmd_data->i32_e9u_lsmd_data[ui8_channel][sz_x_position] = (int32_t)i32_value;

    return (0);
}


/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_set_pixel_value (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_channel, size_t sz_x_position, size_t sz_y_position, int32_t i32_value)
{
    if (e9u_LSMD_IO_get_reg8  (e9u_lsmd_data, e9u_LSMD_CH0_ADC, 3, e9u_LSMD_RX) / 8 == 1)
        e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel][sz_x_position + e9u_lsmd_data->e9u_lsmd_interface->register_rx[e9u_LSMD_CH0_DARK_PRE].ui16_value[1]] = (uint8_t)i32_value;

    if (e9u_LSMD_IO_get_reg8  (e9u_lsmd_data, e9u_LSMD_CH0_ADC, 3, e9u_LSMD_RX) / 8 == 2)
        e9u_lsmd_data->ui16_e9u_lsmd_data[ui8_channel][sz_x_position + e9u_lsmd_data->e9u_lsmd_interface->register_rx[e9u_LSMD_CH0_DARK_PRE].ui16_value[1]] = (uint16_t)i32_value;

    if (e9u_LSMD_IO_get_reg8  (e9u_lsmd_data, e9u_LSMD_CH0_ADC, 3, e9u_LSMD_RX) / 8 == 4)
        e9u_lsmd_data->i32_e9u_lsmd_data[ui8_channel][sz_x_position + e9u_lsmd_data->e9u_lsmd_interface->register_rx[e9u_LSMD_CH0_DARK_PRE].ui16_value[1]] = (int32_t)i32_value;

    return (0);
}


/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
uint32_t e9u_LSMD_IO_get_frame_counter (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_channel)
{
    return (e9u_lsmd_data->e9u_lsmd_interface->ui32_frame_count_data[ui8_channel]);
}


/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
uint32_t e9u_LSMD_IO_check_new_frames (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_channel)
{
    return (e9u_LSMD_IO_diff32 (e9u_lsmd_data->e9u_lsmd_interface->ui32_frame_count_shadow[ui8_channel], e9u_lsmd_data->e9u_lsmd_interface->ui32_frame_count_data[ui8_channel]));
}


/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
uint32_t e9u_LSMD_IO_diff32 (uint32_t ui32_minuend, uint32_t ui32_subtrahend)
{
    if (ui32_minuend < ui32_subtrahend)
        return ((4294967295 - ui32_subtrahend) + ui32_minuend);
    else
        return (ui32_minuend - ui32_subtrahend);
}


/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_update_memory (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_channel)
{
uint16_t ui16_register;

// currently only channel 0 supported:
    if (ui8_channel != 0) 
        return (e9u_LSMD_ERROR_PROTO);

// request locking:
    e9u_LSMD_SEM_lock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_shadow);

// Copy shared / shadow Memory into data Memory and update status:
    memcpy ((char *)e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel],  
            (char *)e9u_lsmd_data->ui8_e9u_lsmd_shadow[ui8_channel], 
            e9u_lsmd_data->e9u_lsmd_interface->sz_e9u_lsmd_data[ui8_channel]);

// copy registers:
    for (ui16_register = 0; ui16_register < 256; ++ui16_register) {
        e9u_lsmd_data->e9u_lsmd_interface->register_data[ui16_register].ui8_register = e9u_lsmd_data->e9u_lsmd_interface->register_shadow[ui16_register].ui8_register;
        e9u_lsmd_data->e9u_lsmd_interface->register_data[ui16_register].ui32_value   = e9u_lsmd_data->e9u_lsmd_interface->register_shadow[ui16_register].ui32_value;
        e9u_lsmd_data->e9u_lsmd_interface->register_data[ui16_register].ui8_status   = e9u_lsmd_data->e9u_lsmd_interface->register_shadow[ui16_register].ui8_status;
    }
    e9u_lsmd_data->e9u_lsmd_interface->ui32_frame_count_data[ui8_channel] = e9u_lsmd_data->e9u_lsmd_interface->ui32_frame_count_shadow[ui8_channel];

    e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_shadow);

    return (0);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_set_reg (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_register, uint32_t ui32_value)
{
    e9u_LSMD_SEM_lock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
    e9u_lsmd_data->e9u_lsmd_interface->register_tx[ui8_register].ui32_value = ui32_value;
    e9u_lsmd_data->e9u_lsmd_interface->register_tx[ui8_register].ui8_status = 1;
    e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
    return (0);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_overwrite_reg32 (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_register, uint32_t ui32_value, uint8_t ui8_rx_tx)
{
    if (ui8_rx_tx) {
        e9u_LSMD_SEM_lock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
        e9u_lsmd_data->e9u_lsmd_interface->register_tx[ui8_register].ui32_value = ui32_value;
        e9u_lsmd_data->e9u_lsmd_interface->register_tx[ui8_register].ui8_status = 1;
        e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
    } else {
        e9u_LSMD_SEM_lock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);
        e9u_lsmd_data->e9u_lsmd_interface->register_rx[ui8_register].ui32_value = ui32_value;
        e9u_lsmd_data->e9u_lsmd_interface->register_rx[ui8_register].ui8_status = 1;
        e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);
    }

    return (0);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_overwrite_reg16 (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_register, uint16_t ui16_value, uint8_t ui8_index, uint8_t ui8_rx_tx)
{
    if (ui8_rx_tx) {
        e9u_LSMD_SEM_lock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
        e9u_lsmd_data->e9u_lsmd_interface->register_tx[ui8_register].ui16_value[ui8_index] = ui16_value;
        e9u_lsmd_data->e9u_lsmd_interface->register_tx[ui8_register].ui8_status = 1;
        e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
    } else {
        e9u_LSMD_SEM_lock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);
        e9u_lsmd_data->e9u_lsmd_interface->register_rx[ui8_register].ui16_value[ui8_index] = ui16_value;
        e9u_lsmd_data->e9u_lsmd_interface->register_rx[ui8_register].ui8_status = 1;
        e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);
    }

    return (0);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_overwrite_reg8 (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_register, uint8_t ui8_value, uint8_t ui8_index, uint8_t ui8_rx_tx)
{
    if (ui8_rx_tx) {
        e9u_LSMD_SEM_lock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
        e9u_lsmd_data->e9u_lsmd_interface->register_tx[ui8_register].ui8_value[ui8_index] = ui8_value;
        e9u_lsmd_data->e9u_lsmd_interface->register_tx[ui8_register].ui8_status = 1;
        e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
    } else {
        e9u_LSMD_SEM_lock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);
        e9u_lsmd_data->e9u_lsmd_interface->register_rx[ui8_register].ui8_value[ui8_index] = ui8_value;
        e9u_lsmd_data->e9u_lsmd_interface->register_rx[ui8_register].ui8_status = 1;
        e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);
    }

    return (0);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
uint32_t e9u_LSMD_IO_get_reg32 (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_register, uint8_t ui8_rx_tx)
{
uint32_t ui32_result;

    switch (ui8_rx_tx) {
        case e9u_LSMD_TX: e9u_LSMD_SEM_lock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
                          ui32_result = e9u_lsmd_data->e9u_lsmd_interface->register_tx[ui8_register].ui32_value;
                          e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
                          break;

        case e9u_LSMD_RX: e9u_LSMD_SEM_lock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);
                          ui32_result = e9u_lsmd_data->e9u_lsmd_interface->register_rx[ui8_register].ui32_value;
                          e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);
                          break;
                          
        case e9u_LSMD_SH: e9u_LSMD_SEM_lock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_shadow);
                          ui32_result = e9u_lsmd_data->e9u_lsmd_interface->register_shadow[ui8_register].ui32_value;
                          e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_shadow);
                          break;

        default:          ui32_result = e9u_lsmd_data->e9u_lsmd_interface->register_data[ui8_register].ui32_value;
    }
                          
    return (ui32_result);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
uint16_t e9u_LSMD_IO_get_reg16 (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_register, uint8_t ui8_index, uint8_t ui8_rx_tx)
{
uint16_t ui16_result;


    switch (ui8_rx_tx) {
        case e9u_LSMD_TX: e9u_LSMD_SEM_lock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
                          ui16_result = e9u_lsmd_data->e9u_lsmd_interface->register_tx[ui8_register].ui16_value[ui8_index];
                          e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
                          break;

        case e9u_LSMD_RX: e9u_LSMD_SEM_lock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);
                          ui16_result = e9u_lsmd_data->e9u_lsmd_interface->register_rx[ui8_register].ui16_value[ui8_index];
                          e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);
                          break;
                          
        case e9u_LSMD_SH: e9u_LSMD_SEM_lock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_shadow);
                          ui16_result = e9u_lsmd_data->e9u_lsmd_interface->register_shadow[ui8_register].ui16_value[ui8_index];
                          e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_shadow);
                          break;

        default:          ui16_result = e9u_lsmd_data->e9u_lsmd_interface->register_data[ui8_register].ui16_value[ui8_index];
    }


    return (ui16_result);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
uint8_t e9u_LSMD_IO_get_reg8 (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_register, uint8_t ui8_index, uint8_t ui8_rx_tx)
{
uint8_t ui8_result;

    switch (ui8_rx_tx) {
        case e9u_LSMD_TX: e9u_LSMD_SEM_lock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
                          ui8_result = e9u_lsmd_data->e9u_lsmd_interface->register_tx[ui8_register].ui8_value[ui8_index];
                          e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
                          break;

        case e9u_LSMD_RX: e9u_LSMD_SEM_lock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);
                          ui8_result = e9u_lsmd_data->e9u_lsmd_interface->register_rx[ui8_register].ui8_value[ui8_index];
                          e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);
                          break;
                          
        case e9u_LSMD_SH: e9u_LSMD_SEM_lock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_shadow);
                          ui8_result = e9u_lsmd_data->e9u_lsmd_interface->register_shadow[ui8_register].ui8_value[ui8_index];
                          e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_shadow);
                          break;

        default:          ui8_result = e9u_lsmd_data->e9u_lsmd_interface->register_data[ui8_register].ui8_value[ui8_index];
    }
    
    return (ui8_result);
}


 

/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_update_regs (struct e9u_LSMD_DATA *e9u_lsmd_data)
{
uint16_t ui16_register;
uint8_t  ui8_flag = 0;
int      status;

    e9u_LSMD_SEM_lock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
// first check, if any register changed:
    for (ui16_register = 0; ui16_register < 256; ++ui16_register)
        if (e9u_lsmd_data->e9u_lsmd_interface->register_tx[ui16_register].ui8_status)
            ui8_flag = 1;

// if no update neccessary, quit:
    if (!ui8_flag) {
        e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
        return (0);
    }        
        
// first sync camera once, then send registers:
    status = e9u_LSMD_IO_send_reg (e9u_lsmd_data, e9u_LSMD_STAY_ALIVE);
    if (status != e9u_LSMD_OK) {
        e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
        return (status);
    }
    
    for (ui16_register = 0; ui16_register < 256; ++ui16_register)
        if (e9u_lsmd_data->e9u_lsmd_interface->register_tx[ui16_register].ui8_status) {
            status = e9u_LSMD_IO_send_reg (e9u_lsmd_data, ui16_register);
            if (status != e9u_LSMD_OK) {
                e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
                return (status);
            }
                
// update status of registers:
            e9u_lsmd_data->e9u_lsmd_interface->register_tx[ui16_register].ui8_status = 0;
        }

    e9u_LSMD_SEM_unlock  (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
    return (e9u_LSMD_OK);
}




/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_close_camera (struct e9u_LSMD_DATA *e9u_lsmd_data)
{
int status = e9u_LSMD_OK;
    
    if (e9u_lsmd_data->i_ttyUSB_open != 0)
        status = e9u_LSMD_UART_close (e9u_lsmd_data->e9u_lsmd_interface->hd_ttyUSB);

    e9u_lsmd_data->i_ttyUSB_open = 0;
    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status &= ~e9u_LSMD_OPENED;
    return (status);
}




/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_free_memory (struct e9u_LSMD_DATA *e9u_lsmd_data)
{
// actually hard coded channel 0!
uint8_t ui8_channel = 0;

    if (e9u_lsmd_data->ui8_e9u_lsmd_buffer[ui8_channel] != NULL)
        free (e9u_lsmd_data->ui8_e9u_lsmd_buffer[ui8_channel]);

    if (e9u_lsmd_data->ui8_e9u_lsmd_shadow[ui8_channel] != NULL)
        free (e9u_lsmd_data->ui8_e9u_lsmd_shadow[ui8_channel]);

    if (e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel] != NULL) {
        free (e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel]);
        e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel]   = NULL;
        e9u_lsmd_data->ui16_e9u_lsmd_data[ui8_channel]   = NULL;
        e9u_lsmd_data->ui32_e9u_lsmd_data[ui8_channel]   = NULL;
        e9u_lsmd_data->i32_e9u_lsmd_data[ui8_channel]   = NULL;
    }
    
    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status &= ~e9u_LSMD_ALLOCATED;
    e9u_LSMD_SEM_close (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_shadow);
    e9u_LSMD_SEM_close (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_tx);
    e9u_LSMD_SEM_close (&e9u_lsmd_data->e9u_lsmd_interface->h_semaphore_register_rx);
    
    if (e9u_lsmd_data->e9u_lsmd_interface != NULL)
        free (e9u_lsmd_data->e9u_lsmd_interface);

    return (e9u_LSMD_OK);
}





/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_begin (struct e9u_LSMD_DATA *e9u_lsmd_data, const char *c_device)
{
uint8_t ui8_register;
int status;

// allocate memory and initialize registers with default values:
    status = e9u_LSMD_IO_allocate_interface (e9u_lsmd_data);
    if (status != e9u_LSMD_OK)
        return (status);

    status = e9u_LSMD_IO_initialize_regs (e9u_lsmd_data);
    if (status != e9u_LSMD_OK)
        return (status);

// set device name and open camera:
    status = e9u_LSMD_IO_set_tty_device (e9u_lsmd_data, c_device);
    if (status != e9u_LSMD_OK)
        return (status);

    status = e9u_LSMD_IO_open_camera (e9u_lsmd_data);
    if (status != e9u_LSMD_OK)
        return (status);

// stop camera twice, just to be sure:
    status = e9u_LSMD_IO_stop_camera (e9u_lsmd_data);
    if (status != e9u_LSMD_OK)
        return (status);

    status = e9u_LSMD_IO_stop_camera (e9u_lsmd_data);
    if (status != e9u_LSMD_OK)
        return (status);

// query registers:
    status = e9u_LSMD_IO_send_reg (e9u_lsmd_data, e9u_LSMD_QUERY_REGS);
    if (status != e9u_LSMD_OK)
        return (status);

    status = e9u_LSMD_IO_sync_camera (e9u_lsmd_data, &ui8_register);
    if (status != e9u_LSMD_OK)
        return (status);
    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status |= e9u_LSMD_QUERIED;

// get e9u_LSMD type:
    status = e9u_LSMD_IO_get_name (e9u_lsmd_data);
    if (status != e9u_LSMD_OK)
        return (status);

// allocate image data:
    status = e9u_LSMD_IO_allocate_data (e9u_lsmd_data);
    if (status != e9u_LSMD_OK)
        return (status);

    return (0);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_end (struct e9u_LSMD_DATA *e9u_lsmd_data)
{
int status;

    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_quit |= e9u_LSMD_REQUEST_QUIT;
    
    do {
       e9u_LSMD_SLEEP_ms (1);
    } while (e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status &= e9u_LSMD_THREAD);

// stop camera twice
    status = e9u_LSMD_IO_stop_camera (e9u_lsmd_data);
    if (status != e9u_LSMD_OK)
        return (status);

    status = e9u_LSMD_IO_stop_camera (e9u_lsmd_data);
    if (status != e9u_LSMD_OK)
        return (status);

// free memory and close uart:
    status = e9u_LSMD_IO_close_camera (e9u_lsmd_data);
    if (status != e9u_LSMD_OK)
        return (status);
    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status &= ~e9u_LSMD_VERIFIED;
    e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status &= ~e9u_LSMD_QUERIED;

    status = e9u_LSMD_IO_free_memory (e9u_lsmd_data);

    if (status != e9u_LSMD_OK)
        return (status);

    return (e9u_LSMD_OK);
}


/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_get_name (struct e9u_LSMD_DATA *e9u_lsmd_data)
{
uint16_t ui16_counter = 0;

// compatibility for older versions:
// do not check for BOARD and VENDOR and overwrite these values
    if (e9u_LSMD_IO_get_reg32 (e9u_lsmd_data, e9u_LSMD_FPGA_VERSION, e9u_LSMD_RX) < 0x20111101) {
        e9u_LSMD_IO_overwrite_reg32 (e9u_lsmd_data, e9u_LSMD_VENDOR, 0x027505C3, e9u_LSMD_RX);
        e9u_LSMD_IO_overwrite_reg32 (e9u_lsmd_data, e9u_LSMD_BOARD_TYPE, 0x504d4f44, e9u_LSMD_RX);
    }        

// check for BOARD and VENDOR
    if (e9u_LSMD_IO_get_reg32 (e9u_lsmd_data, e9u_LSMD_VENDOR, e9u_LSMD_RX) != 0x027505C3)
        return (e9u_LSMD_WARNING_UNKOWN);

    if ( (e9u_LSMD_IO_get_reg32 (e9u_lsmd_data, e9u_LSMD_BOARD_TYPE, e9u_LSMD_RX) != 0x504d4f44)
      && (e9u_LSMD_IO_get_reg32 (e9u_lsmd_data, e9u_LSMD_BOARD_TYPE, e9u_LSMD_RX) != 0x4c534d44)
      && (e9u_LSMD_IO_get_reg32 (e9u_lsmd_data, e9u_LSMD_BOARD_TYPE, e9u_LSMD_RX) != 0x50444d44) )
        return (e9u_LSMD_WARNING_UNKOWN);
    
    do {
        if ( (e9u_LSMD_type[ui16_counter].ui32_type == e9u_lsmd_data->e9u_lsmd_interface->register_rx[e9u_LSMD_CH0_TYPE].ui32_value) 
          && (e9u_LSMD_type[ui16_counter].ui32_fpga_version <= e9u_lsmd_data->e9u_lsmd_interface->register_rx[e9u_LSMD_FPGA_VERSION].ui32_value) ) {
            e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.ui32_type         = e9u_LSMD_type[ui16_counter].ui32_type;
            e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.ui32_fpga_version = e9u_LSMD_type[ui16_counter].ui32_fpga_version;
            strcpy (e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.c_type,     e9u_LSMD_type[ui16_counter].c_type);
            e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.d_pixel_width     = e9u_LSMD_type[ui16_counter].d_pixel_width;
            e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.d_pixel_height    = e9u_LSMD_type[ui16_counter].d_pixel_height;
            e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.ui32_min_exp      = e9u_LSMD_type[ui16_counter].ui32_min_exp;
            e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.ui32_step_exp      = e9u_LSMD_type[ui16_counter].ui32_step_exp;
            e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.ui32_min_frame    = e9u_LSMD_type[ui16_counter].ui32_min_frame;
            e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.ui32_step_frame    = e9u_LSMD_type[ui16_counter].ui32_step_frame;
            e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.ui32_features     = e9u_LSMD_type[ui16_counter].ui32_features;
            e9u_lsmd_data->e9u_lsmd_interface->i_e9u_lsmd_status |= e9u_LSMD_VERIFIED;
            return (e9u_LSMD_OK);
        }
        
        ++ui16_counter;
    } while (e9u_LSMD_type[ui16_counter].ui32_type > 0);

    return (e9u_LSMD_WARNING_UNKOWN);
}




/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_board_info (struct e9u_LSMD_DATA *e9u_lsmd_data)
{
    printf ("EURECA Messtechnik GmbH: %s\n", e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.c_type);

    printf ("Board_Type: %02X.%02X.%04X\n", 
            e9u_LSMD_IO_get_reg8  (e9u_lsmd_data, e9u_LSMD_CH0_TYPE, 3, e9u_LSMD_RX),
            e9u_LSMD_IO_get_reg8  (e9u_lsmd_data, e9u_LSMD_CH0_TYPE, 2, e9u_LSMD_RX),
            e9u_LSMD_IO_get_reg16 (e9u_lsmd_data, e9u_LSMD_CH0_TYPE, 0, e9u_LSMD_RX));

    printf ("FPGA_Version: %08X\n", 
            e9u_LSMD_IO_get_reg32 (e9u_lsmd_data, e9u_LSMD_FPGA_VERSION, e9u_LSMD_RX));

    printf ("Dark_Pixel: %d x %d (ver x hor)\n", 
            e9u_LSMD_IO_get_reg16 (e9u_lsmd_data, e9u_LSMD_CH0_DARK_PRE, e9u_LSMD_VER, e9u_LSMD_RX),
            e9u_LSMD_IO_get_reg16 (e9u_lsmd_data, e9u_LSMD_CH0_DARK_PRE, e9u_LSMD_HOR, e9u_LSMD_RX));

    printf ("Pixel:      %d x %d (ver x hor)\n", 
            e9u_LSMD_IO_get_reg16 (e9u_lsmd_data, e9u_LSMD_CH0_PIXEL, e9u_LSMD_VER, e9u_LSMD_RX),
            e9u_LSMD_IO_get_reg16 (e9u_lsmd_data, e9u_LSMD_CH0_PIXEL, e9u_LSMD_HOR, e9u_LSMD_RX));

    printf ("Transfer:   %d Bits per Pixel\n", 
            e9u_LSMD_IO_get_reg8  (e9u_lsmd_data, e9u_LSMD_CH0_ADC, 3, e9u_LSMD_RX));

    printf ("ADC:        %d Bits @ %1.1f MHz\n", 
            e9u_LSMD_IO_get_reg8  (e9u_lsmd_data, e9u_LSMD_CH0_ADC, 2, 0),
            1000. / e9u_LSMD_IO_get_reg16  (e9u_lsmd_data, e9u_LSMD_CH0_ADC, 0, e9u_LSMD_RX));

    return (e9u_LSMD_OK);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_eeprom_info (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_pcb_number)
{
int status;
char c_i2c_data[32];
uint8_t ui8_i2c_address;
uint8_t ui8_counter;

    if (e9u_LSMD_IO_get_reg32 (e9u_lsmd_data, e9u_LSMD_FPGA_VERSION, e9u_LSMD_RX) < 0x20112701) {
        printf ("i2c eeprom not supported.\n");
        return (e9u_LSMD_OK);
    }

    ui8_i2c_address = 0b10100100 | (ui8_pcb_number << 1);
    c_i2c_data[0] = 0;
    c_i2c_data[1] = 0;
    status = e9u_LSMD_IO_I2C_transfer (e9u_lsmd_data, ui8_i2c_address, 2, e9u_LSMD_TX, c_i2c_data);
    if (status != e9u_LSMD_OK)
        return (status);
    e9u_LSMD_SLEEP_ms (10);
    
    ui8_i2c_address = 0b10100101 | (ui8_pcb_number << 1);
    for (ui8_counter = 0; ui8_counter < 8; ++ui8_counter) {
        status = e9u_LSMD_IO_I2C_transfer (e9u_lsmd_data, ui8_i2c_address, 32, e9u_LSMD_RX, c_i2c_data);
        if (status != e9u_LSMD_OK) {
            printf ("error reading i2c eeprom.\n");
            return (e9u_LSMD_OK);
        }
        c_i2c_data[31] = 0;
        printf ("%s\n", c_i2c_data);
        strcpy (e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.c_eeprom[ui8_counter], c_i2c_data);

    }

    return (e9u_LSMD_OK);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
char * e9u_LSMD_IO_board_type (struct e9u_LSMD_DATA *e9u_lsmd_data)
{
    return (e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.c_type);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
char * e9u_LSMD_IO_eeprom_string (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_string)
{
    return (e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.c_eeprom[ui8_string]);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
double e9u_LSMD_IO_pixel_width (struct e9u_LSMD_DATA *e9u_lsmd_data)
{
    return (e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.d_pixel_width);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
double e9u_LSMD_IO_pixel_height (struct e9u_LSMD_DATA *e9u_lsmd_data)
{
    return (e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.d_pixel_height);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
uint32_t e9u_LSMD_IO_minimum_exposure (struct e9u_LSMD_DATA *e9u_lsmd_data)
{
    return (e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.ui32_min_exp);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
uint32_t e9u_LSMD_IO_step_exposure (struct e9u_LSMD_DATA *e9u_lsmd_data)
{
    return (e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.ui32_step_exp);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
uint32_t e9u_LSMD_IO_minimum_frame (struct e9u_LSMD_DATA *e9u_lsmd_data)
{
    return (e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.ui32_min_frame);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
uint32_t e9u_LSMD_IO_step_frame (struct e9u_LSMD_DATA *e9u_lsmd_data)
{
    return (e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.ui32_step_frame);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
uint32_t e9u_LSMD_IO_features (struct e9u_LSMD_DATA *e9u_lsmd_data)
{
    return (e9u_lsmd_data->e9u_lsmd_interface->e9u_lsmd_type.ui32_features);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_I2C_transfer (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_i2c_adress, uint8_t ui8_i2c_count, uint16_t ui16_i2c_writeprotect, char *c_i2c_data)
{
size_t sz_transfered;
int status;

    e9u_lsmd_data->e9u_lsmd_interface->register_tx[e9u_LSMD_I2C].ui8_value[0]  = ui8_i2c_adress;
    e9u_lsmd_data->e9u_lsmd_interface->register_tx[e9u_LSMD_I2C].ui8_value[1]  = ui8_i2c_count;
    e9u_lsmd_data->e9u_lsmd_interface->register_tx[e9u_LSMD_I2C].ui16_value[1] = ui16_i2c_writeprotect;

    status = e9u_LSMD_UART_write (e9u_lsmd_data->e9u_lsmd_interface->hd_ttyUSB, (char *)&e9u_lsmd_data->e9u_lsmd_interface->register_tx[e9u_LSMD_I2C].ui8_register, sizeof (uint8_t), &sz_transfered);
    if (status != e9u_LSMD_OK)
        return (status);
        
    status = e9u_LSMD_UART_write (e9u_lsmd_data->e9u_lsmd_interface->hd_ttyUSB, (char *)&e9u_lsmd_data->e9u_lsmd_interface->register_tx[e9u_LSMD_I2C].ui32_value,   sizeof (uint32_t), &sz_transfered);
    if (status != e9u_LSMD_OK)
        return (status);

    if (ui16_i2c_writeprotect == e9u_LSMD_RX)
        status = e9u_LSMD_UART_read (e9u_lsmd_data->e9u_lsmd_interface->hd_ttyUSB, c_i2c_data, sizeof (char) * ui8_i2c_count, &sz_transfered);
    else
        status = e9u_LSMD_UART_write (e9u_lsmd_data->e9u_lsmd_interface->hd_ttyUSB, c_i2c_data, sizeof (char) * ui8_i2c_count, &sz_transfered);

    return (status);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
void * e9u_LSMD_IO_get_pixel_pointer (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_channel)
{
    return ((void *)e9u_lsmd_data->ui8_e9u_lsmd_data[ui8_channel]);
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int e9u_LSMD_IO_get_byte_per_pixel (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_channel)
{
    return (e9u_LSMD_IO_get_reg8 (e9u_lsmd_data, e9u_LSMD_CH0_ADC, 3, e9u_LSMD_RX) / 8);
}
