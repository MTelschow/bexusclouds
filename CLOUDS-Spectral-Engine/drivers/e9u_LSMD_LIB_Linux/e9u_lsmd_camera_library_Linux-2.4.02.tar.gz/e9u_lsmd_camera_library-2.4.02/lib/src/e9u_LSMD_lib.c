/*
    EURECA's e9u_LSMD camera software – connect to a e9u_LSMD camera USB module
    Copyright (C) 2020 - 2022 Eureca Messtechnik GmbH, <info@eureca.de>

	This file is part of EURECA's e9u_LSMD camera software.

	EURECA's e9u_LSMD camera software is free software: you can redistribute
	it and/or modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation, either
	version 3 of the License, or (at your option) any later version.

	EURECA's e9u_LSMD camera software is distributed in the hope that it
	will be useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
	See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
	along with Foobar.  If not, see <http://www.gnu.org/licenses/>.



    Diese Datei ist Teil von EURECAs e9u_LSMD Kamera-Software.

	EURECAs e9u_LSMD Kamera-Software ist Freie Software: Sie können sie
	unter den Bedingungen der GNU Lesser General Public License, wie von
	der Free Software Foundation, Version 3 der Lizenz oder (nach Ihrer
	Wahl) jeder neueren veröffentlichten Version, weiter verteilen
	und/oder modifizieren.

	EURECAs e9u_LSMD Kamera-Software wird in der Hoffnung, dass es nützlich
	sein wird, aber OHNE JEDE GEWÄHRLEISTUNG, bereitgestellt; sogar ohne
	die implizite Gewährleistung der MARKTFÄHIGKEIT oder EIGNUNG FÜR
	EINEN BESTIMMTEN ZWECK.  Siehe die GNU General Public License für
	weitere Details.

    Sie sollten eine Kopie der GNU General Public License zusammen mit diesem
    Programm erhalten haben. Wenn nicht, siehe <https://www.gnu.org/licenses/>.

*/

// include for "printf"
#include <stdio.h>

// include for fixed length integer
#include <stdint.h>

#include "e9u_LSMD_defs.h"
#include "e9u_LSMD_interface.h"
#include "e9u_LSMD.h"



// make use of C99 Standard 6.7.8.21:
// If there are fewer initializers in a brace-enclosed list than there are elements
// or members of an aggregate, or fewer characters in a string literal used to
// initialize an array of known size than there are elements in the array,
// the remainder of the aggregate shall be initialized implicitly the same
// as objects that have static storage duration.
struct e9u_LSMD_DATA e9u_LSMD_data[16] = { {NULL, 0, {NULL}, {NULL}, {0}, {NULL}, {NULL}, {NULL}, {NULL}, 0}};


/** @brief ??
 * @param[in] ui_camera_index ??
 * @returns ??
 * @todo sanitize input
 */
int DLL_CALL e9u_LSMD_read_camera (unsigned int ui_camera_index)
{
uint8_t ui8_register;
int     status;

    status = e9u_LSMD_IO_read_camera (&e9u_LSMD_data[ui_camera_index], &ui8_register);
    if (status != e9u_LSMD_OK) {
//printf ("%08X\n", status);
        if (status == e9u_LSMD_QUIT)
            return (e9u_LSMD_QUIT);
        else
            return (e9u_LSMD_FAIL);
    }
        
    return (ui8_register);
}    



/** @brief ??
 * @param[??] ui_camera_index ??
 * @param[??] i_flag ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_add_status_flag (unsigned int ui_camera_index, int i_flag)
{
    return (e9u_LSMD_IO_add_status_flag (&e9u_LSMD_data[ui_camera_index], i_flag));
}
    


/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_remove_status_flag (unsigned int ui_camera_index, int i_flag)
{
    return (e9u_LSMD_IO_remove_status_flag (&e9u_LSMD_data[ui_camera_index], i_flag));
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_get_status_flag (unsigned int ui_camera_index)
{
    return (e9u_LSMD_IO_get_status_flag (&e9u_LSMD_data[ui_camera_index]));
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_get_dark_value (unsigned int ui_camera_index, unsigned int ui_channel, unsigned int ui_x_position, unsigned int ui_y_position)
{
    return (e9u_LSMD_IO_get_dark_value (&e9u_LSMD_data[ui_camera_index], ui_channel, ui_x_position, ui_y_position));
}

/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_get_pixel_value (unsigned int ui_camera_index, unsigned int ui_channel, unsigned int ui_x_position, unsigned int ui_y_position)
{
    return (e9u_LSMD_IO_get_pixel_value (&e9u_LSMD_data[ui_camera_index], ui_channel, ui_x_position, ui_y_position));
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_set_dark_value (unsigned int ui_camera_index, unsigned int ui_channel, unsigned int ui_x_position, unsigned int ui_y_position, unsigned int ui_value)
{
    return (e9u_LSMD_IO_set_dark_value (&e9u_LSMD_data[ui_camera_index], ui_channel, ui_x_position, ui_y_position, ui_value));
}

/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_set_pixel_value (unsigned int ui_camera_index, unsigned int ui_channel, unsigned int ui_x_position, unsigned int ui_y_position, unsigned int ui_value)
{
    return (e9u_LSMD_IO_set_pixel_value (&e9u_LSMD_data[ui_camera_index], ui_channel, ui_x_position, ui_y_position, ui_value));
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
unsigned int DLL_CALL e9u_LSMD_get_frame_counter (unsigned int ui_camera_index, unsigned int ui_channel)
{
    return (e9u_LSMD_IO_get_frame_counter (&e9u_LSMD_data[ui_camera_index], ui_channel));
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
unsigned int DLL_CALL e9u_LSMD_check_new_frames (unsigned int ui_camera_index, unsigned int ui_channel)
{
    return (e9u_LSMD_IO_check_new_frames (&e9u_LSMD_data[ui_camera_index], ui_channel));
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
unsigned int DLL_CALL e9u_LSMD_diff32 (unsigned int ui_minuend, unsigned int ui_subtrahend)
{
    return (e9u_LSMD_IO_diff32 (ui_minuend, ui_subtrahend));
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_update_memory (unsigned int ui_camera_index, unsigned int ui_channel)
{
    return (e9u_LSMD_IO_update_memory (&e9u_LSMD_data[ui_camera_index], ui_channel));
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_set_reg (unsigned int ui_camera_index, unsigned int ui_register, unsigned int ui_value)
{
int status;

    status = e9u_LSMD_IO_set_reg (&e9u_LSMD_data[ui_camera_index], ui_register, ui_value);
    if (status != e9u_LSMD_OK)
        return (e9u_LSMD_FAIL);
        
    return (0);
}    
   

/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_overwrite_reg32 (unsigned int ui_camera_index, unsigned int ui_register, unsigned int ui_value, unsigned int ui_rx_tx)
{
    return (e9u_LSMD_IO_overwrite_reg32 (&e9u_LSMD_data[ui_camera_index], ui_register, ui_value, ui_rx_tx));
}

/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_overwrite_reg16 (unsigned int ui_camera_index, unsigned int ui_register, unsigned int ui_value, unsigned int ui_value_index, unsigned int ui_rx_tx)
{
    return (e9u_LSMD_IO_overwrite_reg16 (&e9u_LSMD_data[ui_camera_index], ui_register, ui_value, ui_value_index, ui_rx_tx));
}

/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_overwrite_reg8  (unsigned int ui_camera_index, unsigned int ui_register, unsigned int ui_value, unsigned int ui_value_index, unsigned int ui_rx_tx)
{
    return (e9u_LSMD_IO_overwrite_reg8 (&e9u_LSMD_data[ui_camera_index], ui_register, ui_value, ui_value_index, ui_rx_tx));
}


/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
unsigned int DLL_CALL e9u_LSMD_get_reg32 (unsigned int ui_camera_index, unsigned int ui_register, unsigned int ui_rx_tx)
{
    return (e9u_LSMD_IO_get_reg32 (&e9u_LSMD_data[ui_camera_index], ui_register, ui_rx_tx));
}

/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
unsigned int DLL_CALL e9u_LSMD_get_reg16 (unsigned int ui_camera_index, unsigned int ui_register, unsigned int ui_value_index, unsigned int ui_rx_tx)
{
    return (e9u_LSMD_IO_get_reg16 (&e9u_LSMD_data[ui_camera_index], ui_register, ui_value_index, ui_rx_tx));
}

/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
unsigned int DLL_CALL e9u_LSMD_get_reg8  (unsigned int ui_camera_index, unsigned int ui_register, unsigned int ui_value_index, unsigned int ui_rx_tx)
{
    return (e9u_LSMD_IO_get_reg8  (&e9u_LSMD_data[ui_camera_index], ui_register, ui_value_index, ui_rx_tx));
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_update_regs (unsigned int ui_camera_index)
{
int status;

    status = e9u_LSMD_IO_update_regs (&e9u_LSMD_data[ui_camera_index]);
    if (status != e9u_LSMD_OK)
        return (e9u_LSMD_FAIL);
        
    return (0);
}    



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_begin (unsigned int ui_camera_index, const char *c_device)
{
int status;

    status = e9u_LSMD_IO_begin (&e9u_LSMD_data[ui_camera_index], c_device);
    if (status != e9u_LSMD_OK)
        return (e9u_LSMD_FAIL);
        
    return (0);
}    



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_end (unsigned int ui_camera_index)
{
int status;

    status = e9u_LSMD_IO_end (&e9u_LSMD_data[ui_camera_index]);
    if (status != e9u_LSMD_OK)
        return (e9u_LSMD_FAIL);
        
    return (0);
}    



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_stop (unsigned int ui_camera_index)
{
int status;

    status = e9u_LSMD_IO_stop_camera (&e9u_LSMD_data[ui_camera_index]);
    if (status != e9u_LSMD_OK)
        return (e9u_LSMD_FAIL);
        
    return (0);
}    



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_board_info (unsigned int ui_camera_index)
{
int status;

    status = e9u_LSMD_IO_board_info (&e9u_LSMD_data[ui_camera_index]);
    if (status != e9u_LSMD_OK)
        return (e9u_LSMD_FAIL);
        
    return (0);
}    



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
char * DLL_CALL e9u_LSMD_board_type (unsigned int ui_camera_index)
{
    return (e9u_LSMD_IO_board_type (&e9u_LSMD_data[ui_camera_index]));
}

/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
char * DLL_CALL e9u_LSMD_eeprom_string (unsigned int ui_camera_index, unsigned int ui_string_index)
{
    return (e9u_LSMD_IO_eeprom_string (&e9u_LSMD_data[ui_camera_index], ui_string_index));
}

/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
double DLL_CALL e9u_LSMD_pixel_width (unsigned int ui_camera_index)
{
    return (e9u_LSMD_IO_pixel_width (&e9u_LSMD_data[ui_camera_index]));
}

/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
double DLL_CALL e9u_LSMD_pixel_height (unsigned int ui_camera_index)
{
    return (e9u_LSMD_IO_pixel_height (&e9u_LSMD_data[ui_camera_index]));
}

/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
unsigned int DLL_CALL e9u_LSMD_minimum_exposure (unsigned int ui_camera_index)
{
    return (e9u_LSMD_IO_minimum_exposure (&e9u_LSMD_data[ui_camera_index]));
}

/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
unsigned int DLL_CALL e9u_LSMD_step_exposure (unsigned int ui_camera_index)
{
    return (e9u_LSMD_IO_step_exposure (&e9u_LSMD_data[ui_camera_index]));
}

/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
unsigned int DLL_CALL e9u_LSMD_minimum_frame (unsigned int ui_camera_index)
{
    return (e9u_LSMD_IO_minimum_frame (&e9u_LSMD_data[ui_camera_index]));
}

/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
unsigned int DLL_CALL e9u_LSMD_step_frame (unsigned int ui_camera_index)
{
    return (e9u_LSMD_IO_step_frame (&e9u_LSMD_data[ui_camera_index]));
}

/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
unsigned int DLL_CALL e9u_LSMD_features (unsigned int ui_camera_index)
{
    return (e9u_LSMD_IO_features (&e9u_LSMD_data[ui_camera_index]));
}


/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
void * DLL_CALL e9u_LSMD_get_pixel_pointer (unsigned int ui_camera_index, unsigned int ui_channel)
{
    return (e9u_LSMD_IO_get_pixel_pointer (&e9u_LSMD_data[ui_camera_index], ui_channel));
}


/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_get_byte_per_pixel (unsigned int ui_camera_index, unsigned int ui_channel)
{
    return (e9u_LSMD_IO_get_byte_per_pixel (&e9u_LSMD_data[ui_camera_index], ui_channel));
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_I2C_transfer (unsigned int ui_camera_index, unsigned int ui_i2c_adress, unsigned int ui_i2c_count, unsigned int ui_i2c_writeprotect, char *c_i2c_data)
{
int status;

    status = e9u_LSMD_IO_I2C_transfer (&e9u_LSMD_data[ui_camera_index], ui_i2c_adress, ui_i2c_count, ui_i2c_writeprotect, c_i2c_data);
    if (status != e9u_LSMD_OK)
        return (e9u_LSMD_FAIL);
        
    return (0);
}    



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_eeprom_info (unsigned int ui_camera_index, unsigned int ui_pcb_number)
{
int status;

    status = e9u_LSMD_IO_eeprom_info (&e9u_LSMD_data[ui_camera_index], ui_pcb_number);
    if (status != e9u_LSMD_OK)
        return (e9u_LSMD_FAIL);
        
    return (0);
}    



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_begin_shm (unsigned int ui_camera_index, const char *c_device, const char *c_mmap_name)
{
int status;

    status = e9u_LSMD_SHM_begin (&e9u_LSMD_data[ui_camera_index], c_device, c_mmap_name);
    if (status != e9u_LSMD_OK)
        return (e9u_LSMD_FAIL);
        
    return (0);
}    



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_end_shm (unsigned int ui_camera_index)
{
int status;

    status = e9u_LSMD_SHM_end (&e9u_LSMD_data[ui_camera_index]);
    if (status != e9u_LSMD_OK)
        return (e9u_LSMD_FAIL);
        
    return (0);
}    

/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_attach_shm (unsigned int ui_camera_index, const char *c_mmap_name)
{
int status;

    status = e9u_LSMD_SHM_attach (&e9u_LSMD_data[ui_camera_index], c_mmap_name);
    if (status != e9u_LSMD_OK)
        return (e9u_LSMD_FAIL);
        
    return (0);
}    

/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_detach_shm (unsigned int ui_camera_index)
{
int status;

    status = e9u_LSMD_SHM_detach (&e9u_LSMD_data[ui_camera_index]);
    if (status != e9u_LSMD_OK)
        return (e9u_LSMD_FAIL);
        
    return (0);
}    


