/*
    EURECA's e9u_LSMD camera software – connect to a e9u_LSMD camera USB module
    Copyright (C) 2020 - 2022 Eureca Messtechnik GmbH, <info@eureca.de>

	This file is part of EURECA's e9u_LSMD camera software.

	EURECA's e9u_LSMD camera software is free software: you can redistribute
	it and/or modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation, either
	version 3 of the License, or (at your option) any later version.

	EURECA's e9u_LSMD camera software is distributed in the hope that it
	will be useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
	See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
	along with Foobar.  If not, see <http://www.gnu.org/licenses/>.



    Diese Datei ist Teil von EURECAs e9u_LSMD Kamera-Software.

	EURECAs e9u_LSMD Kamera-Software ist Freie Software: Sie können sie
	unter den Bedingungen der GNU Lesser General Public License, wie von
	der Free Software Foundation, Version 3 der Lizenz oder (nach Ihrer
	Wahl) jeder neueren veröffentlichten Version, weiter verteilen
	und/oder modifizieren.

	EURECAs e9u_LSMD Kamera-Software wird in der Hoffnung, dass es nützlich
	sein wird, aber OHNE JEDE GEWÄHRLEISTUNG, bereitgestellt; sogar ohne
	die implizite Gewährleistung der MARKTFÄHIGKEIT oder EIGNUNG FÜR
	EINEN BESTIMMTEN ZWECK.  Siehe die GNU General Public License für
	weitere Details.

    Sie sollten eine Kopie der GNU General Public License zusammen mit diesem
    Programm erhalten haben. Wenn nicht, siehe <https://www.gnu.org/licenses/>.

*/

int e9u_LSMD_UART_open   (e9u_LSMD_TTY_HANDLE *h_ttyUSB, char* c_devname);
int e9u_LSMD_UART_close  (e9u_LSMD_TTY_HANDLE h_ttyUSB);
int e9u_LSMD_UART_write  (e9u_LSMD_TTY_HANDLE h_ttyUSB, char* c_buffer, size_t sz_count, size_t* sz_written);
int e9u_LSMD_UART_read   (e9u_LSMD_TTY_HANDLE h_ttyUSB, char* c_buffer, size_t sz_count, size_t* sz_read);
int e9u_LSMD_UART_flush  (e9u_LSMD_TTY_HANDLE h_ttyUSB);

int e9u_LSMD_SEM_create  (e9u_LSMD_SEM_HANDLE *h_semaphore);
int e9u_LSMD_SEM_lock    (e9u_LSMD_SEM_HANDLE *h_semaphore);
int e9u_LSMD_SEM_unlock  (e9u_LSMD_SEM_HANDLE *h_semaphore);
int e9u_LSMD_SEM_close   (e9u_LSMD_SEM_HANDLE *h_semaphore);

struct e9u_LSMD_REGISTER { uint8_t          ui8_register;
                           union { uint8_t  ui8_value[4];
                                   uint16_t ui16_value[2];
                                   uint32_t ui32_value; }; 
                           uint8_t          ui8_status; };

struct e9u_LSMD_TYPE { uint32_t    ui32_type;
                       uint32_t    ui32_fpga_version;
                       char        c_type[128]; 
                       char        c_eeprom[8][32];
                       double      d_pixel_width;
                       double      d_pixel_height;
                       uint32_t    ui32_min_exp;
                       uint32_t    ui32_step_exp;
                       uint32_t    ui32_min_frame;
                       uint32_t    ui32_step_frame;
                       uint32_t    ui32_features; };

struct e9u_LSMD_INTERFACE { uint32_t                 ui32_frame_count_shadow[8];
                            uint32_t                 ui32_frame_count_data[8];
                            size_t                   sz_e9u_lsmd_data[8];
                            char                     c_ttyUSB_name[128];
                            e9u_LSMD_TTY_HANDLE      hd_ttyUSB;
                            volatile int             i_e9u_lsmd_status;
                            volatile int             i_e9u_lsmd_quit;
                            e9u_LSMD_SEM_HANDLE      h_semaphore_shadow;
                            e9u_LSMD_SEM_HANDLE      h_semaphore_register_tx;
                            e9u_LSMD_SEM_HANDLE      h_semaphore_register_rx;
                            struct e9u_LSMD_TYPE     e9u_lsmd_type;
                            struct e9u_LSMD_REGISTER register_tx[256];
                            struct e9u_LSMD_REGISTER register_rx[256];
                            struct e9u_LSMD_REGISTER register_shadow[256];
                            struct e9u_LSMD_REGISTER register_data[256]; };


struct e9u_LSMD_DATA { struct e9u_LSMD_INTERFACE *e9u_lsmd_interface;	        // exported via mmap
                       e9u_LSMD_SHM_HANDLE       hd_e9u_lsmd_interface;	        // file descriptor for mmap
                       uint8_t                   *ui8_e9u_lsmd_buffer[8];	// local, used during camera read
                       uint8_t                   *ui8_e9u_lsmd_shadow[8];	// local, fast copy after read
                       e9u_LSMD_SHM_HANDLE       hd_e9u_lsmd_shadow[8]; 	// file descriptors for mmap
                       uint8_t                   *ui8_e9u_lsmd_data[8];	        // exported via mmap
                       uint16_t                  *ui16_e9u_lsmd_data[8];	// exported via mmap, same address as ui8_e9u_lsmd_data
                       uint32_t                  *ui32_e9u_lsmd_data[8];	// exported via mmap, same address as ui8_e9u_lsmd_data
                       int32_t                   *i32_e9u_lsmd_data[8];	        // exported via mmap, same address as ui8_e9u_lsmd_data
                       int                       i_ttyUSB_open; };



int e9u_LSMD_IO_allocate_interface (struct e9u_LSMD_DATA *e9u_lsmd_data);
int e9u_LSMD_IO_initialize_regs (struct e9u_LSMD_DATA *e9u_lsmd_data);
int e9u_LSMD_IO_set_tty_device (struct e9u_LSMD_DATA *e9u_lsmd_data, const char *c_device);
int e9u_LSMD_IO_add_status_flag (struct e9u_LSMD_DATA *e9u_lsmd_data, int i_flag);
int e9u_LSMD_IO_remove_status_flag (struct e9u_LSMD_DATA *e9u_lsmd_data, int i_flag);
int e9u_LSMD_IO_get_status_flag (struct e9u_LSMD_DATA *e9u_lsmd_data);
int e9u_LSMD_IO_open_camera(struct e9u_LSMD_DATA* e9u_lsmd_data);
int e9u_LSMD_IO_send_reg (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_register);
int e9u_LSMD_IO_stop_camera (struct e9u_LSMD_DATA *e9u_lsmd_data);
int e9u_LSMD_IO_sync_camera (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t *ui8_register);
int e9u_LSMD_IO_allocate_data (struct e9u_LSMD_DATA *e9u_lsmd_data);
int e9u_LSMD_IO_read_channel (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_channel);
int e9u_LSMD_IO_read_camera (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t *ui8_register);
int32_t e9u_LSMD_IO_get_dark_value (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_channel, size_t sz_x_position, size_t sz_y_position);
int32_t e9u_LSMD_IO_get_pixel_value (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_channel, size_t sz_x_position, size_t sz_y_position);
int e9u_LSMD_IO_set_dark_value (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_channel, size_t sz_x_position, size_t sz_y_position, int32_t i32_value);
int e9u_LSMD_IO_set_pixel_value (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_channel, size_t sz_x_position, size_t sz_y_position, int32_t i32_value);
uint32_t e9u_LSMD_IO_get_frame_counter (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_channel);
uint32_t e9u_LSMD_IO_check_new_frames (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_channel);
uint32_t e9u_LSMD_IO_diff32 (uint32_t ui32_minuend, uint32_t ui32_subtrahend);
int e9u_LSMD_IO_update_memory (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_channel);
int e9u_LSMD_IO_set_reg (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_register, uint32_t ui32_value);
uint32_t e9u_LSMD_IO_get_reg32 (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_register, uint8_t ui8_rx_tx);
uint16_t e9u_LSMD_IO_get_reg16 (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_register, uint8_t ui8_index, uint8_t ui8_rx_tx);
uint8_t e9u_LSMD_IO_get_reg8 (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_register, uint8_t ui8_index, uint8_t ui8_rx_tx);
int e9u_LSMD_IO_overwrite_reg32 (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_register, uint32_t ui32_value, uint8_t ui8_rx_tx);
int e9u_LSMD_IO_overwrite_reg16 (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_register, uint16_t ui16_value, uint8_t ui8_index, uint8_t ui8_rx_tx);
int e9u_LSMD_IO_overwrite_reg8 (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_register, uint8_t ui8_value, uint8_t ui8_index, uint8_t ui8_rx_tx);
int e9u_LSMD_IO_update_regs (struct e9u_LSMD_DATA *e9u_lsmd_data);
int e9u_LSMD_IO_close_camera (struct e9u_LSMD_DATA *e9u_lsmd_data);
int e9u_LSMD_IO_free_memory (struct e9u_LSMD_DATA *e9u_lsmd_data);
int e9u_LSMD_IO_begin (struct e9u_LSMD_DATA *e9u_lsmd_data, const char *c_device);
int e9u_LSMD_IO_end (struct e9u_LSMD_DATA *e9u_lsmd_data);
int e9u_LSMD_IO_get_name (struct e9u_LSMD_DATA *e9u_lsmd_data);
int e9u_LSMD_IO_board_info (struct e9u_LSMD_DATA *e9u_lsmd_data);
int e9u_LSMD_IO_I2C_transfer (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_i2c_adress, uint8_t ui8_i2c_count, uint16_t ui16_i2c_writeprotect, char *c_i2c_data);
int e9u_LSMD_IO_eeprom_info (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_pcb_number);
char * e9u_LSMD_IO_board_type (struct e9u_LSMD_DATA *e9u_lsmd_data);
char * e9u_LSMD_IO_eeprom_string (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_string);
double e9u_LSMD_IO_pixel_width (struct e9u_LSMD_DATA *e9u_lsmd_data);
double e9u_LSMD_IO_pixel_height (struct e9u_LSMD_DATA *e9u_lsmd_data);
uint32_t e9u_LSMD_IO_minimum_exposure (struct e9u_LSMD_DATA *e9u_lsmd_data);
uint32_t e9u_LSMD_IO_step_exposure (struct e9u_LSMD_DATA *e9u_lsmd_data);
uint32_t e9u_LSMD_IO_minimum_frame (struct e9u_LSMD_DATA *e9u_lsmd_data);
uint32_t e9u_LSMD_IO_step_frame (struct e9u_LSMD_DATA *e9u_lsmd_data);
uint32_t e9u_LSMD_IO_features (struct e9u_LSMD_DATA *e9u_lsmd_data);

void *e9u_LSMD_IO_get_pixel_pointer (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_channel);
int e9u_LSMD_IO_get_byte_per_pixel (struct e9u_LSMD_DATA *e9u_lsmd_data, uint8_t ui8_channel);

int e9u_LSMD_SHM_allocate_interface (struct e9u_LSMD_DATA *e9u_lsmd_data, const char *c_mmap_name);
int e9u_LSMD_SHM_allocate_data (struct e9u_LSMD_DATA *e9u_lsmd_data, const char *c_mmap_name);
int e9u_LSMD_SHM_free_memory (struct e9u_LSMD_DATA *e9u_lsmd_data);
int e9u_LSMD_SHM_begin (struct e9u_LSMD_DATA *e9u_lsmd_data, const char *c_device, const char *c_mmap_name);
int e9u_LSMD_SHM_end (struct e9u_LSMD_DATA *e9u_lsmd_data);
int e9u_LSMD_SHM_attach (struct e9u_LSMD_DATA *e9u_lsmd_data, const char *c_mmap_name);
int e9u_LSMD_SHM_detach (struct e9u_LSMD_DATA *e9u_lsmd_data);

