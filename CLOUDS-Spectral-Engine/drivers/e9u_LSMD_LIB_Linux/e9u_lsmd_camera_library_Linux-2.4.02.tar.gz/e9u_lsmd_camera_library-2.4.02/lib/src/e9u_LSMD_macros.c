/*
    EURECA's e9u_LSMD camera software – connect to a e9u_LSMD camera USB module
    Copyright (C) 2020 - 2022 Eureca Messtechnik GmbH, <info@eureca.de>

	This file is part of EURECA's e9u_LSMD camera software.

	EURECA's e9u_LSMD camera software is free software: you can redistribute
	it and/or modify it under the terms of the GNU Lesser General Public
	License as published by the Free Software Foundation, either
	version 3 of the License, or (at your option) any later version.

	EURECA's e9u_LSMD camera software is distributed in the hope that it
	will be useful, but WITHOUT ANY WARRANTY; without even the implied
	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
	See the GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
	along with Foobar.  If not, see <http://www.gnu.org/licenses/>.



    Diese Datei ist Teil von EURECAs e9u_LSMD Kamera-Software.

	EURECAs e9u_LSMD Kamera-Software ist Freie Software: Sie können sie
	unter den Bedingungen der GNU Lesser General Public License, wie von
	der Free Software Foundation, Version 3 der Lizenz oder (nach Ihrer
	Wahl) jeder neueren veröffentlichten Version, weiter verteilen
	und/oder modifizieren.

	EURECAs e9u_LSMD Kamera-Software wird in der Hoffnung, dass es nützlich
	sein wird, aber OHNE JEDE GEWÄHRLEISTUNG, bereitgestellt; sogar ohne
	die implizite Gewährleistung der MARKTFÄHIGKEIT oder EIGNUNG FÜR
	EINEN BESTIMMTEN ZWECK.  Siehe die GNU General Public License für
	weitere Details.

    Sie sollten eine Kopie der GNU General Public License zusammen mit diesem
    Programm erhalten haben. Wenn nicht, siehe <https://www.gnu.org/licenses/>.

*/

// include for "sprintf"
#include <stdio.h>

// include for "exit"
#include <stdlib.h>

// include for "strcpy"
#include <string.h>

// include for "pthread_create"
#include <pthread.h>


#include "e9u_LSMD_defs.h"
#include "e9u_LSMD.h"
#include "e9u_LSMD_macros.h"





/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_search_for_camera (unsigned int ui_camera_index) {
int             i_status;
int             i_UART;
char            c_dev_name[256];

// test UARTs:
    i_UART = 99;
    do {
        sprintf (c_dev_name, "%s%s%d", e9u_LSMD_UART_DIRPREFIX, e9u_LSMD_UART_DEVPREFIX, i_UART);
        i_status = e9u_LSMD_UART_exists (c_dev_name);
        if (i_status == e9u_LSMD_OK) {
            i_status = e9u_LSMD_begin (ui_camera_index, c_dev_name);
            if (i_status == e9u_LSMD_FAIL)
                e9u_LSMD_end (ui_camera_index);
        }
        
        if (i_status == e9u_LSMD_FAIL) {
            --i_UART;
            if (i_UART < 0) {
                printf ("ERROR: did not find any e9u_LSMD camera!\n");
                return (e9u_LSMD_FAIL);
            }
        }
    } while (i_status == e9u_LSMD_FAIL);

// print camera information:
    printf ("API Version %X, using device %s:\n", e9u_LSMD_API_VERSION, c_dev_name);
    i_status = e9u_LSMD_board_info (ui_camera_index);
    i_status |= e9u_LSMD_eeprom_info (ui_camera_index, e9u_LSMD_SENSOR_BOARD);
    if (i_status == e9u_LSMD_FAIL)
        return (e9u_LSMD_FAIL);

    return (e9u_LSMD_OK);
}





/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_start_camera_freerun (unsigned int ui_camera_index) {
int i_status;
unsigned int ui_ch0_control;

    i_status  = e9u_LSMD_set_reg (ui_camera_index, e9u_LSMD_CH0_FRAME_TIME, e9u_LSMD_minimum_frame(ui_camera_index));
    i_status |= e9u_LSMD_set_reg (ui_camera_index, e9u_LSMD_CH0_EXP_TIME,   e9u_LSMD_minimum_frame(ui_camera_index));
    i_status |= e9u_LSMD_set_reg (ui_camera_index, e9u_LSMD_CH0_TRIG_DELAY, 0);

    ui_ch0_control = e9u_LSMD_C0C_DEFAULT;
    i_status |= e9u_LSMD_set_reg (ui_camera_index, e9u_LSMD_CH0_CONTROL,    ui_ch0_control);
    i_status |= e9u_LSMD_set_reg (ui_camera_index, e9u_LSMD_GLOBAL_CONTROL, e9u_LSMD_GC_DEFAULT);
    i_status |= e9u_LSMD_update_regs (ui_camera_index);
    if (i_status == e9u_LSMD_FAIL)
        exit (2);

    return (i_status);
}






/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_start_camera_trigger (unsigned int ui_camera_index) {
int i_status;
unsigned int ui_ch0_control;

    i_status  = e9u_LSMD_set_reg (ui_camera_index, e9u_LSMD_CH0_FRAME_TIME, e9u_LSMD_minimum_frame(ui_camera_index));
    i_status |= e9u_LSMD_set_reg (ui_camera_index, e9u_LSMD_CH0_EXP_TIME,   e9u_LSMD_minimum_frame(ui_camera_index));
    i_status |= e9u_LSMD_set_reg (ui_camera_index, e9u_LSMD_CH0_TRIG_DELAY, 0);

    ui_ch0_control = e9u_LSMD_C0C_DEFAULT;
    ui_ch0_control &= ~e9u_LSMD_C0C_TRIG_INT;
    ui_ch0_control &= ~e9u_LSMD_C0C_TRIG_USB;
    ui_ch0_control |=  e9u_LSMD_C0C_TRIG_EXT;
    i_status |= e9u_LSMD_set_reg (ui_camera_index, e9u_LSMD_CH0_CONTROL,    ui_ch0_control);
    i_status |= e9u_LSMD_set_reg (ui_camera_index, e9u_LSMD_GLOBAL_CONTROL, e9u_LSMD_GC_DEFAULT);
    i_status |= e9u_LSMD_update_regs (ui_camera_index);
    if (i_status == e9u_LSMD_FAIL)
        exit (2);

    return (i_status);
}






/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_start_camera_async (unsigned int ui_camera_index) {
int i_status;
unsigned int ui_ch0_control;

    i_status  = e9u_LSMD_set_reg (ui_camera_index, e9u_LSMD_CH0_FRAME_TIME, e9u_LSMD_minimum_frame(ui_camera_index));
    i_status |= e9u_LSMD_set_reg (ui_camera_index, e9u_LSMD_CH0_EXP_TIME,   e9u_LSMD_minimum_frame(ui_camera_index));
    i_status |= e9u_LSMD_set_reg (ui_camera_index, e9u_LSMD_CH0_TRIG_DELAY, 0);

    ui_ch0_control = e9u_LSMD_C0C_DEFAULT;
    ui_ch0_control &= ~e9u_LSMD_C0C_TRIG_INT;	// no internal frame timer
    ui_ch0_control &= ~e9u_LSMD_C0C_TRIG_EXT;	// no external trigger
    ui_ch0_control &= ~e9u_LSMD_C0C_TRIG_USB;	// do not trigger via USB yet, this is done just before a read
    i_status |= e9u_LSMD_set_reg (ui_camera_index, e9u_LSMD_CH0_CONTROL,    ui_ch0_control);
    i_status |= e9u_LSMD_set_reg (ui_camera_index, e9u_LSMD_GLOBAL_CONTROL, e9u_LSMD_GC_DEFAULT);
    i_status |= e9u_LSMD_update_regs (ui_camera_index);
    if (i_status == e9u_LSMD_FAIL)
        exit (2);

    return (i_status);
}






/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_set_times (unsigned int ui_camera_index, double d_exp_time, double d_frame_time) {
unsigned int ui_exp_time;
unsigned int ui_frame_time;

// calculate ms float to us int:
    if (d_frame_time <= 0.)
        ui_frame_time = 0;
    else
        ui_frame_time = d_frame_time * 1000;

// calculate ms float to us int:
    if (d_exp_time <= 0.)
        ui_exp_time = ui_frame_time;
    else
        ui_exp_time = d_exp_time * 1000;

    return (e9u_LSMD_set_times_us (ui_camera_index, ui_exp_time, ui_frame_time));
}



/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_set_times_us (unsigned int ui_camera_index, unsigned int ui_exp_time, unsigned int ui_frame_time) {
int          i_status;

// round frame time to multiple of step_frame:
    ui_frame_time /= e9u_LSMD_step_frame (ui_camera_index);
    ui_frame_time *= e9u_LSMD_step_frame (ui_camera_index);

// check for minimum frame time:
    if (ui_frame_time < e9u_LSMD_minimum_frame (ui_camera_index))
        ui_frame_time = e9u_LSMD_minimum_frame (ui_camera_index);


// calculate ms float to us int:
    if (ui_exp_time == 0)
        ui_exp_time = ui_frame_time;

// check for maximum exposure:
    if (ui_exp_time > ui_frame_time)
        ui_exp_time = ui_frame_time;

// round exposure time to multiple of step_exposure:
    ui_exp_time /= e9u_LSMD_step_exposure (ui_camera_index);
    ui_exp_time *= e9u_LSMD_step_exposure (ui_camera_index);

// check for minimum exposure:
    if (ui_exp_time < e9u_LSMD_minimum_exposure (ui_camera_index))
        ui_exp_time = e9u_LSMD_minimum_exposure (ui_camera_index);

    i_status  = e9u_LSMD_set_reg (ui_camera_index, e9u_LSMD_CH0_FRAME_TIME, ui_frame_time);
    i_status |= e9u_LSMD_set_reg (ui_camera_index, e9u_LSMD_CH0_EXP_TIME,   ui_exp_time);

    if (!(e9u_LSMD_get_status_flag (ui_camera_index) & e9u_LSMD_THREAD))
        i_status |= e9u_LSMD_update_regs (ui_camera_index);

    if (i_status == e9u_LSMD_FAIL)
        exit (2);

    return (i_status);
}





/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_get_next_frame (unsigned int ui_camera_index) {
int i_status = e9u_LSMD_OK;
unsigned int ui_ch0_control;


// trigger async USB, if not in free run or external trigger mode:
    ui_ch0_control = e9u_LSMD_get_reg32 (0, e9u_LSMD_CH0_CONTROL, e9u_LSMD_TX);
    if ((ui_ch0_control & (e9u_LSMD_C0C_TRIG_INT | e9u_LSMD_C0C_TRIG_EXT)) == 0) {
        ui_ch0_control |=  e9u_LSMD_C0C_TRIG_USB;
        
        i_status = e9u_LSMD_set_reg (ui_camera_index, e9u_LSMD_CH0_CONTROL, ui_ch0_control);
        i_status |= e9u_LSMD_update_regs (ui_camera_index);
    }    
    
    do {
        if (!(e9u_LSMD_get_status_flag (ui_camera_index) & e9u_LSMD_THREAD)) {
            i_status = e9u_LSMD_read_camera (ui_camera_index);
            if (i_status == e9u_LSMD_FAIL)
                exit (3);
        } else
            e9u_LSMD_SLEEP_ms (1);

    } while (!e9u_LSMD_check_new_frames (ui_camera_index, 0));


    if ((i_status >= 0xf0) && (i_status <= 0xf7)) {
        e9u_LSMD_update_memory (ui_camera_index, i_status & 0x0f);
        return (e9u_LSMD_OK);
    }
    return (e9u_LSMD_FAIL);
}





/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_wait_times (unsigned int ui_camera_index, double d_exp_time, double d_frame_time) {
int i_status;

    i_status = e9u_LSMD_set_times (ui_camera_index, d_exp_time, d_frame_time);

    do {
        i_status |= e9u_LSMD_get_next_frame (ui_camera_index);
    } while ( (e9u_LSMD_get_reg32 (ui_camera_index, e9u_LSMD_CH0_EXP_TIME, e9u_LSMD_TX) != 
               e9u_LSMD_diff32 (e9u_LSMD_get_reg32 (ui_camera_index, e9u_LSMD_CH0_T_STAMP_EXP_STOP, e9u_LSMD_SH), 
                                e9u_LSMD_get_reg32 (ui_camera_index, e9u_LSMD_CH0_T_STAMP_EXP_START, e9u_LSMD_SH))) );

    return (i_status);
}





/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_wait_times_us (unsigned int ui_camera_index, unsigned int ui_exp_time, unsigned int ui_frame_time) {
int i_status;

    i_status = e9u_LSMD_set_times_us (ui_camera_index, ui_exp_time, ui_frame_time);

    do {
        i_status |= e9u_LSMD_get_next_frame (ui_camera_index);
    } while ( (e9u_LSMD_get_reg32 (ui_camera_index, e9u_LSMD_CH0_EXP_TIME, e9u_LSMD_TX) != 
               e9u_LSMD_diff32 (e9u_LSMD_get_reg32 (ui_camera_index, e9u_LSMD_CH0_T_STAMP_EXP_STOP, e9u_LSMD_SH), 
                                e9u_LSMD_get_reg32 (ui_camera_index, e9u_LSMD_CH0_T_STAMP_EXP_START, e9u_LSMD_SH))) );

    return (i_status);
}





/** @brief ??
 * @param[??] ?? ??
 * @returns ??
 */
int DLL_CALL e9u_LSMD_discard_frames (unsigned int ui_camera_index, unsigned int ui_frames) {
int          i_status = e9u_LSMD_OK;
unsigned int ui_counter;

    for (ui_counter = 0; ui_counter < ui_frames; ++ui_counter)
        i_status = e9u_LSMD_get_next_frame (ui_camera_index);

    return (i_status);
}


